//These are the screen resolution on the actual display.
const int REAL_SCREEN_WIDTH=512;
const int REAL_SCREEN_HEIGHT=512;

//These are the 'logical' resolution; how many segments wide and tall the actual
//program logic will use.
const int LOG_SCREEN_WIDTH=64;
const int LOG_SCREEN_HEIGHT=64;

//This does the work of including all the drawing and scaling framework,
//as well as standard stuff like string, iostream, etc.
#include "src/Engine/engine.h"




//Declare sprites, fonts, and objects here.

Text* font=NULL;
Image* exampleimage=NULL;
Uint32 frametimer;


//Make the screen object.
SDL_Surface* screen=NULL;

int main()
{

    screen=SDL_SetVideoMode(REAL_SCREEN_WIDTH,REAL_SCREEN_HEIGHT,
                                32,SDL_SWSURFACE);
    
    /*To load a bitmap font, just pass the filename to its constructor and it
      will automatically figure out the character dimensions.*/
    font=new Text("./res/text.png");
    
    /*To load an IMAGE (see reference for details), this is the filename, the
      width of each frame, and the height of each frame.*/
    exampleimage=new Image("./res/examplesprite.png",8,8);
    
    /*To create a SPRITE, just pass a pointer to the image it will use to its
      constructor.*/
    Sprite examplesprite(exampleimage);
    
    /*To set the sprite's animation sequence, this is the first frame in the
      sequence, then the last frame in the sequence, then the number of 
      milliseconds that should elapse between each frame.*/
    examplesprite.setAnim(0,3,100);
    
    /*Setting a sprite's location on-screen, x axis, y axis, like normal.*/
    examplesprite.setPosition(10,15);

    SDL_Init(SDL_INIT_EVERYTHING);

    
    while(!quitgame)
    {
        frametimer=SDL_GetTicks();
        //Keep this here. All it does is grab input from the keyboard, so you
        //can use keyDown(), keyHit(), or keyReleased() to check for key states.
        getInput();
        
        //Input. Use standard SDL key constants for keycodes.
        if(keyDown(SDLK_SPACE))
        {
            //targetsurface,x,y,text,color(argb),spacing;
            
            font->render(screen,0,0," FONT! :)",0x00ffffff,4);
            font->render(screen,0,10,"EXAMPLESPRITE",0x00ff0000,2);
            font->render(screen,0,40,"EXAMPLE BOX",0x000000ff,1);
            font->render(screen,32,45,convertToString(45)+(std::string)"*"+convertToString(10),0x000000ff,1);
            font->render(screen,0,35,"\"!?.,:;'{}()*^@+-=\\",0x0000ff00,1);
            
            examplesprite.draw(screen);
            
            //targetsurface,topleft x,topleft y,bottomright x,bottomright y,color,full=true,thickness=1,alpha=255
            drawBox(screen,5,50,50,60,0x0000ff00,false,2);
            
            //drawBox(screen,20,20,45,45,0x00ffffff,true,1,128);
            
            //std::cout << (50 > 25) << "\n";
            
        }
        else
        {
            font->render(screen,4,30,"PRESS SPACE!",0x00ffffff,2,180);
        }
        
    
        //SDL_Flip(screen);
        
        dirtyRect(0,0,64,64);
        cleanRects(screen);
        
        int temp=(SDL_GetTicks()-frametimer);
        
        if(temp<11)
        {
            SDL_Delay(10-temp);
        }

        //SDL_Delay(15);
        SDL_FillRect(screen,NULL,0);
        
    }
    
    
    SDL_Quit();
    
    return 0;
}
