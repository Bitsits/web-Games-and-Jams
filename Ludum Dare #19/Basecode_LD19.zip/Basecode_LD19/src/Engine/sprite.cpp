Sprite::Sprite(Image* img)
{
    base=img;
    cycleStart=0;
    cycleEnd=base->frameCount-1;
    delay=0;
    timer=0;
    currentFrame=0;
    frameOffset=0;
    x=0;
    y=0;
}

void Sprite::setAnim(int cs,int ce,int del)
{
    if((cs!=cycleStart || ce!=cycleEnd || del!=delay) && cs!=ce)
    {
        cycleStart=cs;
        cycleEnd=ce+1;
        delay=del;
        frameOffset=(int)((SDL_GetTicks()%(del*(ce-cs)))/(ce-cs));
        currentFrame=0;
        timer=SDL_GetTicks()+del;
    }
    else if(cs==ce)
    {
        cycleStart=cs;
        cycleEnd=ce;
    }
}

void Sprite::setDelay(int del)
{
    delay=del;
}

void Sprite::setPosition(int nx,int ny)
{
    x=nx;
    y=ny;
}

void Sprite::draw(SDL_Surface* surf)
{
    if(cycleStart!=cycleEnd)
    {
        if(SDL_GetTicks()>timer)
        {
            //std::cout << "Increment: " << int((SDL_GetTicks()-timer)/(cycleEnd-cycleStart)) << "\n";
            currentFrame+=1;
            currentFrame=currentFrame%(cycleEnd-cycleStart);
            timer=SDL_GetTicks()+delay;
        }
        //currentFrame=currentFrame%(cycleEnd-cycleStart;
        
        //std::cout << currentFrame << "\n";
        
        int temp=currentFrame-frameOffset;
        if(temp<0)
        {
            temp=(cycleEnd-cycleStart)-frameOffset;
        }
        
        base->draw(surf,x,y,cycleStart+currentFrame);
    }
    else if(cycleStart==cycleEnd)
    {
        base->draw(surf,x,y,cycleStart);
    }
}
