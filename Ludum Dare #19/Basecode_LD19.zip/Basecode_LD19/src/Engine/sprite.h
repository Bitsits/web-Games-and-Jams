class Sprite
{
    public:
    Image* base;
    int cycleStart;
    int cycleEnd;
    int delay;
    int timer;
    int currentFrame;
    int frameOffset;
    int x,y;
    
    Sprite(Image* img);
    void draw(SDL_Surface* surf);
    void setAnim(int cs,int ce,int del);
    void setDelay(int del);
    void setPosition(int nx,int ny);
};
