//Draw a standard SDL_Surface with proper coordinate scaling.
void drawImage(SDL_Surface* surf,SDL_Surface* img,int x,int y,Uint8 alpha=255,
                int sx=-1,int sy=-1,int ex=-1,int ey=-1)
{
    //The Rect object SDL_BlitSurface needs for surface positioning.
    SDL_Rect posrect;
    
    posrect.x=x*WRATIO;
    posrect.y=y*HRATIO;


    /*sx,sy,ex,ey define a rectangle to draw out of the image, sx and sy
    representing the top left corner, ex and ey representing the bottom right
    corner. We don't need to use them if they aren't negative. If some but not
    all are negative, then no functional rectangle is defined and the values
    are ignored.*/

    if(sx!=-1 && sy!=-1 && ex!=-1 && ey!=-1)
    {
        //Set the alpha temporarily, in case it's something other than 255.
        SDL_SetAlpha(img,SDL_SRCALPHA,alpha);
        
        //The Rect object SDL needs to clip out specific portions of surfaces.
        SDL_Rect cliprect;
        //Multiply everything by WRATIO and HRATIO to account for scaling.
        cliprect.x=sx*WRATIO;
        cliprect.y=sy*HRATIO;
        cliprect.w=(ex-sx)*WRATIO;
        cliprect.h=(ey-sy)*HRATIO;
        
        //Draw it to the specified surface.
        SDL_BlitSurface(img,&cliprect,surf,&posrect);
        
        //Reset alpha to 255.
        SDL_SetAlpha(img,SDL_SRCALPHA,255);
    }
    else
    {
        //Set the alpha temporarily, in case it's something other than 255.
        SDL_SetAlpha(img,SDL_SRCALPHA,alpha);
        
        //Draw it to the specified surface.
        SDL_BlitSurface(img,NULL,surf,&posrect);
        
        //Reset alpha to 255.
        SDL_SetAlpha(img,SDL_SRCALPHA,255);
    }
}


/*Draw a rectangle that can either be full or hollow and with specified
transparency.*/
void drawBox(SDL_Surface* surf,int x1,int y1,int x2,int y2,Uint32 color,
        bool full=true,int thickness=1,Uint8 alpha=255)
{
    //The actual Rect object to be filled.
    SDL_Rect boxrect;
    boxrect.x=0;
    boxrect.y=0;
    boxrect.w=(x2-x1)*WRATIO;
    boxrect.h=(y2-y1)*HRATIO;
    
    /*Hollow rectangles work by making a temporary surface the size of the
    final rectangle to be draw, filling the whole thing with the specified
    color, then reducing the size of the rectangle and filling it with the
    universal 'transparent' color. As efficient as it could be? No. Fun?
                       FUCK YEAH!                                       */
    
    //A temporary surface 'necessary' for drawing a hollow rectangle.
    SDL_Surface* tmpsurf=SDL_CreateRGBSurface(SDL_SWSURFACE,
                                boxrect.w,boxrect.h,32,0,0,0,0);
    
    //Fill the whole rect with the base color.
    SDL_FillRect(tmpsurf,&boxrect,color);
    
    //Only need to reduce the size and fill with transparent if the coder asks.
    if(full==false)
    {
        /*This works by reducing the rectangle's size in both dimensions by
        thickness*2, then moving the rect over in both dimensions.*/
        boxrect.w-=(thickness*2)*WRATIO;
        boxrect.h-=(thickness*2)*HRATIO;
        boxrect.x=thickness*WRATIO;
        boxrect.y=thickness*HRATIO;
        
        //Fill the newly resized rect with the universal transparent color.
        SDL_FillRect(tmpsurf,&boxrect,0x00ff00ff);
        
        /*Then we set the colorkey of the temporary surface so that we can take
        advantage of SDL's binary transparency functionality.*/
        SDL_SetColorKey(tmpsurf,SDL_SRCCOLORKEY,0x00ff00ff);
    }
    
    /*Then we use the drawImage function which handles alpha and coordinate
    scaling for us.*/
    drawImage(surf,tmpsurf,x1,y1,alpha);
    
    /*Avoidin' dem memory leaks.*/
    SDL_FreeSurface(tmpsurf);
    
}


//EXTREMELY POORLY WRITTEN FUNCTION!
void drawLine(SDL_Surface* surf,int sx,int sy,int ex,int ey,Uint32 color,
                Uint8 alpha=255,bool fadeout=false)
{
    int dx=(ex-sx);
    int dy=(ey-sy);
    
    float m=(float)dy/(float)dx;
    
    if(abs(m)<=1)
    {
        int dx2=dx/abs(dx);

        float perc=abs(alpha/dx);
        
        for(int x=0;x!=dx;x+=dx2)
        {
            if(fadeout)
            {
                drawBox(surf,sx+x,sy+(m*x),sx+x+1,sy+(m*x)+1,color,true,1,
                                            alpha-(abs(x)*perc));
            }
        }
    }
    else if(abs(m)>1)
    {
        m=(float)dx/(float)dy;
        int dy2=dy/abs(dy);

        float perc=abs(alpha/dy);
        
        for(int y=0;y!=dy;y+=dy2)
        {
            if(fadeout)
            {
                drawBox(surf,sx+(m*y),sy+y,sx+(m*y)+1,sy+y+1,color,true,1,
                                           alpha-(abs(y)*perc));
            }
        }
    }
}

/*Makes a new SDL_Surface that's properly scaled to the display size.
This function exists primarily because when this framework was made, a goal
was to allow the programmer to use it without *ever* having to know what's
actually going on inside, and without this, the programmer would have to
use HRATIO and WRATIO quite frequently.*/
SDL_Surface* makeCanvas(int x,int y,int depth,Uint32 colorkey)
{
    SDL_Surface* newcanvas=SDL_CreateRGBSurface(SDL_SWSURFACE,x*WRATIO,y*HRATIO,
                                                    depth,0,0,0,0);
    
    SDL_SetColorKey(newcanvas,SDL_SRCCOLORKEY,colorkey);
    
    return newcanvas;
}

// THIRD-PARTY CODE BELOW

Uint32 readPixel(SDL_Surface *surface, int x, int y)
{
    int bpp = surface->format->BytesPerPixel;
    /* Here p is the address to the pixel we want to retrieve */
    Uint8 *p = (Uint8 *)surface->pixels + y * surface->pitch + x * bpp;

    switch(bpp) {
    case 1:
        return *p;

    case 2:
        return *(Uint16 *)p;

    case 3:
        if(SDL_BYTEORDER == SDL_BIG_ENDIAN)
            return p[0] << 16 | p[1] << 8 | p[2];
        else
            return p[0] | p[1] << 8 | p[2] << 16;

    case 4:
        return *(Uint32 *)p;

    default:
        std::cout << "readPixel error: target surface color > 32-bit";
        return 0;       /* shouldn't happen, but avoids warnings */
    }
}

template <class T>
void drawPixel(SDL_Surface* surf, int x,int y,T color,Uint8 alpha)
{
    int bpp=surf->format->BytesPerPixel;
    Uint8* p;
    
    switch(bpp)
    {
        case 1:
            if(sizeof(color)!=1)
            {
                std::cout << "drawPixel error: color given is " <<
                        sizeof(color)*8 << "-bit, but target surface color " <<
                        "is 8-bit.\n";
            }
            else
            {
                for(int a=0;a<WRATIO;a++)
                {
                    for(int b=0;b<HRATIO;b++)
                    {
                        p=(Uint8*)surf->pixels
                            +(y*HRATIO+b)
                            *surf->pitch
                            +(x*WRATIO+a)
                            *bpp;
                        p[0]=color;
                    }
                }
            }
            break;
        case 2:
            if(sizeof(color)!=2)
            {
                std::cout << "drawPixel error: color given is " <<
                        sizeof(color)*8 << "-bit, but target surface color " <<
                        "is 16-bit.\n";
            }
            else
            {
                for(int a=0;a<WRATIO;a++)
                {
                    for(int b=0;b<HRATIO;b++)
                    {
                        p=(Uint8*)surf->pixels
                            +(y*HRATIO+b)
                            *surf->pitch
                            +(x*WRATIO+a)
                            *bpp;
                        p[0]=color;
                        p[1]=color >> 8;
                    }
                }
            }
            break;
        case 3:
            if(sizeof(color)!=3)
            {
                std::cout << "drawPixel error: color given is " <<
                        sizeof(color)*8 << "-bit, but target surface color " <<
                        "is 24-bit.\n";
            }
            else
            {
                for(int a=0;a<WRATIO;a++)
                {
                    for(int b=0;b<HRATIO;b++)
                    {
                        p=(Uint8*)surf->pixels
                            +(y*HRATIO+b)
                            *surf->pitch
                            +(x*WRATIO+a)
                            *bpp;
                        if(SDL_BYTEORDER==SDL_BIG_ENDIAN)
                        {
                            p[0]=color >> 16;
                            p[1]=color >> 8;
                            p[3]=color;
                        }
                        else
                        {
                            p[0]=color;
                            p[1]=color >> 8;
                            p[2]=color >> 16;
                        }
                        
                    }
                }
            }
            break;
        case 4:
            if(sizeof(color)!=4)
            {
                std::cout << "drawPixel error: color given is " <<
                        sizeof(color)*8 << "-bit, but target surface color " <<
                        "is 32-bit.\n";
            }
            else
            {
                for(int a=0;a<WRATIO;a++)
                {
                    for(int b=0;b<HRATIO;b++)
                    {
                        p=(Uint8*)surf->pixels
                            +(y*HRATIO+b)
                            *surf->pitch
                            +(x*WRATIO+a)
                            *bpp;
                        /*p[0]=color;
                        p[1]=color >> 8;
                        p[2]=color >> 16;
                        p[3]=color >> 24;*/
                        std::cout << p[2]+(Uint8)(color >> 16)*((double)alpha/255) << "\n";
                        p[0]=p[0]+(Uint8)(color >> 0)*((double)alpha/255);
                        p[1]=p[1]+(Uint8)(color >> 8)*((double)alpha/255);
                        p[2]=p[2]+(Uint8)(color >> 16)*((double)alpha/255);
                        p[3]=p[3]+(Uint8)(color >> 24)*((double)alpha/255);
                    }
                }
            }
            break;
        default:
            std::cout << "drawPixel error: target surface color over 32-bit";
            break;
    }
    
}

void brightenPixel(SDL_Surface* surf,int x,int y,int amount)
{

    Uint8* p;
    int bpp=surf->format->BytesPerPixel;

    for(int a=0;a<WRATIO;a++)
    {
        for(int b=0;b<HRATIO;b++)
        {
            p=(Uint8*)surf->pixels
                +(y*HRATIO+b)
                *surf->pitch
                +(x*WRATIO+a)
                *bpp;
            if((p[0]+amount)<255)
            {
                p[0]+=amount;
            }
            else
            {
                p[0]=255;
            }
            
            if((p[1]+amount)<255)
            {
                p[1]+=amount;
            }
            else
            {
                p[1]=255;
            }
            
            if((p[2]+amount)<255)
            {
                p[2]+=amount;
            }
            else
            {
                p[2]=255;
            }
            
            if((p[3]+amount)<255)
            {
                p[3]+=amount;
            }
            else
            {
                p[3]=255;
            }
        }
    }
}
