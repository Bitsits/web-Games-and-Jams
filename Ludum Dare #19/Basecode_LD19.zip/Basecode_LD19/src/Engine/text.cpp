Text::Text(std::string filename)
{
    SDL_Surface* tempsurf=IMG_Load(filename.c_str());
    
    charMap=new Image(filename,tempsurf->w/8,tempsurf->h/12,0);
    
    SDL_FreeSurface(tempsurf);
}

void Text::render(SDL_Surface* surf,int x,int y,std::string rawtext,
                    Uint32 color,int space=1,Uint8 alpha=255)
{
    int fx=charMap->frameWidth/WRATIO;
    int fy=charMap->frameHeight/HRATIO;

    int so=rawtext.length();
    
    SDL_Surface* tmpsurf=SDL_CreateRGBSurface(SDL_SWSURFACE,
                                (so*fx+so*space)*WRATIO,fy*HRATIO,32,0,0,0,0);

    SDL_FillRect(tmpsurf,NULL,color);
    
    SDL_Rect tmprect;
    
    tmprect.w=space*WRATIO;
    tmprect.h=fy*HRATIO;
    tmprect.x=0;
    tmprect.y=0;
    
    for(int a=0;a<so;a++)
    {
        charMap->draw(tmpsurf,a*fx+(a*space),0,int(rawtext[a])-32);
    }
    
    for(int a=1;a<so+1;a++)
    {
        tmprect.x=(a*fx+((a-1)*space))*WRATIO;
        SDL_FillRect(tmpsurf,&tmprect,0x00000000);
    }
    
    SDL_SetColorKey(tmpsurf,SDL_SRCCOLORKEY,0x00ff00ff);
    drawImage(surf,tmpsurf,x,y,alpha);
    
    SDL_FreeSurface(tmpsurf);

    
}
