template <class T>
int sgn(T a)
{
    return (a>0)-(a<0);
}

template <class T>
std::string convertToString(T in)
{
    std::stringstream ss;
    ss << in;
    return ss.str();
}

template <class T>
T abs(T a)
{
    if(a<0)
    {
        return -a;
    }
    else
    {
        return a;
    }
}
















