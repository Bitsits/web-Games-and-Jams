void getInput()
{
    

    for(int i=0;i<323;++i)
    {
        previouskeymap[i]=currentkeymap[i];
    }

    
    SDL_Event event;    
    
    while(SDL_PollEvent(&event))
    {
        switch(event.type)
        {
            case SDL_QUIT:
                quitgame=true;
                break;
            case SDL_KEYDOWN:
                currentkeymap[event.key.keysym.sym]=true;
                break;
            case SDL_KEYUP:
                currentkeymap[event.key.keysym.sym]=false;
                break;
        }
    }
    
    //keymap=SDL_GetKeyState(NULL);

}

bool keyDown(int keynum)
{
    return currentkeymap[keynum];
}

bool keyHit(int keynum)
{
    if(!(previouskeymap[keynum]) && currentkeymap[keynum])
    {
        return true;
    }
    else
    {
        return false;
    }

}

bool keyReleased(int keynum)
{
    if(previouskeymap[keynum])
    {
        return true;
    }
    else
    {
        return false;
    }
}
