#include <sstream>
#include <iostream>
#include <math.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>


const int WRATIO=REAL_SCREEN_WIDTH/LOG_SCREEN_WIDTH;
const int HRATIO=REAL_SCREEN_HEIGHT/LOG_SCREEN_HEIGHT;

bool previouskeymap[323];
bool currentkeymap[323];
bool quitgame=false;

#include "utils.cpp"
#include "imageops.cpp"
#include "input.cpp"
#include "image.h"
#include "image.cpp"
#include "sprite.h"
#include "sprite.cpp"
#include "text.h"
#include "text.cpp"
#include "rects.cpp"
