#include <list>
//#include <SDL/SDL.h>

std::list<SDL_Rect> rectlist;
std::list<SDL_Rect>::iterator rectiter;


void dirtyRect(int x,int y,int x2,int y2)
{
    SDL_Rect temprect;
    
    if(x>x2)
    {
        int tmpx=x;
        x=x2;
        x2=tmpx;
    }
    if(y>y2)
    {
        int tmpy=y;
        y=y2;
        y2=tmpy;
    }
    
    if(x<0)
    {
        x=0;
    }
    if(x2>LOG_SCREEN_WIDTH)
    {
        x2=LOG_SCREEN_WIDTH;
    }
    if(y<0)
    {
        y=0;
    }
    if(y2>LOG_SCREEN_HEIGHT)
    {
        y2=LOG_SCREEN_HEIGHT;
    }
    

    
    temprect.x=x*WRATIO;
    temprect.y=y*HRATIO;
    temprect.w=(x2-x)*WRATIO;
    temprect.h=(y2-y)*HRATIO;
    
    rectlist.push_back(temprect);
}

void cleanRects(SDL_Surface* surf)
{
    for(rectiter=rectlist.begin();rectiter!=rectlist.end();rectiter++)
    {
        SDL_UpdateRect(surf,rectiter->x,rectiter->y,rectiter->w,rectiter->h);
        rectiter=rectlist.erase(rectiter);
    }
}
