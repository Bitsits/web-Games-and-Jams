class Text
{
    Image* charMap;
    
    public:
    Text(std::string filename);
    void render(SDL_Surface* surf,int x,int y,std::string rawtext,
                    Uint32 color,int space,Uint8 alpha);
};
