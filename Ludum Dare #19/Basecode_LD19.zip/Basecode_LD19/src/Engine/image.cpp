/* Creates a sprite object and loads the specified Image to be the sprite's
Image, and defines some variables to allow drawing just certain frames
in the Image when we need to. */
Image::Image(std::string filename,int fx,int fy,Uint32 colorKey=0x00ff00ff)
{
    SDL_Surface* tmpimage1=SDL_DisplayFormat(IMG_Load(filename.c_str()));
    
    /*  Make some temporary variables to hold the Image's width so the following
    for loops don't have to call for them constantly.  */
    int w=tmpimage1->w;
    int h=tmpimage1->h;
    int x,y;
    
    /*  Since we have the opportunity, we'll go ahead and calculate the
    scaled-up size here as well, and store them in totalWidth and
    totalHeight in the sprite object.  */
    totalWidth=w*WRATIO;
    totalHeight=h*HRATIO;
    
    //  And now we'll figure out the dimensions of a single (scaled-up) frame.
    frameWidth=totalWidth/(totalWidth/(fx*WRATIO));
    frameHeight=totalHeight/(totalHeight/(fy*HRATIO));
    
    frameCount=(totalWidth/frameWidth)*(totalHeight/frameHeight);
    frameCountX=totalWidth/frameWidth;
    frameCountY=totalHeight/frameHeight;
    
    /*  Define the final Image as a scaled-up (or not) copy of the
    specified one.  */
    data=SDL_CreateRGBSurface(SDL_SWSURFACE,w*WRATIO,h*HRATIO,
                            32,0,0,0,0);
    
    /*  Make a temporary rect object to be the 'brush' for the scaled-up
    version of the loaded Image.  */
    SDL_Rect tmprect;
    tmprect.w=WRATIO;
    tmprect.h=HRATIO;
    
    for(x=0;x<w;++x)
    {
        for(y=0;y<h;++y)
        {
            /*  Move the 'brush' to the (x,y) coordinates, scaled up to fit
            the target size.  */
            tmprect.x=x*WRATIO;
            tmprect.y=y*HRATIO;
            
            /*  Fill the brush with the color of the corresponding coordinates
            from the base Image, onto the final Image. (So one pixel from the
            original becomes a WRATIO*HRATIO rectangle on the final Image,
            creating the illusion of pixellation.)  */

            SDL_FillRect(data,&tmprect,readPixel(tmpimage1,x,y));

            
        }
        
    }
    
    SDL_SetColorKey(data,SDL_SRCCOLORKEY,colorKey);
    
}



void Image::draw(SDL_Surface* surf,int x,int y,int frame,Uint8 alpha=255)
{

    /*  Make a temporary rect to control the location where the frame is
    drawn to the surface, and set its coordinates to a scaled-up
    version of the given coordinates.  */
    SDL_Rect posrect;
    
    posrect.x=x*WRATIO;
    posrect.y=y*HRATIO;
    
    /*  Calculate the number of frames along each axis.  */
    int fcx=totalWidth/frameWidth;
    int fcy=totalHeight/frameHeight;
    
    /*  Make a temporary rect to control which section of the Image is shown  */
    SDL_Rect cliprect;
    
    SDL_SetAlpha(data,SDL_SRCALPHA,alpha);
    
    if(frame==-1)
    {
        SDL_BlitSurface(data,NULL,surf,&posrect);
    }
    else
    {
        /*  We only do this part if frame has been specified as not being
        equal to -1, because -1 is a special case allowing the entire image, not
        just single frames, to be drawn.  */ 
        cliprect.w=frameWidth;
        cliprect.h=frameHeight;
        cliprect.x=(frame % fcx)*frameWidth;
        cliprect.y=int(frame/fcx)*frameHeight;
        SDL_BlitSurface(data,&cliprect,surf,&posrect);
    }

    SDL_SetAlpha(data,SDL_SRCALPHA,255);
    
    //std::cout << frame << "\n";
}
