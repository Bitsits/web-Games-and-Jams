class Image
{
    SDL_Surface* data;
    
    public:
    int frameCount,frameWidth,frameHeight,totalWidth,totalHeight;
    int frameCountX,frameCountY;
    
    Image(std::string filename,int fx,int fy,Uint32 colorKey);
    void draw(SDL_Surface* surf,int x,int y,int frame,Uint8 alpha);
};
