// Under the MIT license. Petri Purho
#ifndef INC_WEBUTILS_H
#define INC_WEBUTILS_H

#include <string>
#include <vector>


// utility stuff
std::string		GetDataFromWeb( const std::string& url );
std::string		GetDataFromWebPost( const std::string& url, const std::string& post_data );
std::string		GetDataFromWebPost( const std::string& url, const std::vector< std::pair< std::string, std::string > >&  post_data );


struct HiddenWebApiData;
std::string GetDataFromWeb( const std::string& url ) ;

struct CFunkyWeb
{
	CFunkyWeb();
	~CFunkyWeb();
	void StartPageLoading( const std::string& url );
	std::string GetPageResponse();

	HiddenWebApiData* myWebApiData;
};


#endif
