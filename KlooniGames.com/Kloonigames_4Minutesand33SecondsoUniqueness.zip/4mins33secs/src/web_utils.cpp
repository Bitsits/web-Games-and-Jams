// Under the MIT license. Petri Purho
#include "web_utils.h"

#include <curl/curl.h>
#include <fstream>

#include <iostream>
#include <assert.h>

#include <sdl.h>

#define logger_error std::cout
#define cassert assert


//=============================================================================
namespace {

static int curl_writer(char *data, size_t size, size_t nmemb,
                  std::string *buffer)
{
	int result = 0;

	if (buffer != NULL)
	{
		buffer->append(data, size * nmemb);
		result = (int)( size * nmemb );
	}

	return result;
}

} // end o anonymous namespace
//=============================================================================

void DownloadAFile( const std::string& url, const std::string& filename )
{
	char		error_buffer[CURL_ERROR_SIZE];
	std::string	buffer;

    CURL *curl;
    CURLcode result;

    curl = curl_easy_init();

	if( curl )
    {
		curl_easy_setopt(curl, CURLOPT_ERRORBUFFER, error_buffer);
		curl_easy_setopt(curl, CURLOPT_URL, url.c_str() );
		curl_easy_setopt(curl, CURLOPT_HEADER, 0);
		curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1);
		curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, curl_writer);
		curl_easy_setopt(curl, CURLOPT_WRITEDATA, &buffer);

		result = curl_easy_perform(curl);

		curl_easy_cleanup(curl);

		if( result == CURLE_OK )
		{
			std::fstream fout( filename.c_str(), std::ios::out | std::ios::binary );
			fout << buffer;
			fout.close();
		}
		else
		{
			logger_error << "Error: [" << result << "] - " << error_buffer;
		}
	}
}

//=============================================================================

std::string GetDataFromWeb( const std::string& url )
{
	char		error_buffer[CURL_ERROR_SIZE];
	std::string	buffer;

    CURL *curl;
    CURLcode result;

    curl = curl_easy_init();

	if( curl )
    {
		curl_easy_setopt(curl, CURLOPT_ERRORBUFFER, error_buffer);
		curl_easy_setopt(curl, CURLOPT_URL, url.c_str() );
		curl_easy_setopt(curl, CURLOPT_HEADER, 0);
		curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1);
		curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, curl_writer);
		curl_easy_setopt(curl, CURLOPT_WRITEDATA, &buffer);

		result = curl_easy_perform(curl);

		curl_easy_cleanup(curl);

		if( result == CURLE_OK )
		{
			return buffer;
		}
		else
		{
			logger_error << "Error: [" << result << "] - " << error_buffer;
		}
	}

	return "";
}

//=============================================================================

std::string GetDataFromWebPost( const std::string& url, const std::string& post_data )
{
	char		error_buffer[CURL_ERROR_SIZE];
	std::string	buffer;

    CURL *curl;
    CURLcode result;

    curl = curl_easy_init();

	if( curl )
    {
		curl_easy_setopt(curl, CURLOPT_ERRORBUFFER, error_buffer);
		curl_easy_setopt(curl, CURLOPT_URL, url.c_str() );
		if( post_data.empty() == false )
			curl_easy_setopt(curl, CURLOPT_POSTFIELDS, post_data.c_str() );
		curl_easy_setopt(curl, CURLOPT_HEADER, 0);
		curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1);
		curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, curl_writer);
		curl_easy_setopt(curl, CURLOPT_WRITEDATA, &buffer);

		result = curl_easy_perform(curl);

		curl_easy_cleanup(curl);

		if( result == CURLE_OK )
		{
			return buffer;
		}
		else
		{
			logger_error << "Error: [" << result << "] - " << error_buffer;
		}
	}

	return "";
}


std::string GetDataFromWebPost( const std::string& url, const std::vector< std::pair< std::string, std::string > >& post_data )
{
    CURL *curl = curl_easy_init();
    if( curl == NULL )
    {
        return "";
    }

	std::string	buffer;
	char		error_buffer[CURL_ERROR_SIZE];


	curl_easy_setopt(curl, CURLOPT_ERRORBUFFER, error_buffer);

    struct curl_httppost *post=NULL;
    struct curl_httppost *last=NULL;
    
	for( unsigned int i = 0; i < post_data.size(); ++i )
	{
		if( post_data[ i ].first.empty() == false &&
			post_data[ i ].second.empty() == false )
		{
			curl_formadd(&post, &last,
               CURLFORM_COPYNAME, post_data[ i ].first.c_str(),
               CURLFORM_COPYCONTENTS, post_data[ i ].second.c_str(), CURLFORM_END);
		}
	}

    curl_easy_setopt(curl, CURLOPT_HTTPPOST, post);
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str() );
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, curl_writer );
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &buffer );

	
    // curl_easy_setopt(curl, CURLOPT_USERAGENT, "monster-agent/1.0");    
    
    CURLcode result = curl_easy_perform(curl);
	if( result == CURLE_OK )
	{
		return buffer;
	}
	else
	{
		logger_error << "Error: [" << result << "] - " << error_buffer;
	}
    curl_formfree(post);
    curl_easy_cleanup(curl);

	return "";
}

///////////////////////////////////////////////////////////////////////////////


struct HiddenWebApiData
{
	HiddenWebApiData() :	
		response(), 
		updated( false ), 
		lock( NULL )
	{ 
		lock = SDL_CreateMutex();
	}

	~HiddenWebApiData()
	{
		SDL_DestroyMutex( lock );
		lock = NULL;
	}

	void Reset() 
	{
		updated = false;
		response.clear();
	}

	bool Enter()
	{
		cassert( lock );
		if( lock == NULL )
			return false;

		if( SDL_mutexP( lock ) == -1 )
		{
			logger_error << "Thread fail: SDL_mutexP failed" << std::endl;
			return false;
		}
		return true;
	}

	bool Leave()
	{
		cassert( lock );

		if( lock == NULL )
			return false;

		if( SDL_mutexV( lock ) == -1 )
		{
			logger_error << "Thread fail: SDL_mutexV failed" << std::endl;
			return false;
		}
		return true;
	}

	std::string		response;
	bool			updated;
	SDL_mutex*		lock;
};

struct GenericInputData
{
	std::string url;
	HiddenWebApiData* web_api;
};

int GenericThread( void* data )
{
	GenericInputData* input_data = (GenericInputData*)data;
	if( input_data == NULL )
		return -1;

	std::string server = "http://www.kloonigames.com/";

	std::string url = input_data->url;
	std::string web_response = GetDataFromWeb( url );

	if( input_data->web_api->Enter() )
	{
		input_data->web_api->response = web_response;
		input_data->web_api->updated = true;
	}

	input_data->web_api->Leave();	

	delete input_data;
	input_data = NULL;
	
	return 0;
}

//=============================================================================
CFunkyWeb::CFunkyWeb()
{
	myWebApiData = new HiddenWebApiData;
}

CFunkyWeb::~CFunkyWeb()
{
	delete myWebApiData;
	myWebApiData = NULL;
}

	void CFunkyWeb::StartPageLoading( const std::string& url )
	{
		GenericInputData* input_data = new GenericInputData;
		input_data->web_api = myWebApiData;
		input_data->url = url;


		SDL_CreateThread( GenericThread, (void*)input_data );	
	}

	std::string CFunkyWeb::GetPageResponse()
	{
		if( myWebApiData->Enter() )
		{
			if( myWebApiData->updated )
			{
				myWebApiData->updated = false;
				return myWebApiData->response;
			}
			myWebApiData->Leave();
		}

		return "";
	}

///////////////////////////////////////////////////////////////////////////////
