// Under the MIT license. Petri Purho
#pragma comment( lib, "libcurl.lib" )
#pragma comment( lib, "ws2_32.lib" )
#pragma comment( lib, "wldap32.lib" )
#pragma comment( lib, "shell32.lib" )
#pragma comment( lib, "sdl.lib" )
#pragma comment( lib, "sdlmain.lib" )

#include <sdl.h>
#include <windows.h>

#include <stdio.h>
#include <curl/curl.h>

#include <string>
#include <iostream>
#include <fstream>
#include <assert.h>
#include <vector>
#include <sstream>
#include <iomanip>
#include <time.h>
// #include "curl/curl.h"

#include "web_utils.h"

#define logger_error std::cout
#define cassert assert

SDL_Surface* screen = NULL;
SDL_Surface* end_screen = NULL;

int CreateNewWindow( int w, int h, const std::string& tittle, bool fullscreen = false )
{

	if( SDL_Init( SDL_INIT_VIDEO | SDL_INIT_JOYSTICK ) < 0 )
		std::cout << "Error: SDL_Init failed - reason: " << SDL_GetError() << std::endl;

	screen = SDL_SetVideoMode( w, h, 0, SDL_SWSURFACE );

	SDL_WM_SetCaption( tittle.c_str(), tittle.c_str() ); 

	return 1;
}

int		running = 1;

void kill_me()
{
	running = 0;
	/*CFunkyWeb* random = 0;
				std::string t = random->GetPageResponse();
				t += "f";*/
}

int main(int argc, char* argv[])
{
	srand((unsigned)time(0)); 

	int random_id = rand();
	
	std::stringstream ss;
	ss << "http://www.kloonigames.com/nordicjam2009/new_game.php?v=" << random_id;
	std::cout << "Starting the game" << std::endl;
	{
		CFunkyWeb funky_web;
		funky_web.StartPageLoading( ss.str() );
		
		std::string response = funky_web.GetPageResponse();
		while( response == "" )
		{
			response = funky_web.GetPageResponse();
		}

		// std::cout << response << std::endl;
	}

	std::string result_should_be = "";
	{
		CFunkyWeb funky_web;
		funky_web.StartPageLoading( "http://www.kloonigames.com/nordicjam2009/whois.txt" );

		while( result_should_be == "" )
		{
			result_should_be = funky_web.GetPageResponse();
		}
	}

	CreateNewWindow( 640, 480, "3 Minutes of Uniqueness" );
	CFunkyWeb* funky_web = new CFunkyWeb;

	// std::cout << "game_started" << std::endl;
	Uint32 time_started = SDL_GetTicks();
	
	std::string response_in = "";
	Uint32	last_update = 0;
	Uint32  last_web = 0;
	int request_made = 0;
	int request_received = 0;
	Uint32 when_we_end = 3 * 60 * 1000;
	SDL_Event event;

	bool completed = false;
	while( running  )
	{
		if( SDL_GetTicks() > last_update + 16 )
		{
			last_update = SDL_GetTicks();

			SDL_Rect rect;
			rect.x = 0;
			rect.y = 0;
			rect.w = (int)( (float) ( (float)( last_update - time_started ) / (float)when_we_end ) * 640 );
			rect.h = 480;

			if( ( last_update - time_started ) > when_we_end )
			{
				completed = true;
				if( end_screen == NULL )
				{
					end_screen = SDL_LoadBMP( "end_screen.bmp" );
					
					funky_web = new CFunkyWeb;
					funky_web->StartPageLoading( "http://www.kloonigames.com/nordicjam2009/igotit.php" );
				}
			}

			if( end_screen )
			{
				SDL_BlitSurface( end_screen, NULL, screen, NULL );
			}
			else
			{
				SDL_FillRect( screen , &rect , 0xffffffff );
			}
			SDL_Flip( screen );

			if( end_screen == NULL && SDL_GetTicks() > last_web + 2000 )
			{
				if( request_made != request_received )
				{
					kill_me();
				}

				delete funky_web;
				funky_web = new CFunkyWeb;

				// std::cout << request_made << " / " << request_received << std::endl; 
				funky_web->StartPageLoading( "http://www.kloonigames.com/nordicjam2009/whois.txt" );
				request_made++;
				last_web = SDL_GetTicks();
			}

			response_in = funky_web->GetPageResponse();
			if( response_in != "" )
			{
				request_received++;
				if( response_in != result_should_be )
				{
					// std::cout << response_in << " != " << result_should_be << std::endl;
					// std::cout << "someone else is online" << std::endl;
					kill_me();
				}
			}

			while( SDL_PollEvent( &event ) ) 
			{
				switch( event.type ) 
				{
					case SDL_KEYDOWN:
					{
						switch( event.key.keysym.sym )
						{
						case SDLK_ESCAPE:
							running = 0;
							break;
						}
					}
					break;
					case SDL_QUIT:
						running = 0;
					break;

				}
			}
		}
	}
	// std::cout << GetDataFromWeb( "http://www.kloonigames.com/" ) << std::endl;	
	return 0;
}
