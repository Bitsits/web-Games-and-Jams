#include "graphics.h"

namespace impl 
{

bool mute_all = false;
void MuteAll( bool value ) { mute_all = value; }

Direct3DCrap* Direct3DCrap::global_impl = 0;

void PreloadEffect( const std::string& file ) { MixerFile::GetEffect( file ); }

void PlayEffectImpl( const std::string& file )
{
	MixerFile* temp = MixerFile::GetEffect( file );

	if( temp->myMixChunk )
	{
		Mix_PlayChannel( -1, temp->myMixChunk, 0 );
	}
	else
	{
		delete temp;
		temp = NULL;
	}
}

void PlayEffect( const std::string& file )
{
	if( mute_all ) 
		return;

	static std::string last_play = "";
	static Uint32 last_time = 0;

	if( SDL_GetTicks() - last_time < 100 &&
		last_play == file )
	{
	}
	else
	{
		PlayEffectImpl( file );
		last_play = file;
		last_time = SDL_GetTicks();
	}
}
	
Direct3DCrap InitDirect3DCrap( int w, int h )
{
	Direct3DCrap result;

	std::cout << "Creating Direct3D device" << std::endl;
	LPDIRECT3D9 direct3D_object = Direct3DCreate9( D3D_SDK_VERSION );
	result.direct3D_object = direct3D_object;
	if( direct3D_object == NULL )
	{
		std::cout << "Could not create Direct3D Object" << std::endl;
		return result;
	}

	// get the display mode
	D3DDISPLAYMODE d3ddm;
	direct3D_object->GetAdapterDisplayMode(D3DADAPTER_DEFAULT, &d3ddm);

	D3DPRESENT_PARAMETERS present_parameters;
	memset( &present_parameters, 0, sizeof( present_parameters ) );

	present_parameters.Windowed					= TRUE;
	present_parameters.BackBufferCount			= 1;
	present_parameters.MultiSampleType			= D3DMULTISAMPLE_NONE;
	present_parameters.SwapEffect				= D3DSWAPEFFECT_DISCARD;
	present_parameters.EnableAutoDepthStencil	= FALSE; 
	present_parameters.AutoDepthStencilFormat	= D3DFMT_UNKNOWN;
	present_parameters.hDeviceWindow			= GetActiveWindow();
	present_parameters.Flags					= 0; 
	present_parameters.PresentationInterval		= D3DPRESENT_INTERVAL_IMMEDIATE;
	present_parameters.BackBufferWidth			= w;
	present_parameters.BackBufferHeight			= h;
	present_parameters.BackBufferFormat			=  d3ddm.Format; 
	present_parameters.FullScreen_RefreshRateInHz = D3DPRESENT_RATE_DEFAULT;	
	
	LPDIRECT3DDEVICE9 direct3D_device = NULL;

	//creating direct3D device
	if( FAILED( direct3D_object->CreateDevice( 
		D3DADAPTER_DEFAULT, 
		D3DDEVTYPE_HAL, 
		GetActiveWindow(), 
		D3DCREATE_SOFTWARE_VERTEXPROCESSING, 
		&present_parameters, 
		&direct3D_device ) ) )
	{
		std::cout << "Could not create Direct3D Device" << std::endl;
		return result;
	}

	//establishing projection matrix, lighting, culling, depth buffer, and vertex format
	D3DXMATRIX mat;
	D3DXMatrixIdentity(&mat);
	direct3D_device->SetTransform(D3DTS_WORLD, &mat);
	direct3D_device->SetTransform(D3DTS_VIEW, &mat);
	direct3D_device->SetTransform(D3DTS_PROJECTION, &mat);

	direct3D_device->SetRenderState( D3DRS_DITHERENABLE, TRUE );
	direct3D_device->SetRenderState( D3DRS_ZENABLE,      FALSE );
	direct3D_device->SetRenderState( D3DRS_LIGHTING,     FALSE );
	direct3D_device->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE);

	direct3D_device->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_NONE);
	direct3D_device->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_NONE);
	direct3D_device->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_NONE);
	direct3D_device->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
	direct3D_device->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);

	direct3D_device->SetSamplerState(1, D3DSAMP_MINFILTER, D3DTEXF_NONE);
	direct3D_device->SetSamplerState(1, D3DSAMP_MAGFILTER, D3DTEXF_NONE);
	direct3D_device->SetSamplerState(1, D3DSAMP_MIPFILTER, D3DTEXF_NONE);
	direct3D_device->SetSamplerState(1, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	direct3D_device->SetSamplerState(1, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);

	direct3D_device->SetSamplerState(2, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	direct3D_device->SetSamplerState(2, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);
	direct3D_device->SetSamplerState(2, D3DSAMP_MINFILTER, D3DTEXF_NONE);
	direct3D_device->SetSamplerState(2, D3DSAMP_MAGFILTER, D3DTEXF_NONE);
	direct3D_device->SetSamplerState(2, D3DSAMP_MIPFILTER, D3DTEXF_NONE);

	result.direct3D_device = direct3D_device;


	LPD3DXSPRITE sprite_device = NULL;
	if( FAILED( D3DXCreateSprite( direct3D_device, &sprite_device ) ) )
	{
		std::cout << "Couldn't create sprite device" << std::endl;
	}
	
	result.direct3D_object = direct3D_object;
	result.direct3D_device = direct3D_device;
	result.sprite_device = sprite_device;

	std::cout << "Creating Direct3D device [OK]" << std::endl;

	Direct3DCrap::global_impl = new Direct3DCrap;
	Direct3DCrap::global_impl->direct3D_object = result.direct3D_object;
	Direct3DCrap::global_impl->direct3D_device = result.direct3D_device;
	Direct3DCrap::global_impl->sprite_device = result.sprite_device;

	return result;
}

void InitSDL( int w, int h, const std::string& window_name )
{
	SDL_Init( SDL_INIT_VIDEO | SDL_INIT_TIMER );
	SDL_Surface* screen = SDL_SetVideoMode( w, h, 0, SDL_SWSURFACE );
	SDL_WM_SetCaption( window_name.c_str(), window_name.c_str() ); 
	// InitDirect3DCrap( w, h );
}

Direct3DCrap InitStuff( int w, int h, const std::string& window_name )
{
	InitSDL( w, h, window_name );
	return InitDirect3DCrap( w, h );
}

void ShutDownD3D( const Direct3DCrap& crap )
{
	bool shutdown_failed = false;
	if( crap.sprite_device )
	{
		if( crap.sprite_device->Release() != 0 )
		{
			std::cout << "sprite device unitialization failed" << std::endl;
			shutdown_failed = true;
		}
	}

	if( crap.direct3D_device )
	{
		if( crap.direct3D_device->Release() != 0 )
		{
			std::cout << "direct3d device unitialization failed" << std::endl;
			shutdown_failed = true;
		}
	}
	
	if( crap.direct3D_object )
	{
		if( crap.direct3D_object->Release() != 0 )
		{
			std::cout << "direct3d object unitialization failed" << std::endl;
			shutdown_failed = true;
		}
	}
}


LPDIRECT3DTEXTURE9 LoadD3DTexture( const std::string& filename )
{
	LPDIRECT3DDEVICE9 direct3D_device = Direct3DCrap::global_impl->direct3D_device; // GetGlobalDevice(); //  impl::CGlobalD3D::GetSingletonPtr()->direct3d_variables->direct3D_device;

	if( direct3D_device == NULL )	
	{
		std::cout << "Couldn't load image (" << filename <<"), because Direct3D device wasn't initialized." << std::endl;
		return NULL;
	}

	D3DXIMAGE_INFO info;
	if( FAILED( D3DXGetImageInfoFromFile( filename.c_str(), &info ) ) )
	{
		std::cout << "Couldn't load image (" << filename <<"), because D3DXGetImageInfoFromFile failed." << std::endl;
		return NULL;
	}

	LPDIRECT3DTEXTURE9 texture = NULL;

	if( FAILED(	D3DXCreateTextureFromFileEx( direct3D_device,
					 filename.c_str(),
					 info.Width, // I had to set width manually. D3DPOOL_DEFAULT works for textures but causes problems for D3DXSPRITE.
					 info.Height, // I had to set height manually. D3DPOOL_DEFAULT works for textures but causes problems for D3DXSPRITE.
					 1,   // Don't create mip-maps when you plan on using D3DXSPRITE. It throws off the pixel math for sprite animation.
					 D3DPOOL_DEFAULT,
					 D3DFMT_UNKNOWN,
					 D3DPOOL_DEFAULT,
					 D3DX_DEFAULT,
					 D3DX_DEFAULT,
					 0, // D3DCOLOR_COLORVALUE(0.0f,0.0f,0.0f,1.0f),
					 &info,
					 NULL,
					 &texture ) ) )
	{
		std::cout << "Couldn't load image (" << filename <<"), because D3DXCreateTextureFromFileEx failed." << std::endl;
		return NULL;
	}

	if( texture == NULL )
		std::cout << "Couldn't load image (" << filename <<"), because D3DXCreateTextureFromFileEx failed." << std::endl;

	return texture;
}

CD3DTexture* ReallyLoadATexture( const std::string& filename )
{
	D3DXIMAGE_INFO info;
	if( FAILED( D3DXGetImageInfoFromFile( filename.c_str(), &info ) ) )
	{
		std::cout << "Couldn't load image (" << filename <<"), because D3DXGetImageInfoFromFile failed." << std::endl;
		return NULL;
	}

	LPDIRECT3DTEXTURE9 texture = LoadD3DTexture( filename );

	CD3DTexture* texture_helper = new CD3DTexture( texture, info.Width, info.Height, filename );
	texture_helper->reference_count = 1;

	return texture_helper;
}

CD3DTexture* LoadTexture( const std::string& filename )
{
	std::list< CD3DTexture* >& textures_list = ceng::CAutoList< CD3DTexture >::GetList();
	
	std::list< CD3DTexture* >::iterator i = textures_list.begin();

	for( ; i != textures_list.end(); ++i )
	{
		if( (*i)->filename == filename )
		{
			(*i)->reference_count++;
			return (*i);
		}
	}
	
	return ReallyLoadATexture( filename );
}

void ReleaseTexture( CD3DTexture* texture )
{
	if( texture )
	{
		texture->reference_count--;
		if( texture->reference_count <= 0 )
			delete texture;
	}
}

void AddToRenderer( CSprite* sprite )
{
	std::list< CSprite* >& sprite_list = CRenderer::GetSingletonPtr()->mySprites;
	std::list< CSprite* >::iterator i = sprite_list.begin();
	
	bool inserted = false;
	for( ; i != sprite_list.end(); ++i )
	{
		if ( (*i)->GetZValue() >= sprite->GetZValue() )
		{
			sprite_list.insert( i, sprite );
			inserted = true;
			break;
		}
	}

	if( inserted == false )
		sprite_list.push_back( sprite );
}

CSprite* LoadASprite( const std::string& filename, float z_value  )
{
	CSprite* temp = new CSprite( filename );
	temp->myZValue = z_value;
	AddToRenderer( temp );

	return temp;
}

void RemoveFromRenderer( CSprite* sprite )
{
	std::list< CSprite* >& sprite_list = CRenderer::GetSingletonPtr()->mySprites;
	std::list< CSprite* >::iterator i = sprite_list.begin();
	for( ; i != sprite_list.end(); ++i )
	{
		if( *i == sprite )
		{
			sprite_list.erase( i );
			return;
		}
	}
}

void CSprite::Hide()
{
	if( myHidden == false )
	{
		myHidden = true;
		RemoveFromRenderer( this );
	}
}

void CSprite::Show()
{
	if( myHidden )
	{
		myHidden = false;
		AddToRenderer( this );
	}
}

} // edn o namespace