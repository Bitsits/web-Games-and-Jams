#ifndef INC_CGAMEPLAY_H
#define INC_CGAMEPLAY_H

#include <string>
#include <memory>

namespace impl {
	class CSprite;
}

class CGameplay
{
public:
	CGameplay();
	~CGameplay();

	void Update();

	void OnMouseDown( float x, float y );
	void OnMouseUp( float x, float y );
	void OnMouseMove( float x, float y );

	void ToggleGame();

private:
	class CGameplayImpl;
	std::auto_ptr< CGameplayImpl > impl;

	void ClickNext();

	int myStatus;
	impl::CSprite* mySprite;

};

#endif
