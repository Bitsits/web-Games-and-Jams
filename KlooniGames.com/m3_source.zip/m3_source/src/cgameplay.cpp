#include "cgameplay.h"
#include "graphics.h"

#include "utils/staticarray/cstaticarray.h"

#include <sstream>
#include <vector>
#include <assert.h>
#include <time.h>

float frandom( float min, float max )
{
	float ra = (float)rand();
	ra /= RAND_MAX;
	return ( (max - min) * ra + min );
}

int random( int min, int max )
{
	static bool initialized = false;
	if( initialized == false )
	{
		initialized = true;
		srand( ( unsigned )time( 0 ) ); 
	}
	return ( rand() % (max - min) ) + min;
}

bool reset_me = false;

///////////////////////////////////////////////////////////////////////////////
namespace types {

	typedef Uint32 ticks;

	class CTimer
	{
	public:

		CTimer() { Reset(); }

		void Reset() 
		{
			myStartTime = SDL_GetTicks();
		}

		ticks GetTime() const 
		{
			return ( SDL_GetTicks() - myStartTime );
		}

		ticks myStartTime;
	};

	typedef CTimer timer;
	typedef impl::CSprite* sprite;
	typedef impl::vector2 vector2;
	typedef impl::Rect rect;

	const int drag_size = 5;
	typedef ceng::CStaticArray< ceng::CStaticArray< int, drag_size >, drag_size > drag_array;

	const int gameplay_size = 14;
	typedef ceng::CStaticArray< ceng::CStaticArray< int, gameplay_size >, gameplay_size > gameplay_array;
	// typedef int drag_array[ 25 ];

	const int box_width = 32;
	const int box_height = 32;

	const int max_colors = 4;
} // end o types

const types::vector2 extra_herkku( ( 1024.f - 800.f ) * 0.5f, 0  );

///////////////////////////////////////////////////////////////////////////////

class INumericFilter
{
public:
	virtual ~INumericFilter() { }

	virtual float Filter( float v ) = 0;
};

///////////////////////////////////////////////////////////////////////////////

class IAnimationUpdator
{
public:
	virtual ~IAnimationUpdator() { }

	virtual void Update( types::ticks time ) = 0;
	virtual bool IsDead() const { return true; }
	virtual bool CheckForSprite( const types::sprite& sprite ) const = 0;
};

//=============================================================================

class CAnimationSoundEffect : public IAnimationUpdator
{
public:
	CAnimationSoundEffect( const std::string& filename )
	{
		myFilename = filename;
	}

	std::string myFilename;

	virtual void Update( types::ticks time ) 
	{
		impl::PlayEffect( myFilename );
	}

	virtual bool IsDead() const { return true; }
	virtual bool CheckForSprite( const types::sprite& sprite ) const { return false; }
};

class CAnimationBasics : public IAnimationUpdator
{
public:
	CAnimationBasics( types::ticks total_time, INumericFilter* filter = NULL ) : 
		myDeadTime( total_time ), 
		myCurrentTime( 0 ), 
		myDead( false ),
		myFilter( filter ),
		myAllowExtras( false )
	{ 
	}

	virtual ~CAnimationBasics() { }

	virtual bool IsDead() const 
	{ 
		return myDead; 
	}

	virtual float GetAsFloat( types::ticks delta_time )
	{
		myCurrentTime += delta_time;
		float value = (float)myCurrentTime / (float)myDeadTime;

		if( value >= 1.0f ) 
		{
			value = 1.0f; 
			myDead = true;
		}

		if( myFilter )
			value = myFilter->Filter( value );

		if( myAllowExtras == false )
		{
			if( value < 0.0f ) value = 0.0f;
			if( value > 1.0f ) value = 1.0f;
		}

		return value;
	}

protected:

	types::ticks	myDeadTime;
	types::ticks	myCurrentTime;
	bool			myDead;
	INumericFilter* myFilter;
	bool			myAllowExtras;
};

//=============================================================================

class CAnimationKiller : public IAnimationUpdator
{
public:
	CAnimationKiller( const types::sprite& sprite, types::ticks total_time ) : 
		myDeadTime( total_time ), 
		myCurrentTime( 0 ), 
		myDead( false ),
		mySprite( sprite )
	{ 
	}

	virtual ~CAnimationKiller() 
	{ 
		delete mySprite;
		mySprite = NULL;
	}

	virtual bool IsDead() const 
	{ 
		return myDead; 
	}

	virtual float GetAsFloat( types::ticks delta_time )
	{
		myCurrentTime += delta_time;
		float value = (float)myCurrentTime / (float)myDeadTime;

		if( value >= 1.0f ) 
		{
			value = 1.0f; 
			myDead = true;
		}

		return value;
	}

	virtual void Update( types::ticks time )
	{
		GetAsFloat( time );
	}

	virtual bool CheckForSprite( const types::sprite& sprite ) const { return ( mySprite == sprite ); }

protected:

	types::ticks	myDeadTime;
	types::ticks	myCurrentTime;
	bool			myDead;
	types::sprite	mySprite;
};

//=============================================================================

class CAnimationResizer : public CAnimationBasics
{
public:
	CAnimationResizer( const types::sprite& sprite, float scale_x_target, float scale_y_target, types::ticks time, INumericFilter* filter = NULL ) :
		CAnimationBasics( time, filter ),
		mySprite( sprite ),
		myTargetScaleX( scale_x_target ),
		myTargetScaleY( scale_y_target ),
		myOrigScaleX( 1.0f ),
		myOrigScaleY( 1.0f )
	{
		if( mySprite )
		{
			myOrigScaleX = mySprite->myScaleX;
			myOrigScaleY = mySprite->myScaleY;
		}
	}

	void Update( types::ticks time )
	{
		float v = GetAsFloat( time );
		float scale_x_now = ( myTargetScaleX - myOrigScaleX ) * v + myOrigScaleX;
		float scale_y_now = ( myTargetScaleY - myOrigScaleY ) * v + myOrigScaleY;

		if( mySprite )
		{
			types::vector2 temp_pos = mySprite->GetCenterPos();
			mySprite->Resize( scale_x_now, scale_y_now );
			mySprite->MoveCenterTo( temp_pos );
		}
	}

	virtual bool CheckForSprite( const types::sprite& sprite ) const { return ( mySprite == sprite ); }

	types::sprite mySprite;
	float myTargetScaleX;
	float myTargetScaleY;
	float myOrigScaleX;
	float myOrigScaleY;
};

//=============================================================================

class CAnimationMover : public CAnimationBasics
{
public:
	CAnimationMover( const types::sprite& sprite, float target_x, float target_y, types::ticks time, INumericFilter* filter = NULL ) :
		CAnimationBasics( time, filter ),
		mySprite( sprite ),
		myTargetX( target_x ),
		myTargetY( target_y ),
		myOrigX( 1.0f ),
		myOrigY( 1.0f )
	{
		if( mySprite )
		{
			myOrigX = mySprite->myRect.x;
			myOrigY = mySprite->myRect.y;
		}
	}

	void Update( types::ticks time )
	{
		float v = GetAsFloat( time );
		float x_now = ( myTargetX - myOrigX ) * v + myOrigX;
		float y_now = ( myTargetY - myOrigY ) * v + myOrigY;

		if( mySprite )
			mySprite->MoveTo( x_now, y_now );
	}

	virtual bool CheckForSprite( const types::sprite& sprite ) const { return ( mySprite == sprite ); }

	types::sprite mySprite;
	float myTargetX;
	float myTargetY;
	float myOrigX;
	float myOrigY;
};

///////////////////////////////////////////////////////////////////////////////

class CAnimationBouncer : public CAnimationBasics
{
public:
	CAnimationBouncer( const types::sprite& sprite, float target_x, float speed, types::ticks time, INumericFilter* filter = NULL ) :
		CAnimationBasics( time, filter ),
		mySprite( sprite ),
		myTargetX( target_x ),
		mySpeed( speed ),
		myVelocity( 0.01f ),
		myOrigX( 1.0f )
	{
		if( mySprite )
		{
			myOrigX = mySprite->myRect.x;
			myOrigY = mySprite->myRect.y;
		}
	}

	void Update( types::ticks time )
	{
		float vel = myTargetX > mySprite->myRect.x?1.f:-1.f;
		float add = vel * myVelocity;
		if( myVelocity != 0 )
			myVelocity += mySpeed;
		float v = GetAsFloat( time );
		float x_now = mySprite->myRect.x + add;
		float y_now = myOrigY;

		if( vel > 0 )
		{
			if( x_now > myTargetX )
			{
				float t = x_now - myTargetX;
				x_now = myTargetX - t;
				myVelocity = -0.5f * myVelocity;
				if( fabs( myVelocity ) < mySpeed * 3 ) 
				{
					myVelocity = 0;
					x_now = myTargetX;
				}
			}
		}
		else
		{
			if( x_now < myTargetX )
			{
				float t = myTargetX - x_now;
				x_now = myTargetX + t;
				myVelocity = -0.5f * myVelocity;
				if( fabs( myVelocity ) < mySpeed * 3 ) 
				{
					myVelocity = 0;
					x_now = myTargetX;
				}
			}
		}

		if( mySprite )
			mySprite->MoveTo( x_now, y_now );
	}

	virtual bool CheckForSprite( const types::sprite& sprite ) const { return ( mySprite == sprite ); }

	types::sprite mySprite;
	float myTargetX;
	float mySpeed;
	float myVelocity;
	float myOrigX;
	float myOrigY;
};

//=============================================================================

class CAnimationFader : public CAnimationBasics
{
public:
	CAnimationFader( const types::sprite& sprite, float target_alpha, types::ticks time, INumericFilter* filter = NULL ) :
		CAnimationBasics( time, filter ),
		mySprite( sprite ),
		myTargetAlpha( target_alpha ),
		myOrigAlpha( 1.0f )
	{
		if( mySprite )
		{
			myOrigAlpha = mySprite->myAlpha;
		}
	}

	void Update( types::ticks time )
	{
		float v = GetAsFloat( time );
		float alpha_now = ( myTargetAlpha - myOrigAlpha ) * v + myOrigAlpha;

		if( mySprite )
			mySprite->SetAlpha( alpha_now );
	}

	virtual bool CheckForSprite( const types::sprite& sprite ) const { return ( mySprite == sprite ); }

	types::sprite mySprite;
	float myTargetAlpha;
	float myOrigAlpha;
};

//=============================================================================

class CAnimationConstantFader : public IAnimationUpdator
{
public:


	CAnimationConstantFader( const types::sprite& sprite, float alpha_steps_in_second, INumericFilter* filter = NULL ) :
		IAnimationUpdator(),
		myDead( false ),
		mySprite( sprite ),
		myAlphaInSec( alpha_steps_in_second ),
		myFilter( filter ),
		myOrigAlpha( 1.0f ),
		myDirection( false )
	{
		if( mySprite )
		{
			myOrigAlpha = mySprite->myAlpha;
		}
	}

	void Update( types::ticks time )
	{
		float v = GetAsFloat( time );
		float alpha_now = mySprite->myAlpha;
		
		if( myDirection )
		{
			alpha_now += ( v * myAlphaInSec );
		}
		else
		{
			alpha_now -= ( v * myAlphaInSec );
		}

		if( alpha_now > 1.0f )
		{
			myDirection = !myDirection;
			alpha_now = 1.0f;
		}

		if( alpha_now < 0.0f )
		{
			myDirection = !myDirection;
			alpha_now = 0.0f;
		}

		if( mySprite )
			mySprite->SetAlpha( alpha_now );
	}

	virtual bool CheckForSprite( const types::sprite& sprite ) const { return ( mySprite == sprite ); }
	
	virtual bool IsDead() const {return myDead;}

	void KillMe() { myDead = true; mySprite->SetAlpha( myOrigAlpha ); mySprite = NULL; }

	float GetAsFloat( types::ticks time )
	{
		float t = (float)time / 1000.f;
		if( myFilter )
			t = myFilter->Filter( t );

		return t;
	}

	bool			myDirection;
	bool			myDead;
	INumericFilter* myFilter;
	float			myAlphaInSec;
	types::sprite	mySprite;
	float			myOrigAlpha;
};


///////////////////////////////////////////////////////////////////////////////

class CSimpleUiElement
{
public:
	CSimpleUiElement( const types::rect& recto, const std::string& background, const std::string& higlight, int id ) :
		myRect( recto ),
		myBackground( NULL ),
		myHilight( NULL ),
		myMouseOver( false ),
		myUiId( id )
	{ 
		float z_value = 0.7f;
		if( id < 0 ) z_value = 0.51f;
		myBackground = impl::LoadASprite( background,  z_value );
		myHilight = impl::LoadASprite( higlight, z_value + .01f );
		
		if( myBackground )
			myBackground->MoveTo( myRect.x, myRect.y );

		if( myHilight )
			myHilight->MoveTo( myRect.x, myRect.y );

		SetHilight( false );
	}
	~CSimpleUiElement() 
	{ 
		delete myBackground;
		delete myHilight;
	}

	bool MouseDown( const types::vector2& p  ) const { return IsMouseOver( p ); }
	void CheckMouseOver( const types::vector2& p ) 
	{
		if( IsMouseOver( p ) )
		{
			if( myMouseOver == false )
			{
				SetHilight( true );
				myMouseOver = true;
			}
		}
		else
		{
			if( myMouseOver == true )
			{
				SetHilight( false );
				myMouseOver = false;
			}
		}
	}

	bool IsMouseOver( const types::vector2& p ) const
	{
		return ( myRect.IsPointInside( p ) );
	}

	void SetHilight( bool value )
	{
		if( value )
		{
			myHilight->Show();
		}
		else
		{
			myHilight->Hide();
		}
	}

	int				myUiId;
	types::rect		myRect;
	types::sprite	myBackground;
	types::sprite	myHilight;
	bool			myMouseOver;
};

///////////////////////////////////////////////////////////////////////////////

types::drag_array CreateDragArray( 
	int x11 = 0, int x12 = 0, int x13 = 0, int x14 = 0, int x15 = 0,
	int x21 = 0, int x22 = 0, int x23 = 0, int x24 = 0, int x25 = 0,
	int x31 = 0, int x32 = 0, int x33 = 0, int x34 = 0, int x35 = 0,
	int x41 = 0, int x42 = 0, int x43 = 0, int x44 = 0, int x45 = 0,
	int x51 = 0, int x52 = 0, int x53 = 0, int x54 = 0, int x55 = 0 )
{
	types::drag_array result;

	result[ 0 ][ 0 ] = x11;
	result[ 0 ][ 1 ] = x12;
	result[ 0 ][ 2 ] = x13;
	result[ 0 ][ 3 ] = x14;
	result[ 0 ][ 4 ] = x15;

	result[ 1 ][ 0 ] = x21;
	result[ 1 ][ 1 ] = x22;
	result[ 1 ][ 2 ] = x23;
	result[ 1 ][ 3 ] = x24;
	result[ 1 ][ 4 ] = x25;

	result[ 2 ][ 0 ] = x31;
	result[ 2 ][ 1 ] = x32;
	result[ 2 ][ 2 ] = x33;
	result[ 2 ][ 3 ] = x34;
	result[ 2 ][ 4 ] = x35;

	result[ 3 ][ 0 ] = x41;
	result[ 3 ][ 1 ] = x42;
	result[ 3 ][ 2 ] = x43;
	result[ 3 ][ 3 ] = x44;
	result[ 3 ][ 4 ] = x45;

	result[ 4 ][ 0 ] = x51;
	result[ 4 ][ 1 ] = x52;
	result[ 4 ][ 2 ] = x53;
	result[ 4 ][ 3 ] = x54;
	result[ 4 ][ 4 ] = x55;


	return result;
}

///////////////////////////////////////////////////////////////////////////////

class CDraggableElement
{
public:
	CDraggableElement() : 	myHaveWeBeenAdded( false ), myGameplayX( 0 ), myGameplayY( 0 ), hidden( false ) { }
	~CDraggableElement() 
	{ 
		Clear();
	}

	bool hidden;
	void Hide()
	{
		if( hidden == false )
		{
			SetHighlight( false );

			hidden = true;
			for( unsigned int i = 0; i < mySprites.size(); ++i )
			{
				mySprites[ i ]->Hide();
				// impl::RemoveFromRenderer( mySprites[ i ] );
			}

			for( unsigned int i = 0; i < myExtraHilight.size(); ++i )
			{
				myExtraHilight[ i ]->Hide();
				// impl::RemoveFromRenderer( myExtraHilight[ i ] );
			}
		}
	}

	void Show()
	{
		if( hidden == true )
		{
			hidden = false;
			for( unsigned int i = 0; i < mySprites.size(); ++i )
			{
				mySprites[ i ]->Show();
				// impl::AddToRenderer( mySprites[ i ] );
			}

			for( unsigned int i = 0; i < myExtraHilight.size(); ++i )
			{
				myExtraHilight[ i ]->Show();
				// impl::AddToRenderer( myExtraHilight[ i ] );
			}
			
			SetHighlight( false );
		}
	}

	void Clear()
	{
		for( unsigned int i = 0; i < mySprites.size(); ++i )
		{
			delete mySprites[ i ];
		}
		mySprites.clear();

		for( unsigned int i = 0; i < myExtraHilight.size(); ++i )
		{
			delete myExtraHilight[ i ];
		}
		myExtraHilight.clear();
	}

	void MoveTo( const types::vector2& v )
	{
		types::vector2 delta = v - myPosition;
		for( unsigned int i = 0; i < mySprites.size(); ++i )
		{
			mySprites[ i ]->MoveBy( delta.x, delta.y );
		}

		for( unsigned int i = 0; i < myExtraHilight.size(); ++i )
		{
			myExtraHilight[ i ]->MoveBy( delta.x, delta.y );
		}
		
		myPosition = v;
	}

	bool IsMouseOver( const types::vector2& v ) const
	{
		for( unsigned int i = 0; i < mySprites.size(); ++i )
		{
			if( mySprites[ i ]->myRect.IsPointInside( v ) ) 
				return true;
		}

		return false;
	}

	void SetHighlight( bool value )
	{
		if( hidden == false && myExtraHilight.size() >= 2 )
		{
			if( value )
			{
				myExtraHilight[ 0 ]->Hide();
				myExtraHilight[ 1 ]->Show();
			}
			else
			{
				myExtraHilight[ 1 ]->Hide();
				myExtraHilight[ 0 ]->Show();
			}
		}
	}

	void SetData( const types::drag_array& data )
	{
		myData = data;
	}

	void OnDrag() 
	{
	}

	void ReleaseFromGameplayArea( types::gameplay_array& gameplay )
	{
		assert( myHaveWeBeenAdded );
		if( myHaveWeBeenAdded == false ) return;

		for( int x = 0; x < types::drag_size; ++x )
		{
			for( int y = 0; y < types::drag_size; ++y )
			{
				int m_value = myData[ y ][ x ];
				if( m_value )
				{
					int game_x = myGameplayX + x;
					int game_y = myGameplayY + y;

					if( game_x < 0 || game_y < 0 || 
						game_x >= types::gameplay_size || 
						game_y >= types::gameplay_size )
					{
						assert( false );
						return;
					}
					
					assert( m_value == gameplay[ game_y ][ game_x ] );
					gameplay[ game_y ][ game_x ] = 0;
				}
			}
		}

		myHaveWeBeenAdded = false;
	}

	void AddToGameplayArea( types::gameplay_array& gameplay, int p_x, int p_y )
	{
		assert( CouldBeAddedToGameplayAt( gameplay, p_x, p_y ) );

		for( int x = 0; x < types::drag_size; ++x )
		{
			for( int y = 0; y < types::drag_size; ++y )
			{
				int m_value = myData[ y ][ x ];
				if( m_value )
				{
					int game_x = p_x + x;
					int game_y = p_y + y;

					if( game_x < 0 || game_y < 0 || 
						game_x >= types::gameplay_size || 
						game_y >= types::gameplay_size )
					{
						assert( false );
						return;
					}
					
					if( gameplay[ game_y ][ game_x ] != 0 )
					{
						assert( false );
						return ;
					}

					gameplay[ game_y ][ game_x ] = m_value;
				}
			}
		}

		myHaveWeBeenAdded = true;
		myGameplayX = p_x;
		myGameplayY = p_y;
	}

	//.........................................................................

	bool CouldBeAddedToGameplayAt( const types::gameplay_array& gameplay, int p_x, int p_y )
	{
		for( int x = 0; x < types::drag_size; ++x )
		{
			for( int y = 0; y < types::drag_size; ++y )
			{
				int m_value = myData[ y ][ x ];
				if( m_value )
				{
					int game_x = p_x + x;
					int game_y = p_y + y;

					if( game_x < 0 || game_y < 0 || 
						game_x >= types::gameplay_size || 
						game_y >= types::gameplay_size )
						return false;
					
					if( gameplay[ game_y ][ game_x ] != 0 )
						return false;
				}
			}
		}

		return true;
	}

	types::drag_array myData;

	std::vector< types::sprite > mySprites;
	std::vector< types::sprite > myExtraHilight;
	types::vector2 myPosition;

	bool myHaveWeBeenAdded;
	int myGameplayX;
	int myGameplayY;
};

///////////////////////////////////////////////////////////////////////////////

types::sprite GetFontSprite( const std::string& text, float size = 1.0f, float z_value = 0.5f )
{
	const std::string font_filename = "data/gfx/font_big_numbers.png";
	
	impl::CSpriteText* temp = new impl::CSpriteText( font_filename );
	temp->myZValue = z_value;
	impl::AddToRenderer( temp );
	temp->SetCharacterSettings( types::vector2( 18.f, 24.f ), '0' );
	temp->Resize( size, size );
	temp->SetText( text );

	return temp;
}

types::sprite GetChainSpriteFor( int crap, float size )
{
	float z_value = 0.8f;
	const std::string font_filename = "data/gfx/bonus_numbers.png";

	std::stringstream ss;
	ss << ":" << crap;
	std::string text = ss.str();
	
	impl::CSpriteText* temp = new impl::CSpriteText( font_filename );
	temp->myZValue = z_value;
	impl::AddToRenderer( temp );
	temp->SetCharacterSettings( types::vector2( 75.f, 89.f ), '0' );
	temp->Resize( size, size );
	temp->SetText( text );

	return temp;
}

types::sprite GetPieceForType( int i )
{
	std::stringstream ss;
	ss << "data/gfx/cube_0" << i << ".png";

	return impl::LoadASprite( ss.str() );
}

types::sprite GetHighlightForShape( int shape, int hi )
{
	std::stringstream ss;
	ss << "data/gfx/shape_0" << shape << "_0" << hi << ".png";
	return impl::LoadASprite( ss.str(), 0.65f );
}

CDraggableElement* CreateNewDraggableElement( const types::drag_array& a, const types::vector2& position, int shape_n )
{
	CDraggableElement* result = new CDraggableElement;

	for( int x = 0; x < types::drag_size; ++x )
	{
		for( int y = 0; y < types::drag_size; ++y )
		{
			int v = a[ y ][ x ];
			if( v > 0 )
			{
				types::sprite sprite = GetPieceForType( v );
				sprite->MoveTo( x * (float)types::box_width, y * (float)types::box_height );
				result->mySprites.push_back( sprite );
			}
		}
	}

	result->SetData( a );

	result->myExtraHilight.resize( 2 );
	result->myExtraHilight[ 0 ] = GetHighlightForShape( shape_n, 0 );
	result->myExtraHilight[ 1 ] = GetHighlightForShape( shape_n, 1 );

	result->MoveTo( position );
	result->SetHighlight( false );

	return result;
}

class CScoreBoard
{
public:
	CScoreBoard() :
		myScore( 0 ),
		myCurrentScore( 0 )
	{ 
		mySprite = (impl::CSpriteText*)GetFontSprite( "0", 1.0f, 0.65f ); 
	}

	~CScoreBoard() 
	{ 
		delete mySprite;
		mySprite = NULL;
	}

	void AddScore( int s ) { SetScore( myScore + s ); }
	void SetScore( int score )
	{
		if( score < myScore )
		{
			myCurrentScore = score - 1;
		}
		myScore = score;
	}

	void Update()
	{
		if( myCurrentScore != myScore )
		{
			int add_helper = 0;
			for( int i = 0; i < 8; ++i )
			{
				if( myCurrentScore + add_helper <= myScore ) 
				{
					myCurrentScore += add_helper?add_helper:1;
				}
				else
				{
					break;
				}

				if( add_helper == 0 )
					add_helper = 10;
				else
					add_helper = add_helper * 10;
			}

			std::stringstream ss;
			ss << myCurrentScore;

			mySprite->SetText( ss.str() );
		}
	}

	int myCurrentScore;
	int myScore;
	impl::CSpriteText* mySprite;
};

///////////////////////////////////////////////////////////////////////////////

CScoreBoard* myBestScore = NULL;

class CGameplay::CGameplayImpl
{
public:

	std::vector< CSimpleUiElement* > myUiElements;

	CGameplayImpl() :
		background( NULL ),
		mouse_pos(),
		mouse_down( false ),

		myCurrentHilight( NULL ),
		myDraggableElements(),
		myDraggingElement( NULL ),
		myDragOffset(),
		myRunningGame( false ),
		myCurrentPiece( NULL ),
		mySinglePieces(),
		myScoreBoard( NULL )
	{ 
		Init(); 
	}

	CScoreBoard* myScoreBoard;

	~CGameplayImpl() 
	{ 
		Clear();
	}

	std::vector< IAnimationUpdator* > myAnimations;
	std::vector< std::pair< types::ticks, IAnimationUpdator* > > myAnimationAddQueue;

	//============================================================================
	
	void InitGameplayArray( const types::vector2& position )
	{
		for( int x = 0; x < types::gameplay_size; ++x )
		{
			for( int y =0; y < types::gameplay_size; ++y )
			{
				myGameplayArray[ x ][ y ] = 0;
				myObjectArray[ y ][ x ] = NULL;
			}
		}

		myGameplayArrayPos = position;
	}

	//============================================================================

	void Reset()
	{
	}

	//============================================================================

	void Clear()
	{
		delete myScoreBoard;
		myScoreBoard = NULL;

		// delete myBestScore;
		// myBestScore = NULL;

		for( unsigned int i = 0; i < myUiElements.size(); ++i )
			delete myUiElements[ i ];
		myUiElements.clear();

		for( unsigned int i = 0; i < myAnimationAddQueue.size(); ++i )
			delete myAnimationAddQueue[ i ].second;
		myAnimationAddQueue.clear();

		for( unsigned int i = 0; i < myAnimations.size(); ++i )
			delete myAnimations[ i ];
		myAnimations.clear();

		delete background;
		background = NULL;

		delete myFirstDropSprite;
		myFirstDropSprite = NULL;

		for( int x = 0; x < types::gameplay_size; ++x )
		{
			for( int y = 0; y < types::gameplay_size; ++y )
			{
				delete myObjectArray[ y ][ x ];
				myObjectArray[ y ][ x ] = NULL;
			}
		}

		for( unsigned int i = 0; i < myDraggableElements.size(); ++i )
		{
			delete myDraggableElements[ i ];
		}
		myDraggableElements.clear();
	}

	std::vector< types::drag_array > myDragArrays;
	
	//============================================================================

	types::drag_array GetRandomDragArray( int& result_num )
	{
		if( myDragArrays.empty() ) 
		{
			if( false )
			{
				myDragArrays.push_back( CreateDragArray
				(	0, 0, 1, 0, 0,
					0, 0, 1, 0, 0,
					0, 1, 1, 0, 0,
					0, 0, 0, 0, 0,
					0, 0, 0, 0, 0 ) );

				myDragArrays.push_back( CreateDragArray
				(	1, 1, 1, 1, 1,
					0, 0, 0, 0, 0,
					0, 0, 0, 0, 0,
					0, 0, 0, 0, 0,
					0, 0, 0, 0, 0 ) );

				myDragArrays.push_back( CreateDragArray
				(	1, 1, 1, 0, 0,
					1, 1, 1, 0, 0,
					1, 1, 1, 0, 0,
					0, 0, 0, 0, 0,
					0, 0, 0, 0, 0 ) );

				myDragArrays.push_back( CreateDragArray
				(	1, 1, 0, 0, 0,
					1, 1, 0, 0, 0,
					1, 1, 0, 0, 0,
					0, 0, 0, 0, 0,
					0, 0, 0, 0, 0 ) );

				myDragArrays.push_back( CreateDragArray
				(	1, 1, 1, 0, 0,
					1, 1, 1, 0, 0,
					0, 0, 0, 0, 0,
					0, 0, 0, 0, 0,
					0, 0, 0, 0, 0 ) );

				myDragArrays.push_back( CreateDragArray
				(	1, 1, 1, 0, 0,
					0, 1, 0, 0, 0,
					0, 0, 0, 0, 0,
					0, 0, 0, 0, 0,
					0, 0, 0, 0, 0 ) );

				myDragArrays.push_back( CreateDragArray
				(	1, 1, 0, 0, 0,
					1, 1, 0, 0, 0,
					0, 0, 0, 0, 0,
					0, 0, 0, 0, 0,
					0, 0, 0, 0, 0 ) );

				myDragArrays.push_back( CreateDragArray
				(	1, 1, 1, 0, 0,
					0, 0, 1, 0, 0,
					0, 0, 1, 0, 0,
					0, 0, 0, 0, 0,
					0, 0, 0, 0, 0 ) );
			}

			if( true )
			{
				myDragArrays.push_back( CreateDragArray
					(	1, 1, 1, 0, 0,
						0, 0, 0, 0, 0,
						0, 0, 0, 0, 0,
						0, 0, 0, 0, 0,
						0, 0, 0, 0, 0 ) );
				
				myDragArrays.push_back( CreateDragArray
					(	1, 0, 0, 0, 0,
						1, 0, 0, 0, 0,
						1, 0, 0, 0, 0,
						0, 0, 0, 0, 0,
						0, 0, 0, 0, 0 ) );

				myDragArrays.push_back( CreateDragArray
					(	1, 1, 0, 0, 0,
						1, 1, 0, 0, 0,
						0, 0, 0, 0, 0,
						0, 0, 0, 0, 0,
						0, 0, 0, 0, 0 ) );
			}
		}

		result_num = random( 0, myDragArrays.size() );
		types::drag_array result = myDragArrays[ result_num  ];

		for( int x = 0; x < types::drag_size; ++x )
		{
			for( int y = 0 ; y < types::drag_size; ++y )
			{
				if( result[ y ][ x ] )
				{
					result[ y ][ x ] = random( 1, types::max_colors ); 
				}
			}
		}

		return result;
	}

	types::sprite myFirstDropSprite;
	int myFirstDropColor;

	void ClearUi()
	{
		for( unsigned int i = 0; i < myUiElements.size(); ++i )
			delete myUiElements[ i ];
		myUiElements.clear();

		delete myScoreBoard;
		myScoreBoard = NULL;
	}

	enum UiCodes
	{
		ui_start = 1,
		ui_newgame = 2,
		ui_stop = 3
	};

	void InitEditorUi()
	{
		ClearUi();
		
		myUiElements.push_back( new CSimpleUiElement( types::rect( 172 + extra_herkku.x, 19, 126, 40 ), "data/gfx/start_button_lo.png", "data/gfx/start_button_hi.png", ui_start  ) );
		myUiElements.push_back( new CSimpleUiElement( types::rect( 486 + extra_herkku.x, 19, 129, 34 ), "data/gfx/newgame_button_lo.png", "data/gfx/newgame_button_hi.png", ui_newgame )  );
	}

	void InitInGameUi()
	{
		ClearUi();
		
		myUiElements.push_back( new CSimpleUiElement( types::rect( 542 + extra_herkku.x, 29, 73, 38 ), "data/gfx/stop_button_lo.png", "data/gfx/stop_button_hi.png", ui_stop )  );
		myUiElements.push_back( new CSimpleUiElement( types::rect( 158 + extra_herkku.x, 0, 465, 72 ), "data/gfx/ingame_background.png", "data/gfx/ingame_background.png", -1  ) );

		myScoreBoard = new CScoreBoard();
		myScoreBoard->mySprite->MoveTo( 259 + extra_herkku.x, 43 );
	}

	types::vector2 AddThingCrap( int shape )
	{
		switch( shape )
		{
		case 0:
			return types::vector2( 105, 40 );
			break;
		case 1:
			return types::vector2( 40, 105 );
			break;
		case 2:
			return types::vector2( 74, 74 );
			break;
		}

		return types::vector2( 74, 74 );
	}

	void Init()
	{
		background = impl::LoadASprite( "data/gfx/background.png", .1f );

		InitGameplayArray( types::vector2( 167, 75 ) + extra_herkku  );

		myFirstDropColor = random( 1, types::max_colors );
		myFirstDropSprite = GetPieceForType( myFirstDropColor );
		myFirstDropSprite->MoveTo( 361 + extra_herkku.x, 5 );

		types::vector2 last_pos( 20, 35 );
		float x_min_pos = 20;
		float max_x_pos = 200;
		float max_y_add = 0;

		for( int i = 0; i < 40; ++i )
		{
			int shape = 0;
			types::drag_array t = GetRandomDragArray( shape );
			CDraggableElement* element = CreateNewDraggableElement( t, last_pos, shape );
			myDraggableElements.push_back( element );

			types::vector2 extra_add = AddThingCrap( shape );
			if( extra_add.y > max_y_add ) 
				max_y_add = extra_add.y;
			last_pos.x += extra_add.x;
			if( last_pos.x > max_x_pos )
			{
				last_pos.x = x_min_pos;
				last_pos.y += max_y_add;
				max_y_add = 0;
				if( last_pos.y > 533 )
				{
					last_pos.Set( 735, 35 );
					x_min_pos = 735;
					max_x_pos = 935;
				}
			}

		}
		InitEditorUi();

		if( myBestScore == NULL )
		{
			myBestScore = new CScoreBoard();
			myBestScore->mySprite->Resize( 0.8f, 0.8f );
			myBestScore->mySprite->MoveTo( 462, 530 );
		}

		/*
		types::drag_array t = CreateDragArray
			(	0, 0, 1, 0, 0,
				0, 0, 1, 0, 0,
				0, 1, 1, 0, 0,
				0, 0, 0, 0, 0,
				0, 0, 0, 0, 0 );

								
		CDraggableElement* element = CreateNewDraggableElement( t, types::vector2( 100, 100 ) );
		myDraggableElements.push_back( element );

		element = CreateNewDraggableElement( t, types::vector2( 600, 100 ) );
		myDraggableElements.push_back( element );
		*/

	}

	//============================================================================

	void Update() 
	{
		types::ticks step = myTimer.GetTime();
		myTimer.Reset();

		if( myScoreBoard )
			myScoreBoard->Update();

		if( myBestScore )
			myBestScore->Update();

		types::ticks time_now = SDL_GetTicks();
		for( unsigned int i = 0; i < myAnimationAddQueue.size(); )
		{
			if( time_now >= myAnimationAddQueue[ i ].first )
			{
				myAnimations.push_back( myAnimationAddQueue[ i ].second );
				myAnimationAddQueue[ i ] = myAnimationAddQueue[ myAnimationAddQueue.size() - 1 ];
				myAnimationAddQueue.pop_back();
			}
			else
			{
				++i;
			}
		}

		for( unsigned int i = 0; i < myAnimations.size(); )
		{
			myAnimations[ i ]->Update( step );
			if( myAnimations[ i ]->IsDead() )
			{
				delete myAnimations[ i ];
				myAnimations[ i ] = myAnimations[ myAnimations.size() - 1 ];
				myAnimations.pop_back();
			}
			else
			{
				++i;
			}
		}

		if( myRunningGame ) 
			UpdateGameplay();
	}

	///////////////////////////////////////////////////////////////////////////

	void ToggleGame()
	{
		myGameplayTimer.Reset();

		myRunningGame = !myRunningGame;

		if( myRunningGame )
		{	
			InitInGameUi();
			for( int x = 0; x < types::gameplay_size; ++x )
			{
				for( int y = 0; y < types::gameplay_size; ++y )
				{
					myObjectArray[ y ][ x ] = CreateSinglePieceFrom( myGameplayArray[ y ][ x ], x, y );
				}
			}

			for( unsigned int i = 0; i < myDraggableElements.size();++i )
			{
				myDraggableElements[ i ]->Hide();
			}
			myHaveWeAddedTheThing = false;
		}
		else
		{
			if( myScoreBoard && myBestScore && myScoreBoard->myScore > myBestScore->myScore )
			{
				myBestScore->SetScore( myScoreBoard->myScore );
			}

			InitEditorUi();
			for( unsigned int i = 0; i < myDraggableElements.size();++i )
			{
				myDraggableElements[ i ]->Show();
			}

			for( int x = 0; x < types::gameplay_size; ++x )
			{
				for( int y = 0; y < types::gameplay_size; ++y )
				{
					delete myObjectArray[ y ][ x ];
					myObjectArray[ y ][ x ] = NULL;
				}
			}

			for( unsigned int i = 0; i < myAnimationAddQueue.size(); ++i )
				delete myAnimationAddQueue[ i ].second;
			myAnimationAddQueue.clear();

			for( unsigned int i = 0; i < myAnimations.size(); ++i )
				delete myAnimations[ i ];
			myAnimations.clear();
		}
	}

	//============================================================================

	class CSinglePiece
	{
	public:
		CSinglePiece() : sprite(NULL ), falling( 0 ) { }
		~CSinglePiece() { delete sprite; }
		int play_x;
		int play_y;
		types::sprite sprite;
		int color;
		int falling;
	};

	//============================================================================

	CSinglePiece* CreateSinglePieceFrom( int color, int x, int y  )
	{
		if( color == NULL )
			return NULL;

		CSinglePiece* temp = new CSinglePiece;
		temp->play_x = x;
		temp->play_y = y;
		temp->color = color;
		temp->sprite = GetPieceForType( temp->color );
		temp->falling = 0;

		MoveSpriteToPos( temp->sprite, ConvertGridPosToScreen( temp->play_x, temp->play_y ) );

		return temp;
	}

	//============================================================================

	CSinglePiece* CreateNewFallingPiece()
	{
		CSinglePiece* temp = new CSinglePiece;
		temp->play_x = 6;
		temp->play_y = 0;
		temp->color = this->myFirstDropColor; // random( 1, types::max_colors );
		temp->sprite = GetPieceForType( temp->color );
		temp->falling = 1;
		// mySinglePieces.push_back( temp );

		MoveSpriteToPos( temp->sprite, ConvertGridPosToScreen( temp->play_x, temp->play_y ) );

		return temp;
	}

	//============================================================================

	void StartAnimationSlowly( IAnimationUpdator* who, types::ticks how_long )
	{
		types::ticks time_now = SDL_GetTicks();
		myAnimationAddQueue.push_back( std::pair< types::ticks, IAnimationUpdator* >( time_now + how_long, who ) ); 
	}

	//============================================================================
	
	void MoveSpriteToPos( const types::sprite& sprite, const types::vector2& pos )
	{
		if( sprite )
			sprite->MoveTo( pos.x, pos.y );
	}

	void MoveSpriteSlowlyToPos( const types::sprite& sprite, const types::vector2& pos, types::ticks time )
	{
		if( sprite )
		{
			myAnimations.push_back( new CAnimationMover( sprite, pos.x, pos.y, time ) );
		}
	}

	void RisingScore( int score, const types::vector2& p, types::ticks delay_time )
	{
		const types::ticks death_time = 1500;
		types::vector2 score_target( 292.f, 53.f );
		score_target = score_target + extra_herkku;

		std::stringstream ss;
		ss << ":" << score;
		types::sprite sprite = GetFontSprite( ss.str(), 0.5f, 0.7f );
		sprite->MoveCenterTo( p );

		if( delay_time == 0 )
		{
			// score_target.Set( p.x, p.y - 250.f );
			myAnimations.push_back( new CAnimationMover( sprite, score_target.x, score_target.y, death_time - 100 ) );
			StartAnimationSlowly( new CAnimationFader( sprite, 0.0f, death_time - 100 ), 100 );
			myAnimations.push_back( new CAnimationKiller( sprite, death_time + 500 ) );
			sprite->SetAlpha( 0 );
			myAnimations.push_back(  new CAnimationFader( sprite, 1.0f, 100 ) );
		}
		else
		{
			// score_target.Set( p.x, p.y - 250.f );
			StartAnimationSlowly( new CAnimationMover( sprite, score_target.x, score_target.y, death_time - 100 ), delay_time );
			StartAnimationSlowly( new CAnimationFader( sprite, 0.0f, death_time - 100 ), delay_time + 100 );
			StartAnimationSlowly( new CAnimationKiller( sprite, death_time + 500 ), delay_time );
			sprite->SetAlpha( 0 );
			StartAnimationSlowly( new CAnimationFader( sprite, 1.0f, 100 ), delay_time );

		}
	}

	enum bonus_defs
	{
		bonus_level_cleared = 1,
		bonus_chain_x = 2
	};

	void ShowBonus( int which_bonus, int extra_var = 0 )
	{
		// std::cout << extra_var << std::endl;
		types::sprite left_sprite = NULL;
		types::sprite right_sprite = NULL;
		int score_add = 0;

		if( which_bonus == bonus_level_cleared )
		{
			left_sprite = impl::LoadASprite( "data/gfx/bonus_level.png", 0.8f );
			right_sprite = impl::LoadASprite( "data/gfx/bonus_cleared.png", 0.8f );
			score_add = 15000;

			StartAnimationSlowly( new CAnimationSoundEffect( "data/sfx/bonus_effect.wav" ), 200 );
		}
		else if( which_bonus == bonus_chain_x && extra_var >= 7 )
		{
			float size = (float)extra_var / 15.0f;

			if( size >= 1.0f )
				size = 1.0f;

			score_add = extra_var * 1000;
			left_sprite = impl::LoadASprite( "data/gfx/bonus_chain.png", 0.8f );
			right_sprite = GetChainSpriteFor( extra_var, size );

			if( size < 1.0f )
			{
				left_sprite->Resize( size, size );
				right_sprite->Resize( size, size );
			}
		}

		if( left_sprite && right_sprite )
		{
			const types::ticks play_time = 2500;
			left_sprite->MoveTo( ( -left_sprite->myRect.w * left_sprite->myScaleX ), 200 );
			right_sprite->MoveTo( 1024, 200 );

			myAnimations.push_back( new CAnimationBouncer( left_sprite, 512 - ( ( left_sprite->myRect.w * left_sprite->myScaleX ) + 50 ), 3.0f, play_time ) );
			myAnimations.push_back( new CAnimationBouncer( right_sprite, 512 + 50, 3.0f, play_time ) );

			StartAnimationSlowly( new CAnimationFader( left_sprite, 0.0f, 350 ), play_time );
			StartAnimationSlowly( new CAnimationFader( right_sprite, 0.0f, 350 ), play_time );

			StartAnimationSlowly( new CAnimationResizer( left_sprite, 3.0f, 3.0f, 350 ), play_time );
			StartAnimationSlowly( new CAnimationResizer( right_sprite, 3.0f, 3.0f, 350 ), play_time );

			StartAnimationSlowly( new CAnimationKiller( left_sprite, 350 + 500 ), play_time );
			StartAnimationSlowly( new CAnimationKiller( right_sprite, 350 + 500 ), play_time );

			RisingScore( score_add, types::vector2( 512, 300 ), play_time );
			if( myScoreBoard )
				myScoreBoard->AddScore( score_add );

		}
	}

	void CubeDestruction( const types::sprite& sprite, int score_count )
	{
		const types::ticks death_time = 500;
		if( sprite )
		{
			std::string effect_name = "data/sfx/bling_01.wav";
			types::ticks delay_time = 0;
			if( myCheckingPiecePos.x != 0.0f && myCheckingPiecePos.y != 0.0f )
			{
				types::vector2 delta = myCheckingPiecePos - sprite->GetCenterPos();
				float l = delta.Length();
				if( l > ( types::box_width * 1.5f ) )
				{
					l /= types::box_width;
					int effect_n = (int)l;
					l -= 1.0f;
					delay_time = (types::ticks)( 200.0f * l );
					if( effect_n < 1 ) effect_n = 1;
					if( effect_n > 9 ) effect_n = 9;

					std::stringstream ss; ss << "data/sfx/bling_0" << effect_n << ".wav"; 
					effect_name = ss.str();
				}
			}
			
			if( delay_time == 0 )
			{
				myAnimations.push_back( new CAnimationResizer( sprite, 3.5f, 3.5f, death_time ) );
				myAnimations.push_back( new CAnimationFader( sprite, 0.0f, death_time ) );
				myAnimations.push_back( new CAnimationKiller( sprite, death_time + 500 ) );
				myAnimations.push_back( new CAnimationSoundEffect( effect_name ) );
			}
			else
			{
				StartAnimationSlowly( new CAnimationResizer( sprite, 3.5f, 3.5f, death_time ), delay_time );
				StartAnimationSlowly( new CAnimationFader( sprite, 0.0f, death_time ), delay_time );
				StartAnimationSlowly( new CAnimationKiller( sprite, death_time + 500 ), delay_time );
				StartAnimationSlowly( new CAnimationSoundEffect( effect_name ), delay_time );
			}

			int score = 150 * score_count;
			RisingScore( score, sprite->GetCenterPos(), delay_time );
			if( myScoreBoard )
				myScoreBoard->AddScore( score );
		}
	}

	std::list< CSinglePiece* > mySinglePieceCheckQueue;

	//============================================================================

	bool myHaveWeAddedTheThing;
	int myExtraFallCounter;

	void UpdateGameplay()
	{
		// myObjectArray
		const Uint32 piece_drop_time = 500;
		const Uint32 new_piece_time = 1500;

		if( myGameplayTimer.GetTime() > piece_drop_time )
		{
			bool anything_falling = false;

			for( int y = types::gameplay_size - 1; y >= 0; --y )
			{
				for( int x = types::gameplay_size - 1; x >= 0; --x )
				{
					if( myObjectArray[ y ][ x ] && myObjectArray[ y ][ x ]->falling == 1 )
					{
						anything_falling = true;
						CSinglePiece* current = myObjectArray[ y ][ x ];
						bool r_value = DropSinglePiece( current );
						MoveSpriteSlowlyToPos( current->sprite, ConvertGridPosToScreen( current->play_x, current->play_y ), piece_drop_time - 5  );
						if( current->play_x != x || current->play_y != y )
						{
							myObjectArray[ y ][ x ] = NULL;
							myObjectArray[ current->play_y ][ current->play_x ] = current;
						}
						if( r_value ) 
						{
							current->falling = 0;
							mySinglePieceCheckQueue.push_back( current );
						}
					}
				}
			}

			if( mySinglePieceCheckQueue.empty() == false )
			{
				while( mySinglePieceCheckQueue.empty() == false )
				{
					CSinglePiece* first = mySinglePieceCheckQueue.front();
					mySinglePieceCheckQueue.pop_front();
					CheckForMatches( first );
				}
			}

			if( anything_falling == false  )
			{
				if( myHaveWeAddedTheThing == false )
				{
					CSinglePiece* temp = CreateNewFallingPiece();
					myObjectArray[ temp->play_y ][ temp->play_x ] = temp;
					myHaveWeAddedTheThing = true;
					myExtraFallCounter = 0;
				}
				else
				{
					myExtraFallCounter++;
					if( myExtraFallCounter == 1 )
					{
						bool is_empty = true;
						for( int x = 0; x < types::gameplay_size; ++x )
						{
							for( int y  = 0; y < types::gameplay_size; ++y )
							{
								if( myObjectArray[ y ][ x ] != NULL )
								{
									is_empty = false;
									break;
								}
							}
						}

						if( is_empty )
							ShowBonus( bonus_level_cleared );
					}
					if( myExtraFallCounter == 3 )
					{
						ShowEndScreen();
					}
				}
			}

			myGameplayTimer.Reset();
		}
	}


	void ShowEndScreen()
	{
		if( myScoreBoard && myBestScore && myScoreBoard->myScore > myBestScore->myScore )
		{
			myBestScore->SetScore( myScoreBoard->myScore );
		}
	}

	//============================================================================

	bool IsAcceptableInDestruction( CSinglePiece* p1, CSinglePiece* p2 ) const 
	{ 
		if( p1 == NULL ) return false;
		if( p2 == NULL ) return false;

		if( p2->play_x == p1->play_x && p1->play_y < p2->play_y )
		{
		}
		else if ( p1->falling == 1 )
			return false;

		return( p1->color == p2->color ); 
	}

	//============================================================================

	void RemoveCube( int x, int y, int score_count ) 
	{ 
		CSinglePiece *t = myObjectArray[ y ][ x ];

		bool color_discriminate = true;
		if( t )
		{
			int iy = y;
			for( ; iy >= 0; --iy )
			{
				if( myObjectArray[ iy ][ x ] == NULL )
					break;
				
				if( color_discriminate )
				{
					if( t->color != myObjectArray[ iy ][ x ]->color )
						myObjectArray[ iy ][ x ]->falling = -1;
					else
						color_discriminate = false;
				}
				else
				{
					myObjectArray[ iy ][ x ]->falling = -1;
				}
			}

			std::list< CSinglePiece* >::iterator i;
			for( i = mySinglePieceCheckQueue.begin(); i != mySinglePieceCheckQueue.end(); ++i )
			{
				if( (*i) == t )
				{
					mySinglePieceCheckQueue.erase( i );
					break;
				}
			}

			types::sprite sprite = t->sprite;
			t->sprite = NULL;
			
			CubeDestruction( sprite, score_count );

			delete myObjectArray[ y ][ x ];
			myObjectArray[ y ][ x ] = NULL;
		}
	}

	//============================================================================

	bool CheckHelper( CSinglePiece* piece, int x, int y ) const
	{
		if( x >= 0 && x < types::gameplay_size &&
			y >= 0 && y < types::gameplay_size )
		{
			return IsAcceptableInDestruction( myObjectArray[ y ][ x ], piece );
		}
		else
		{
			return false;
		}
	}

	//============================================================================

	bool IsGoodForPaintJob( CSinglePiece* piece, int x, int y  ) const
	{
		bool result = false;

		result |= CheckHelper( piece, x - 1, y );
		result |= CheckHelper( piece, x + 1, y );
		result |= CheckHelper( piece, x, y + 1 );
		result |= CheckHelper( piece, x, y - 1 );

		return result;
	}

	//============================================================================

	int PaintCheck( CSinglePiece* piece, int x, int y, int score_count )
	{
		if( x >= 0 && x < types::gameplay_size &&
			y >= 0 && y < types::gameplay_size )
		{
			if( IsAcceptableInDestruction( myObjectArray[ y ][ x ], piece ) )
			{
				CSinglePiece* current = myObjectArray[ y ][ x ];
				myObjectArray[ y ][ x ] = NULL;
				
				score_count++;
				int total = 1;
				total += PaintCheck( current, x - 1, y, score_count );
				total += PaintCheck( current, x + 1, y, score_count );
				total += PaintCheck( current, x, y + 1, score_count );
				total += PaintCheck( current, x, y - 1, score_count );
				
				myObjectArray[ y ][ x ] = current;
				RemoveCube( x, y, score_count );


				return total;
			}
			else
			{
				return 0;
			}
		}
		else
		{
			return 0;
		}
	}

	//============================================================================

	// start the explosions and fireworks and shit
	types::vector2 myCheckingPiecePos;
	void CheckForMatches( CSinglePiece* piece ) 
	{
		if( piece == NULL )
			return;

		myObjectArray[ piece->play_y ][ piece->play_x ] = piece;
		if( piece->falling == 1 )
			return;
		
		myCheckingPiecePos.Set( 0.0f, 0.0f );

		if( piece->sprite )
			myCheckingPiecePos = piece->sprite->GetCenterPos();

		if( IsGoodForPaintJob( piece, piece->play_x, piece->play_y ) )
		{
			int s = PaintCheck( piece, piece->play_x, piece->play_y, 0 );

			ShowBonus( bonus_chain_x, s );

			for( int x = 0; x < types::gameplay_size; ++x )
			{
				for( int y = 0; y < types::gameplay_size; ++y )
				{
					if( myObjectArray[ y ][ x ] &&
						myObjectArray[ y ][ x ]->falling == -1 )
						myObjectArray[ y ][ x ]->falling = 1;

				}
			}
		}

		myCheckingPiecePos.Set( 0.0f, 0.0f );

		return;
	}

	//============================================================================

	// returns if it's done falling
	bool DropSinglePiece( CSinglePiece* piece ) 
	{
		int new_x = piece->play_x;
		int new_y = piece->play_y + 1;
		if( new_y >= types::gameplay_size ) return true;

		if( myObjectArray[ new_y ][ new_x ] )
			return true;
		
		piece->play_x = new_x;
		piece->play_y = new_y;

		if( piece->play_x < 0 ) piece->play_x = 0;
		if( piece->play_y < 0 ) piece->play_y = 0;
		if( piece->play_x >= types::gameplay_size ) piece->play_x = types::gameplay_size - 1;
		if( piece->play_y >= types::gameplay_size ) { piece->play_y = types::gameplay_size - 1; return true; }

		return false;
	}

	//============================================================================

	types::timer myTimer;
	types::timer myGameplayTimer;

	typedef ceng::CStaticArray< ceng::CStaticArray< CSinglePiece*, types::gameplay_size >, types::gameplay_size > object_array;

	object_array myObjectArray;
	CSinglePiece* myCurrentPiece;
	std::vector< CSinglePiece* > mySinglePieces;

	//////////////////////////////////////////////////////////////////////////////

	void NewGame() { reset_me = true; }

	void DealWithMouseClick( int cmd )
	{
		switch( cmd )
		{
		case ui_start:
		case ui_stop:
			ToggleGame();
			break;
		case ui_newgame:
			NewGame();
			break;
		default:
			break;
		};
	}

	void OnMouseDown( const types::vector2& v ) 
	{
		for( unsigned int i = 0; i < myUiElements.size(); ++i )
		{
			if( myUiElements[ i ]->MouseDown( v ) )
			{
				DealWithMouseClick( myUiElements[ i ]->myUiId );
				break;
			}
		}
		
		if( myRunningGame ) 
			return;

		if( myCurrentHilight )
		{
			myDraggingElement = myCurrentHilight;
			myDragOffset = myDraggingElement->myPosition - v;

			if( myDraggingElement->myHaveWeBeenAdded )
				myDraggingElement->ReleaseFromGameplayArea( myGameplayArray );
		}
	}

	//----------------------------------------------------------------------------

	void OnMouseUp( const types::vector2& v ) 
	{ 
		if( myRunningGame ) 
			return;

		if( myDraggingElement )
		{
			if( IsAcceptableDragPos( myDraggingElement, false ) )
			{
				myDraggingElement->AddToGameplayArea( myGameplayArray, myDraggingElement->myGameplayX, myDraggingElement->myGameplayY );
			}
				
			myDraggingElement = NULL;
		}
	}

	//----------------------------------------------------------------------------

	void OnMouseMove( const types::vector2& v ) 
	{ 
		for( unsigned int i = 0; i < myUiElements.size(); ++i )
		{
			myUiElements[ i ]->CheckMouseOver( v );
		}

		if( myRunningGame ) 
			return;

		if( myDraggingElement == NULL )
		{
			types::vector2 delta = v - mouse_pos;
			if( delta.LengthSquared() >= 4.0f )
			{
				mouse_pos = v;

				if( myCurrentHilight != NULL )
				{ 
					if( myCurrentHilight->IsMouseOver( mouse_pos ) )
					{
						return;
					}
					else 
					{
						myCurrentHilight->SetHighlight( false );
						myCurrentHilight = NULL;
					}
				}
			
				CDraggableElement* element_at = GetElementAt( mouse_pos );
				if( element_at )
				{
					myCurrentHilight = element_at;
					myCurrentHilight->SetHighlight( true );
				}
			}
		}
		else
		{
			mouse_pos = v;
			myDraggingElement->MoveTo( mouse_pos + myDragOffset );
			IsAcceptableDragPos( myDraggingElement );
		}
	}

	//============================================================================

	bool IsAcceptableDragPos( CDraggableElement* element, bool move_me = true )
	{
		types::vector2 pos = element->myPosition;
		types::vector2 del = pos - myGameplayArrayPos;
		del.x += 0.5f * (float)types::box_width;
		del.y += 0.5f * (float)types::box_height;


		int array_pos_x = (int)( del.x / (float)types::box_width );
		int array_pos_y = (int)( del.y / (float)types::box_height );

		bool value = element->CouldBeAddedToGameplayAt( myGameplayArray, array_pos_x, array_pos_y );

		if( value && move_me )
		{
			types::vector2 p = types::vector2( (float)( array_pos_x * types::box_width ), (float)(array_pos_y * types::box_height) ) + myGameplayArrayPos;
			element->MoveTo( p );
			element->myGameplayX = array_pos_x;
			element->myGameplayY = array_pos_y;
		}

		return value;
	}

	//============================================================================

	CDraggableElement* GetElementAt( const types::vector2& v ) const
	{
		for( unsigned int i = 0; i < myDraggableElements.size(); ++i )
		{
			if( myDraggableElements[ i ]->IsMouseOver( v ) )
				return myDraggableElements[ i ];
		}

		return NULL;
	}

	//============================================================================

	types::vector2 ConvertGridPosToScreen( int x, int y ) const
	{
		return ( types::vector2( (float)( x * types::box_width ), (float)(y * types::box_height) ) + myGameplayArrayPos );
	}

	//============================================================================

	types::sprite background;
	types::vector2 mouse_pos;
	bool mouse_down;

	CDraggableElement* myCurrentHilight;
	CDraggableElement* myDraggingElement;
	types::vector2 myDragOffset;
	std::vector< CDraggableElement* > myDraggableElements;

	types::vector2			myGameplayArrayPos;
	types::gameplay_array	myGameplayArray;

	bool					myRunningGame;


};

///////////////////////////////////////////////////////////////////////////////

CGameplay::CGameplay() : 
	impl( NULL ),
	myStatus( 1 ),
	mySprite( NULL )
{
	mySprite = impl::LoadASprite( "data/gfx/title_screen.jpg", 0.5f );
}

CGameplay::~CGameplay() 
{ 
	delete myBestScore;
	myBestScore = NULL;
}

///////////////////////////////////////////////////////////////////////////////

void CGameplay::Update() 
{ 
	if( impl.get() )
		impl->Update();

	if( reset_me )
	{
		impl.reset( new CGameplayImpl );
		reset_me = false;
	}
}

void CGameplay::OnMouseDown( float x, float y ) 
{ 
	if( impl.get() )
		impl->OnMouseDown( types::vector2( x, y ) );
	else
		ClickNext();
}


void CGameplay::OnMouseUp( float x, float y ) 
{ 
	if( impl.get() )
		impl->OnMouseUp( types::vector2( x, y ) );
}

void CGameplay::OnMouseMove( float x, float y ) 
{ 
	if( impl.get() )
		impl->OnMouseMove( types::vector2( x, y ) );
}

void CGameplay::ToggleGame()
{
	if( impl.get() )
		impl->ToggleGame();
	else
		ClickNext();
}

void CGameplay::ClickNext()
{
	if( myStatus == 1 )
	{
		myStatus = 2;
		delete mySprite;
		mySprite = impl::LoadASprite( "data/gfx/help_screen.jpg", 0.5f );
	}
	else if( myStatus == 2 )
	{
		delete mySprite;
		mySprite = NULL;
		myStatus = 3;
		impl.reset( new CGameplayImpl );
	}
}