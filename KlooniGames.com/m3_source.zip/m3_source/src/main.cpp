#include "graphics.h"
#include "cgameplay.h"

#include <sdl_mixer.h>

#include <vector>

class CPreloader
{
public:
	CPreloader() { }
	~CPreloader() 
	{
		for( unsigned int i = 0; i < mySprites.size(); ++i )
		{
			delete mySprites[ i ];
		}
	}

	void Preload( const std::string& filename )
	{
		mySprites.push_back( new impl::CSprite( filename ) );
	}

	std::vector< impl::CSprite* > mySprites;
};

/*	if( SDL_InitSubSystem( SDL_INIT_AUDIO ) < 0 )
	{
		std::cout << "Ei onnannu " << SDL_GetError() << std::endl;
		exit(1);
	}

	if( Mix_OpenAudio( 44100, AUDIO_S16SYS, 2, 2048 ) < 0)
	{
		std::cout << "Vaara: ei kyetty 44100 Hz 16-bit audioon " << Mix_GetError() << std::endl;
	}

	{
		char s[ 256 ];
		SDL_AudioDriverName( s, 256 );
		std::cout << s << std::endl;
	}

	{
		// allocate 16 mixing channels
		Mix_AllocateChannels(16);
	}

	// volan s��d�t
	{
		// MIX_MAX_VOLUME
		// Mix_Volume(int channel, int volume)
		// Mix_VolumeMusic(int volume)
	}

	Mix_Music* m = NULL;
	m = Mix_LoadMUS("music.xm");

	if(!m) {
		printf("Mix_LoadMUS(\"music.mp3\"): %s\n", Mix_GetError());
	}

	while( SDL_GetTicks() < 200000 )
	{

		if(!Mix_PlayingMusic())
		{
		  // then start playing it.
		  Mix_PlayMusic( m, 0 );
		}
		SDL_Delay( 1 );
	}

	Mix_FreeMusic( m );

		
*/
	// Mix_CloseAudio();
	// SDL_QuitSubSystem( SDL_INIT_AUDIO );

int InitSDLMixer()
{
	if( SDL_InitSubSystem( SDL_INIT_AUDIO ) < 0 )
	{
		std::cout << "Sorry: " << SDL_GetError() << std::endl;
		return 0;
	}

	if( Mix_OpenAudio( 44100, AUDIO_S16SYS, 2, 2048 ) < 0)
	{
		std::cout << "Sorry: can't init 44100 Hz 16-bit audio: " << Mix_GetError() << std::endl;
		return 0;
	}

	{
		char s[ 256 ];
		SDL_AudioDriverName( s, 256 );
		// std::cout << s << std::endl;
	}

	{
		// allocate 16 mixing channels
		Mix_AllocateChannels(16);
	}

	return 1;
}

void ShutDownSDLMixer()
{
	Mix_CloseAudio();
	SDL_QuitSubSystem( SDL_INIT_AUDIO );
}

int main( int argc, char** args )
{
	using namespace impl;

	impl::Direct3DCrap temp = impl::InitStuff( 1024, 600, "M3 - Molesting the Match-3 Market" );
	impl::CRenderer::GetSingletonPtr()->SetDirect3DCrap( temp );
	
	InitSDLMixer();


	CGameplay* gameplay = new CGameplay;

	SDL_Event event;
	bool running = true;
	
	bool mouse_down;
	vector2 mouse_pos;
	mouse_pos.x = 0;
	mouse_pos.y = 0;

	Uint32 last_update = SDL_GetTicks();
	float fps = 0;
	
	CPreloader* preloader = new CPreloader;
	preloader->Preload( "data/gfx/bonus_chain.png" );
	preloader->Preload( "data/gfx/bonus_cleared.png" );
	preloader->Preload( "data/gfx/bonus_level.png" );
	preloader->Preload( "data/gfx/bonus_numbers.png" );

	bool mute = false;

	while( running ) 
	{ 
		if( SDL_GetTicks() - last_update > 16 )
		{
			last_update = SDL_GetTicks();
			gameplay->Update();
			impl::CRenderer::GetSingletonPtr()->Render();
		}

		while( SDL_PollEvent( &event ) ) 
		{
			switch( event.type ) 
			{
				case SDL_KEYDOWN:
					{
						if( event.key.keysym.sym == SDLK_ESCAPE )
							running = false; 

						if( event.key.keysym.sym == SDLK_SPACE )
							gameplay->ToggleGame();
						if( event.key.keysym.sym == SDLK_m )
						{
							mute = !mute;
							MuteAll( mute );
						}

					}
					break;

				case SDL_QUIT:
					running = false;
					break;

				case SDL_MOUSEBUTTONDOWN:
					if( event.button.button == SDL_BUTTON_LEFT )
					{
						mouse_down = true;
						gameplay->OnMouseDown( mouse_pos.x, mouse_pos.y );
					}
					break;

				case SDL_MOUSEBUTTONUP:
					if( event.button.button == SDL_BUTTON_LEFT )
					{
						mouse_down = false;
						gameplay->OnMouseUp( mouse_pos.x, mouse_pos.y );
						// mouse_down = false;
					}
					break;

				case SDL_MOUSEMOTION:
					// mouse_pos.Set( event.motion.x, event.motion.y );
					if( true )
					{
						mouse_pos.x = event.motion.x;
						mouse_pos.y = event.motion.y;
						gameplay->OnMouseMove( mouse_pos.x, mouse_pos.y );

						// AddSomeGround( &myGrid, event.motion.x, event.motion.y );
					}
					break;
			}
		}
	}

	impl::MixerFile::FreeAll();

	delete preloader;
	preloader = NULL;

	delete gameplay;
	gameplay = NULL;

	ShutDownSDLMixer();
	impl::ShutDownD3D( temp );

	return 0;
}