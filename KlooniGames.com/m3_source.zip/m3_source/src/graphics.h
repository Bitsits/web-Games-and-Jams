#ifndef INC_GRAPHICS_H
#define INC_GRAPHICS_H

#pragma comment( lib, "sdl.lib" )
#pragma comment( lib, "sdlmain.lib" )
#pragma comment( lib, "sdl_mixer.lib" )
#pragma comment( lib, "d3d9.lib" )
#pragma comment( lib, "d3dx9.lib" )

#include <sdl.h>
#include <sdl_mixer.h>
#include <d3d9.h>
#include <d3dx9.h>

#include <string>
#include <iostream>
#include <vector>
#include <math.h>

#include "utils/singleton/csingleton.h"
#include "utils/autolist/cautolist.h"

namespace impl {

void MuteAll( bool value );

class MixerFile : public ceng::CAutoList< MixerFile >
{
public:
	MixerFile( const std::string& filename ) 
	{ 
		myMixChunk = NULL;
		myMixChunk = Mix_LoadWAV( filename.c_str() );
		myFilename = filename;

		if( myMixChunk == NULL ) 
		{
			std::cout << "Error! Couldn't load: " << filename << std::endl;
		}
	}

	~MixerFile() 
	{ 
		Mix_FreeChunk( myMixChunk );
		myMixChunk = NULL;
	}

	Mix_Chunk*	myMixChunk;
	std::string	myFilename;

	static MixerFile* GetEffect( const std::string& filename )
	{
		std::list< MixerFile* >& list = ceng::CAutoList< MixerFile >::GetList();
		for( std::list< MixerFile* >::iterator i = list.begin(); i != list.end(); ++i )
		{
			if( (*i)->myFilename == filename )
			{
				return (*i);
			}
		}

		return new MixerFile( filename );
	}

	static void FreeAll()
	{
		while( ceng::CAutoList< MixerFile >::Empty() == false )
		{
			delete CAutoList< MixerFile >::GetList().front();
		}
	}
};

void PreloadEffect( const std::string& file );
void PlayEffect( const std::string& file );

struct vector2
{
	vector2() : x( 0.f ), y( 0.f ) { }
	vector2( float ix, float iy ) : x( ix ), y( iy ) { }

	vector2 operator+ ( const vector2& other ) const 
	{ 
		return vector2( x + other.x, y + other.y ); 
	}

	vector2 operator- ( const vector2& other ) const
	{
		return vector2( x - other.x, y - other.y ); 
	}

	float Length() const { return sqrt( LengthSquared() ); }
	float LengthSquared() const { return x * x + y * y; }
	void Set( float ix, float iy ) { x  = ix; y = iy; }

	float x, y;
};

struct Direct3DCrap
{
	Direct3DCrap() : direct3D_object( 0 ), direct3D_device( 0 ), sprite_device( 0 ) { }

	LPDIRECT3D9 direct3D_object;
	LPDIRECT3DDEVICE9 direct3D_device;
	LPD3DXSPRITE sprite_device;

	static Direct3DCrap* global_impl;
};


Direct3DCrap InitDirect3DCrap( int w, int h );
void InitSDL( int w, int h, const std::string& window_name );
Direct3DCrap InitStuff( int w, int h, const std::string& window_name );
void ShutDownD3D( const Direct3DCrap& crap );

///////////////////////////////////////////////////////////////////////////////

struct CD3DTexture : public ceng::CAutoList< CD3DTexture >
{
	CD3DTexture() : texture( NULL ), width( 0 ), height( 0 ), filename(), reference_count( 0 ) { }
	CD3DTexture( LPDIRECT3DTEXTURE9 texture, int width, int height, const std::string& filename ) : 
		texture( texture ), 
		width( width ), 
		height( height ),
		filename( filename ),
		reference_count( 0 )
	{ 
	}

	~CD3DTexture()
	{
		if( texture )
			texture->Release();
		texture = NULL;
	}

	LPDIRECT3DTEXTURE9 texture;
	int width;
	int height;
	std::string filename;
	int reference_count;
};

CD3DTexture* LoadTexture( const std::string& filename );
void ReleaseTexture( CD3DTexture* texture );

///////////////////////////////////////////////////////////////////////////////

struct Rect
{
	Rect() : x( 0.f ), y( 0.f ), w( 0.f ), h( 0.f ) { }
	Rect( float ix, float iy, float iw, float ih ) : x( ix ), y( iy ), w( iw ), h( ih ) { }
	float x, y, w, h;

	void Set( float ix, float iy, float iw, float ih ) { x = ix; y = iy; w = iw; h = ih; }

	bool IsPointInside( const vector2& p ) const
	{
		return( this->x <= p.x && this->x + this->w > p.x && this->y <= p.y && this->y + this->h > p.y );
	}
};

///////////////////////////////////////////////////////////////////////////////

class CSprite;
void RemoveFromRenderer( CSprite* sprite );

///////////////////////////////////////////////////////////////////////////////

class CSprite
{
public:
	CSprite() :
		myRotation( 0.f ),
		myScaleX( 1.0f ),
		myScaleY( 1.0f ),
		myRect(),
		myInImageRect(),
		myAlpha( 1.0f ),
		myTexture( NULL ),
		myZValue( 0.5f ),
		myHidden( false )
	{
	}

	CSprite( const std::string& filename ) :
		myRotation( 0.f ),
		myScaleX( 1.0f ),
		myScaleY( 1.0f ),
		myRect(),
		myInImageRect(),
		myAlpha( 1.0f ),
		myTexture( NULL ),
		myZValue( 0.5f ),
		myHidden( false )
	{
		LoadMeImage( filename );
	}

	virtual ~CSprite() 
	{ 
		ReleaseTexture( myTexture ); 
		myTexture = NULL; 
		RemoveFromRenderer( this );
	}

	void LoadMeImage( const std::string& file ) 
	{
		ReleaseTexture( myTexture );
		myTexture = LoadTexture( file );
		if( myTexture )
		{
			myRect.w = (float)myTexture->width;
			myRect.h = (float)myTexture->height;
			myInImageRect.Set( 0, 0, (float)myTexture->width, (float)myTexture->height );
		}
	}

	void Resize( float x, float y ) { myScaleX = x; myScaleY = y; }
	void SetAlpha( float alpha ) { myAlpha = alpha; }
	void RotateTo( float angle ) { myRotation = angle; }
	virtual void MoveTo( float x, float y )
	{
		myRect.x = x;
		myRect.y = y;
	}

	vector2 GetCenterPos() const 
	{
		return vector2( myRect.x + ( myRect.w * myScaleX * 0.5f ), myRect.y + ( myRect.h * myScaleY * 0.5f ) );
	}

	void MoveCenterTo( const vector2& p ) { MoveCenterTo( p.x, p.y ); }

	void MoveCenterTo( float x, float y )
	{
		MoveTo( x - ( myRect.w * myScaleX * 0.5f ), y - ( myRect.h * myScaleY * 0.5f ) );
	}

	void MoveBy( float x, float y )
	{
		MoveTo( myRect.x + x, myRect.y + y );
	}

	float GetZValue() const { return myZValue; }

	float myRotation;
	float myScaleX;
	float myScaleY;
	Rect myRect;
	Rect myInImageRect;
	float myAlpha;
	CD3DTexture* myTexture;
	float myZValue;
	bool myHidden;

	void Hide();
	void Show();

	virtual void Render( const Direct3DCrap& crap ) 
	{ 
		if( myTexture == NULL ||
			myTexture->texture == NULL )
			return;

		D3DXMATRIX mat;
		{

			/*CCameraResult result = Gfx::GetCamera()->Transform( 
				CRect< float >( (float)target_rect.x, (float)target_rect.y, (float)(target_rect.w), (float)(target_rect.h)  ),
				myRotation );*/

			float rotation = myRotation;
			D3DXVECTOR2 scaling( 0, 0 );
				
			scaling.x = myScaleX;
			scaling.y = myScaleY;

			D3DXVECTOR2 trans = D3DXVECTOR2( myRect.x, myRect.y );
			D3DXVECTOR2 center = D3DXVECTOR2( myRect.w * 0.5f, myRect.h * 0.5f );

			RECT srcRect;
			srcRect.left   = (long)myInImageRect.x;
			srcRect.top    = (long)myInImageRect.y;
			srcRect.right	= (long)( myInImageRect.x + myInImageRect.w );
			srcRect.bottom  = (long)( myInImageRect.y + myInImageRect.h );

			float alpha = myAlpha;

			// out, scaling centre, scaling rotation, scaling, rotation centre, rotation, translation
			float scaling_rotation = 0.0f;
			D3DXMatrixTransformation2D( &mat, NULL, scaling_rotation, &scaling, &center, rotation, &trans );

			crap.sprite_device->SetTransform( &mat );

			crap.sprite_device->Draw( myTexture->texture, 
								&srcRect,
								NULL,
								NULL,
								D3DCOLOR_COLORVALUE(1.0f,1.0f,1.0f, alpha ) );
		}
	}
};

class CSpriteText : public CSprite
{
public:
	CSpriteText() : CSprite() { }
	CSpriteText( const std::string& filename ) : CSprite( filename ) { }
	~CSpriteText() { }

	vector2 myCharacterExtents;
	char myStarttingChar;
	void SetCharacterSettings( const vector2& char_extents, char startting_char )
	{
		myCharacterExtents = char_extents;
		myStarttingChar = startting_char;

		myRect.w = char_extents.x;
		myRect.h = char_extents.y;
	}

	void SetText( const std::string& text )
	{
		myInRects.clear();
		for( unsigned int i = 0; i < text.size(); ++i )
		{
			int p = (int)( text[ i ] - myStarttingChar );
			Rect r( p * myCharacterExtents.x, 0, myCharacterExtents.x, myCharacterExtents.y );
			myInRects.push_back( r );
		}
	}

	virtual void Render( const Direct3DCrap& crap ) 
	{
		if( myTexture == NULL ||
			myTexture->texture == NULL )
			return;

		float add_all = 0;
		Rect current;
		D3DXMATRIX mat;
		for( unsigned int i = 0; i < myInRects.size(); ++i )
		{
			current = myInRects[ i ];
			/*CCameraResult result = Gfx::GetCamera()->Transform( 
				CRect< float >( (float)target_rect.x, (float)target_rect.y, (float)(target_rect.w), (float)(target_rect.h)  ),
				myRotation );*/

			float rotation = myRotation;
			D3DXVECTOR2 scaling( 0, 0 );
				
			scaling.x = myScaleX;
			scaling.y = myScaleY;

			D3DXVECTOR2 trans = D3DXVECTOR2( myRect.x + add_all, myRect.y );
			D3DXVECTOR2 center = D3DXVECTOR2( current.w * 0.5f, current.h * 0.5f );

			RECT srcRect;
			srcRect.left   = (long)current.x;
			srcRect.top    = (long)current.y;
			srcRect.right	= (long)( current.x + current.w );
			srcRect.bottom  = (long)( current.y + current.h );

			float alpha = myAlpha;

			// out, scaling centre, scaling rotation, scaling, rotation centre, rotation, translation
			float scaling_rotation = 0.0f;
			D3DXMatrixTransformation2D( &mat, NULL, scaling_rotation, &scaling, &center, rotation, &trans );

			crap.sprite_device->SetTransform( &mat );

			crap.sprite_device->Draw( myTexture->texture, 
								&srcRect,
								NULL,
								NULL,
								D3DCOLOR_COLORVALUE(1.0f,1.0f,1.0f, alpha ) );

			add_all += ( current.w * myScaleX );
		}
	}

	std::vector< Rect > myInRects;
};

///////////////////////////////////////////////////////////////////////////////

class CRenderer : public ceng::CSingleton< CRenderer > 
{
public:
	void SetDirect3DCrap( const Direct3DCrap& crap ) { myCrap = crap; }

	~CRenderer() 
	{ 
	}
	
	void Render() 
	{
		myCrap.direct3D_device->Clear( 0, NULL, D3DCLEAR_TARGET, D3DCOLOR_ARGB( 255, 0, 0, 0 ), 1.0f, 0 );
		
		if( myCrap.direct3D_device->TestCooperativeLevel() !=  D3D_OK )
			std::cout << "TestCooperativeLevel() failed - " << myCrap.direct3D_device->TestCooperativeLevel() << std::endl;

		if( myCrap.direct3D_device->BeginScene() == D3DERR_INVALIDCALL )
			std::cout << "BeginScene failed" << std::endl;

		myCrap.sprite_device->Begin( D3DXSPRITE_ALPHABLEND );

		// render all
		for( std::list< CSprite* >::iterator i = mySprites.begin(); i != mySprites.end(); ++i )
		{
			(*i)->Render( myCrap );
		}

		myCrap.sprite_device->End();
		myCrap.direct3D_device->EndScene();							
		myCrap.direct3D_device->Present(NULL,NULL,NULL,NULL);
	}

	std::list< CSprite* > mySprites;

private:
	Direct3DCrap myCrap;
	friend class ceng::CSingleton< CRenderer >;
};

///////////////////////////////////////////////////////////////////////////////

CSprite* LoadASprite( const std::string& filename, float z_value = 0.5f );

void AddToRenderer( CSprite* sprite );
void RemoveFromRenderer( CSprite* sprite );


///////////////////////////////////////////////////////////////////////////////

} // end o namespace impl

#endif
