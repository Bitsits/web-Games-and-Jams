#include "csingleton.h"

namespace ceng {
	
class T;
T* CStaticSingleton< T >::myInstance = 0;

}