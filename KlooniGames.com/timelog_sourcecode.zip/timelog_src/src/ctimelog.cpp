#include "ctimelog.h"
#include "xml/cxml.h"

#include <assert.h>

namespace timelog {
///////////////////////////////////////////////////////////////////////////////

void CTimeLog::Entry::Serialize( ceng::CXmlFileSys* filesys )
{
	XML_BindAttribute( filesys, name );
	XML_BindAlias( filesys, time, "StartTime" );
	XML_BindAlias( filesys, end_time, "EndTime" );
}

///////////////////////////////////////////////////////////////////////////////

void CTimeLog::WorkingNowOn( const std::string& entryname )
{
	if( myEntries.empty() == false )
	{
		myEntries.begin()->EndEntry();
	}

	myEntries.push_front( Entry( entryname ) );
}

//=============================================================================

void CTimeLog::TakeABreak( const std::string& reason )
{
	if( myEntries.empty() == false )
	{
		myEntries.begin()->EndEntry();
	}

	myEntries.push_front( Entry( reason, Entry::entry_break ) );
}

void CTimeLog::AddEntry( const CTimeLog::Entry& t )
{
	myEntries.push_front( t );
}

bool CTimeLog::OnABreak() const
{
	if( myEntries.empty() == false )
		return ( myEntries.front().entry_type == Entry::entry_break );

	return false;
}

//=============================================================================

void CTimeLog::EndBreak()
{
	if( myEntries.empty() == false )
	{
		myEntries.begin()->EndEntry();

		std::list< Entry >::iterator i;
		for( i = myEntries.begin(); i != myEntries.end() && i->entry_type == Entry::entry_break; ++i ) { }
		
		if( i != myEntries.end() && i->entry_type != Entry::entry_break )
		{
			myEntries.push_front( Entry( i->GetName() ) );
		}
		

	}
}

//=============================================================================

void CTimeLog::UndoLastEntry()
{
	if( myEntries.empty() == false )
	{
		myEntries.pop_front();
	}
}

///////////////////////////////////////////////////////////////////////////////

const std::list< CTimeLog::Entry >& CTimeLog::GetEntryList() const
{
	return myEntries;
}

//=============================================================================

CTimeLog::Entry  CTimeLog::GetCurrentEntry() const
{
	Entry return_value;

	if( myEntries.empty() == false )
	{
		return_value = *myEntries.begin();
	}

	return return_value;
	
}

///////////////////////////////////////////////////////////////////////////////

void CTimeLog::LoadProject( const std::string& project )
{
	ceng::XmlLoadFromFile( *this, project, "TimeLog" );
}

//=============================================================================

void CTimeLog::SaveProject( const std::string& project )
{
	if( myEntries.empty() == false )
	{
		myEntries.begin()->EndEntry();
	}

	ceng::XmlSaveToFile( *this, project, "TimeLog" );
}

///////////////////////////////////////////////////////////////////////////////

void CTimeLog::Clear()
{
	if( myEntries.empty() == false )
		myEntries.clear();

	assert( myEntries.empty() );
}

///////////////////////////////////////////////////////////////////////////////

void CTimeLog::Serialize( ceng::CXmlFileSys* filesys )
{
	if( filesys->IsWriting() )
	{
		filesys->AddElement( "Entries" );

		std::list< CTimeLog::Entry >::iterator i;
		for( i = myEntries.begin(); i != myEntries.end(); ++i )
		{
			std::string name = ( i->entry_type == Entry::entry_subtask )?"Task":"Break";
			filesys->GetNode()->AddChild( ceng::XmlConvertFrom( (*i), name ) );
		}

		filesys->EndElement( "Entries" );
	
	}
	else if ( filesys->IsReading() )
	{
		if( myEntries.empty() == false && myUnload )
			myEntries.clear();

		ceng::CXmlNode* entries = filesys->FindChildByName( "Entries" );
		if( entries )
		{
			int i = 0;
			for( i = 0; i < entries->GetChildCount(); i++ )
			{
				if( entries->GetChild( i )->GetName() == "Task" || entries->GetChild( i )->GetName() == "Break" ) 
				{
					
					Entry temp;
					ceng::XmlConvertTo( entries->GetChild( i ), temp );
					temp.entry_type = entries->GetChild( i )->GetName() == "Task"?Entry::entry_subtask:Entry::entry_break;
					myEntries.push_back( temp );
				}
			}
		}
		

	}
}
	
///////////////////////////////////////////////////////////////////////////////
} // end of namespace timelog