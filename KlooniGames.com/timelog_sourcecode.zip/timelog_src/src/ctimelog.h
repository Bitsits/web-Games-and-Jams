#ifndef INC_CTIMELOG_H
#define INC_CTIMELOG_H

#include <string>
#include <list>

#include "cdate.h"

namespace ceng {
	class CXmlFileSys;
}

namespace timelog {

class CTimeLog
{
public:

	//=========================================================================

	struct Entry
	{
		enum EntryType
		{
			entry_subtask = 0,
			entry_break = 1
		};

		Entry() : name(), time(), end_time(), entry_type( entry_subtask ) { }

		Entry( const std::string& entryname, EntryType entry_type = entry_subtask ) :
			name( entryname ),
			time(),
			end_time(),
			entry_type( entry_type )
		{
		}

		Entry( const Entry& other ) :
			name( other.name ),
			time( other.time ),
			end_time( other.end_time ),
			entry_type( other.entry_type )
		{
		}

		bool operator<( const Entry& other ) const
		{
			return time < other.time;
		}

		bool operator==( const Entry& other ) const
		{
			return ( name == other.name && 
				time == other.time && 
				end_time == other.end_time && 
				entry_type == other.entry_type );
		}

		const Entry& operator=( const Entry& other ) 
		{
			name = other.name;
			time = other.time;
			end_time = other.end_time;
			entry_type = other.entry_type;

			return *this;
		}

		CDate GetDuration() const
		{
			return end_time - time;
		}

		void EndEntry()
		{
			end_time = CDate();
		}

		std::string GetName() const
		{
			return name;
		}

		CDate GetBeginTime() const
		{
			return time;
		}

		CDate GetEndTime() const
		{
			return end_time;
		}

		void Serialize( ceng::CXmlFileSys* filesys );

		std::string		name;		// const
		CDate			time;		// const
		CDate			end_time;
		EntryType		entry_type;
	};

	//=========================================================================

	CTimeLog() : myUnload( true ) { }
	~CTimeLog() { }

	void Serialize( ceng::CXmlFileSys* filesys );

	void LoadProject( const std::string& project );
	void SaveProject( const std::string& project );

	void WorkingNowOn( const std::string& task );
	void TakeABreak( const std::string& reason );
	void EndBreak();
	bool OnABreak() const;
	void UndoLastEntry();

	void SetUnloading( bool unload ) { myUnload = unload; }
	bool GetUnloading() const { return myUnload; }
	void Clear();

	void AddEntry( const Entry& t );

	const std::list< Entry >&	GetEntryList() const;
	Entry						GetCurrentEntry() const;

private:
	std::list< Entry >	myEntries;
	bool				myUnload;
};

} // end of namespace timelog

#endif