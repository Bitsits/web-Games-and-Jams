//  clrscr.h

//

//  adapted from 

//  Vincent Fatica

//  vefatica@syr.edu

//  Syracuse University Mathematics

//  http://barnyard.syr.edu/~vefatica/

//

//  by Shannon Bauman

//  August 9, 1998

//

//  clear entire console screen buffer



#ifndef CLRSCR_H

#define CLRSCR_H



int clrscr();



// #include "clrscr.cpp"



#endif