#include "../tester/ctester.h"
#include "../cdate.h"
#include "../xml/cxml.h"

namespace timelog {
namespace test {

int CDateTester()
{
	// some basics
	{
		const CDate date1;
		const CDate date2 = date1;

		test_assert( date1 == date2 );
		test_assert( date2 == date1 );

		test_float( date1.InSeconds() == date2.InSeconds() );
		test_float( date1.InMinutes() == date2.InMinutes() );
		test_float( date1.InHours() == date2.InHours() );
		test_float( date1.InDays() == date2.InDays() );
		test_float( date1.InWeeks() == date2.InWeeks() );
		test_float( date1.InMonths() == date2.InMonths() );
		test_float( date1.InYears() == date2.InYears() );

		// Operator testing
		{
			//             2 = 6 - 4
			CDate date_minus = date2 - date1;

			//			 6 = 4 + 2
			test_assert( date2 == date1 + date_minus );
			
			//			 4 = 6 - 2
			test_assert( date1 == date2 - date_minus );
			
			//			 2 = 6 - 4
			test_assert( date_minus == date2 - date1 );

			{
				CDate tmp_date_add = date1;
				tmp_date_add += date2;
				
				test_assert( tmp_date_add == date1 + date2 );

				CDate tmp_date_min = date2;
				tmp_date_min -= date1;

				test_assert( tmp_date_min == date2 - date1 ); 
				test_assert( tmp_date_min == date_minus );
			}

			{
				test_assert( date_minus < date1 );
				test_assert( date_minus < date2 );
				test_assert( date_minus <= date1 );
				test_assert( date_minus <= date2 );
				
				test_assert( date1 > date_minus );
				test_assert( date2 > date_minus );
				test_assert( date1 >= date_minus );
				test_assert( date2 >= date_minus );
			}
		}
		
		const CDate date_minus = date2 - date1;
		test_float( date_minus.InSeconds() == 0 );
		test_float( date_minus.InMinutes() == 0 );
		test_float( date_minus.InHours() == 0 );
		test_float( date_minus.InDays() == 0 );
		test_float( date_minus.InWeeks() == 0 );
		test_float( date_minus.InMonths() == 0 );
		test_float( date_minus.InYears() == 0 );

		test_assert( date_minus.GetSeconds() == 0 );
		test_assert( date_minus.GetMinutes() == 0 );
		test_assert( date_minus.GetHours() == 0 );
		test_assert( date_minus.GetWeeks() == 0 );
		test_assert( date_minus.GetMonths() == 0 );
		test_assert( date_minus.GetYears() == 0 );

		// Time testing
		{
			test_float( date1.InSeconds() / 60.0 == date1.InMinutes() );
			test_float( date1.InMinutes() / 60.0 == date1.InHours() );
			test_float( date1.InHours() / 24.0 == date1.InDays() );
			test_float( date1.InDays() / 7.0 == date1.InWeeks() );
			test_float( date1.InYears() * 12.0 == date1.InMonths() );
			test_float( date1.InMonths() / 12.0 == date1.InYears() );
		}

	}

	// testing serialization
	{
		const CDate test_me_const;
		CDate test_me = test_me_const;

		test_assert( test_me_const == test_me );
		test_assert( test_me == test_me_const );
		
		ceng::XmlSaveToFile( test_me, "temp/cdate_test.xml", "date" );

		test_assert( test_me_const == test_me );
		test_assert( test_me == test_me_const );
		
		test_me -= test_me_const;

		test_assert( test_me_const != test_me );
		test_assert( test_me != test_me_const );
		
		ceng::XmlLoadFromFile( test_me, "temp/cdate_test.xml", "date" );
		
		test_assert( test_me_const == test_me );
		test_assert( test_me == test_me_const );
	}

	return 0;
}

TEST_REGISTER( CDateTester );
} // end of namespace test
} // end of namespace timelog
