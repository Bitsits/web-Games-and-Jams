#include "../tester/ctester.h"
#include "../ctimelog.h"
#include "../xml/cxml.h"

namespace timelog {
namespace test {

template< class Container >
bool test_containers( const Container& t1, const Container& t2 )
{
	Container::const_iterator i1;
	Container::const_iterator i2;

	for( i1 = t1.begin(), i2 = t2.begin(); i1 != t1.end() && i2 != t2.end(); ++i1, ++i2 )
	{
		if( !( (*i1) == (*i2) ) ) 
			return false;
	}

	if( i1 != t1.end() ) return false;
	if( i2 != t2.end() ) return false;

	return true;
}

#include <list>
#include <vector>

int test_containersTester()
{
	{
		std::list< int > test1;	
		std::list< int > test2;

		test_assert( test_containers( test1, test2 ) );

		test1.push_back( 1 );
		test_assert( test_containers( test1, test2 ) == false  );

		test2.push_back( 1 );
		test_assert( test_containers( test1, test2 ) );

		test1.push_back( 2 );
		test_assert( test_containers( test1, test2 ) == false  );

		test2.push_back( 1 );
		test_assert( test_containers( test1, test2 ) == false );

	}

	{
		std::vector< int > test1;	
		std::vector< int > test2;

		test_assert( test_containers( test1, test2 ) );

		test1.push_back( 1 );
		test_assert( test_containers( test1, test2 ) == false  );

		test2.push_back( 1 );
		test_assert( test_containers( test1, test2 ) );

		test1.push_back( 2 );
		test_assert( test_containers( test1, test2 ) == false  );

		test2.push_back( 1 );
		test_assert( test_containers( test1, test2 ) == false );
	}


	return 0;
}

TEST_REGISTER( test_containersTester );

int CTimeLogTester()
{
	{
		CTimeLog timelog;
		
		const CDate now;
		timelog.WorkingNowOn( "test-me" );

		test_assert( timelog.GetEntryList().begin()->GetName() == "test-me" );
		test_assert( timelog.GetEntryList().begin()->GetBeginTime() == now );

		const CDate now2;

		timelog.WorkingNowOn( "test-me2" );

		test_assert( timelog.GetEntryList().begin()->GetName() == "test-me2" );
		test_assert( timelog.GetEntryList().begin()->GetBeginTime() == now2 );

		test_assert( (++timelog.GetEntryList().begin())->GetName() == "test-me" );
		test_assert( (++timelog.GetEntryList().begin())->GetBeginTime() == now );
		test_assert( (++timelog.GetEntryList().begin())->GetEndTime() == now2 );
		test_assert( (++timelog.GetEntryList().begin())->GetDuration() == now2 - now );
	}

	{
		CTimeLog timelog;
		
		timelog.WorkingNowOn( "ceng" );
		test_assert( timelog.GetEntryList().begin()->GetName() == "ceng" );
		test_assert( timelog.GetEntryList().begin()->GetBeginTime() == CDate() );

		timelog.WorkingNowOn( "inva" );
		test_assert( timelog.GetEntryList().begin()->GetName() == "inva" );
		test_assert( timelog.GetEntryList().begin()->GetBeginTime() == CDate() );

		timelog.TakeABreak( "coffee" );
		test_assert( timelog.GetEntryList().begin()->GetName() == "coffee" );
		test_assert( timelog.GetEntryList().begin()->GetBeginTime() == CDate() );
		timelog.EndBreak();

		test_assert( timelog.GetEntryList().begin()->GetName() == "inva" );
		test_assert( timelog.GetEntryList().begin()->GetBeginTime() == CDate() );

		timelog.WorkingNowOn( "ceng" );

		test_assert( timelog.GetEntryList().begin()->GetName() == "ceng" );
		test_assert( timelog.GetEntryList().begin()->GetBeginTime() == CDate() );

		timelog.TakeABreak( "toilet" );
		test_assert( timelog.GetEntryList().begin()->GetName() == "toilet" );
		test_assert( timelog.GetEntryList().begin()->GetBeginTime() == CDate() );
		timelog.EndBreak();

		test_assert( timelog.GetEntryList().begin()->GetName() == "ceng" );
		test_assert( timelog.GetEntryList().begin()->GetBeginTime() == CDate() );

		timelog.UndoLastEntry();
		test_assert( timelog.GetEntryList().begin()->GetName() == "toilet" );
		test_assert( timelog.GetEntryList().begin()->GetBeginTime() == CDate() );

	}

	// EndBreak bugi
	{	
		CTimeLog timelog;
		
		timelog.WorkingNowOn( "ceng" );
		test_assert( timelog.GetEntryList().begin()->GetName() == "ceng" );
		test_assert( timelog.GetEntryList().begin()->GetBeginTime() == CDate() );

		timelog.TakeABreak( "coffee" );
		test_assert( timelog.GetEntryList().begin()->GetName() == "coffee" );
		test_assert( timelog.GetEntryList().begin()->GetBeginTime() == CDate() );

		timelog.TakeABreak( "coffee + pelit" );
		test_assert( timelog.GetEntryList().begin()->GetName() == "coffee + pelit" );
		test_assert( timelog.GetEntryList().begin()->GetBeginTime() == CDate() );

		timelog.EndBreak();
		test_assert( timelog.GetEntryList().begin()->GetName() == "ceng" );
		test_assert( timelog.GetEntryList().begin()->GetBeginTime() == CDate() );

	}

	// serialization test
	{
		CTimeLog timelog;

		timelog.WorkingNowOn( "a1" );
		timelog.WorkingNowOn( "b2" );
		timelog.TakeABreak( "coffee" );
		timelog.EndBreak();
		timelog.WorkingNowOn( "c3" );
		timelog.WorkingNowOn( "e4" );

		std::list< CTimeLog::Entry > test_me = timelog.GetEntryList();
		test_assert( test_containers( test_me, timelog.GetEntryList() ) );
		
		ceng::XmlSaveToFile( timelog, "temp/ctimelog_temp.xml", "TimeLog" );

		test_assert( test_containers( test_me, timelog.GetEntryList() ) );

		timelog.WorkingNowOn( "g2" );
		timelog.WorkingNowOn( "e2" );
		timelog.TakeABreak( "coffee" );
		timelog.EndBreak();
		timelog.WorkingNowOn( "f2" );
		timelog.WorkingNowOn( "a2" );

		test_assert( test_containers( test_me, timelog.GetEntryList() ) == false );

		ceng::XmlLoadFromFile( timelog, "temp/ctimelog_temp.xml", "TimeLog" );

		test_assert( test_containers( test_me, timelog.GetEntryList() ) );

		{
			CTimeLog templog;
			ceng::XmlLoadFromFile( templog, "temp/ctimelog_temp.xml", "TimeLog" );

			test_assert( test_containers( test_me, templog.GetEntryList() ) );
		}
	}

	// serialization test
	{
		CTimeLog timelog;

		timelog.WorkingNowOn( "a1" );
		timelog.WorkingNowOn( "b2" );
		timelog.TakeABreak( "coffee" );
		timelog.EndBreak();
		timelog.WorkingNowOn( "c3" );
		timelog.WorkingNowOn( "e4" );

		std::list< CTimeLog::Entry > test_me = timelog.GetEntryList();
		test_assert( test_containers( test_me, timelog.GetEntryList() ) );
		
		timelog.SaveProject( "temp/ctimelog_temp2.xml" );

		test_assert( test_containers( test_me, timelog.GetEntryList() ) );

		timelog.WorkingNowOn( "g2" );
		timelog.WorkingNowOn( "e2" );
		timelog.TakeABreak( "coffee" );
		timelog.EndBreak();
		timelog.WorkingNowOn( "f2" );
		timelog.WorkingNowOn( "a2" );

		test_assert( test_containers( test_me, timelog.GetEntryList() ) == false );

		timelog.LoadProject( "temp/ctimelog_temp2.xml" );

		test_assert( test_containers( test_me, timelog.GetEntryList() ) );

		{
			CTimeLog templog;
			templog.LoadProject( "temp/ctimelog_temp2.xml" );

			test_assert( test_containers( test_me, templog.GetEntryList() ) );
		}
	}
	return 0;
}

TEST_REGISTER( CTimeLogTester );

} // end of namespace test
} // end of namespace timelog