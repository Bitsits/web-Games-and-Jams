#ifndef INC_CDATE_H
#define INC_CDATE_H

#include <string>

namespace ceng {
class CXmlFileSys;
}

namespace timelog {

//! A minimalistic date presentation.
/*!

*/
class CDate
{
public:
	CDate();
	CDate( const CDate& other );
	~CDate();

	CDate& operator= ( const CDate& other );

	bool operator== ( const CDate& other ) const;
	bool operator!= ( const CDate& other ) const;

	bool operator< ( const CDate& other ) const;
	bool operator> ( const CDate& other ) const;
	bool operator<=( const CDate& other ) const;
	bool operator>=( const CDate& other ) const;

	CDate operator- ( const CDate& other ) const;
	CDate operator+ ( const CDate& other ) const;
	CDate& operator-=( const CDate& other );
	CDate& operator+=( const CDate& other );


	int			GetYears() const;
	int			GetMonths() const;
	int			GetWeeks() const;
	int			GetDays() const;
	int			GetHours() const;
	int			GetMinutes() const;
	int			GetSeconds() const;

	double		InYears() const;
	double		InMonths() const;
	double		InWeeks() const;
	double		InDays() const;
	double		InHours() const;
	double		InMinutes() const;
	double		InSeconds() const;

	std::string AsString() const;

	void Serialize( ceng::CXmlFileSys* filesys );

private:
	int myYears;
	int myMonths;
	int myWeeks;
	int myDays;
	int myHours;
	int myMinutes;
	int mySeconds;
};

} // end of namespace timelog

#endif