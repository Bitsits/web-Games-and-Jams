#include <windows.h>
#include <iostream>
#include <string>
#include <math.h>
#include <memory>

#include "tester/tester_console.h"
#include "ctimelogapplication.h"
#include "clrscr.h"

using namespace timelog;

CTimeLogApplication* application = NULL;

// console handler code ripped from http://www.codeproject.com/win32/console_event_handling.asp
BOOL WINAPI ConsoleHandler(DWORD CEvent)
{
    switch(CEvent)
    {
    case CTRL_CLOSE_EVENT:
		if( application )
			application->Save();
		return false;
        break;

    }
    return false;
}

int main( int argc, char** args )
{
	// runs the unit tests, they break only in debug mode
	// RunTests();
	
	clrscr();
	
	{
		application = new CTimeLogApplication(argc,args);
		if (SetConsoleCtrlHandler(
			(PHANDLER_ROUTINE)ConsoleHandler,TRUE)==FALSE)
		{
			// unable to install handler... 
			// display message to the user
			printf("Unable to install handler!\n");
			return -1;
		}

		application->Run();
	}

	delete application;
	application = NULL;
	
	
	return 0;
}

