// Split.h
#ifndef INC_SPLIT_H
#define INC_SPLIT_H

// +----------------------------------------------------------------------+
// | Split 1.1                                                            |
// +----------------------------------------------------------------------+
// | You are free to use this as you wish.	                              |					
// |                                         	                          |
// | the original files can be found at      	                          |
// | http://koti.mbnet.fi/kumikana/soodaus/cpp/Split/                     |              
// |                                         	                          |
// |  Original files:                        	                          |
// |   split.h                              	                          |
// |   split.cpp                             	                          |
// |   example.cpp                           	                          |
// |                                         	                          |
// +----------------------------------------------------------------------+
// | Coded by Petri Purho < pete @ markkupurho.fi >                       |
// +----------------------------------------------------------------------+

#pragma warning(disable:4786) // Poistaa ilkeet warningit mit� stl antaa jos k�ytt�� stringi�

#include <vector>
#include <string>

// This thing works the same way as PHP explode
// It cuts up the _string with _separator and
// pushes the peaces into a vector and returns
// that vector.
//
// Description of explode from php.net
//
// Returns an array of strings, each of which is a 
// substring of string formed by splitting it on 
// boundaries formed by the string separator. 
std::vector <std::string> Split( const std::string& _separator, std::string _string );

// If limit is set, the returned array will contain a 
// maximum of limit elements with the last element 
// containing the rest of string. 
std::vector <std::string> Split( const std::string& _separator, std::string _string, int _limit );


#endif