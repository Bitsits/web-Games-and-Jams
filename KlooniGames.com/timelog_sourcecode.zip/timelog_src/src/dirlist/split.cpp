//
// +----------------------------------------------------------------------+
// | Split 1.1                                                            |
// +----------------------------------------------------------------------+
// | You are free to use this as you wish.	                              |					
// |                                         	                          |
// | the original files can be found at      	                          |
// | http://koti.mbnet.fi/kumikana/soodaus/cpp/Split/                     |              
// |                                         	                          |
// |  Original files:                        	                          |
// |   split.h                              	                          |
// |   split.cpp                             	                          |
// |   example.cpp                           	                          |
// |                                         	                          |
// +----------------------------------------------------------------------+
// | Coded by Petri Purho < pete @ markkupurho.fi >                       |
// +----------------------------------------------------------------------+
//

#include "split.h"

std::vector <std::string> Split( const std::string& _separator, std::string _string )
{

	std::vector <std::string> array;

	size_t position;
	
	// we will find the position of first of the separators
	position = _string.find_first_of( _separator );
	
	// We will loop true this until there are no separators left
	// in _string
	while ( position != _string.npos )
	{
	
		// This thing here checks that we dont push empty strings
		// to the array
		if ( position != 0 )
			array.push_back( _string.substr( 0, position ) );

		// When the cutted part is pushed into the array we
		// remove it and the separator from the _string
		_string.erase( 0, position + _separator.length() );

		// And the we look for a new place for the _separator
		position = _string.find_first_of( _separator );
	}

	// We will push the rest of the stuff in to the array
	if ( _string.empty() == false )
		array.push_back( _string );

	// Then we'll just return the array
	return array;
}


// Same thing as above but with _limit
std::vector <std::string> Split( const std::string& _separator, std::string _string, int _limit )
{

	std::vector <std::string> array;

	size_t position;
	position = _string.find_first_of( _separator );

	// The only diffrence is here
	int count = 0;	

	// and in this while loop the count <= _limit
	while ( position != _string.npos &&  count < _limit )
	{
	
		if ( position != 0 )
			array.push_back( _string.substr( 0, position ) );

		_string.erase( 0, position + _separator.length() );

		position = _string.find_first_of( _separator );

		// And here
		count++;
	}
	if ( _string.empty() == false )
		array.push_back( _string );

	return array;
}