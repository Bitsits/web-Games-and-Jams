#include "../../tester/ctester.h"
#include "../cdirlist.h"

#include <algorithm>

namespace ceng {
namespace test {

int CDirListTest()
{
	{
		CDirList test( "." );
		test.ReadDir();
		
		std::list< std::string > temp_list = test.GetTheList();

		std::list< std::string >::iterator i = std::find( temp_list.begin(), temp_list.end(), "temp" );
		test_assert( i != temp_list.end() );
	}
	return 0;
}

TEST_REGISTER( CDirListTest );

} // end of namespace test
} // end of namespace ceng