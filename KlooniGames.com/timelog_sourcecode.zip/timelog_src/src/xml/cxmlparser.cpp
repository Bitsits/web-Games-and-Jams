#include "cxmlparser.h"

#include <fstream>
#include <iostream>

namespace ceng {

void CXmlParser::ParseFile( const std::string& file )
{
	myHandler->StartDocument();

	std::fstream file_input;
    
	std::string line;

	if( file.empty() == false )
	{
		file_input.open( file.c_str(), std::ios::in );

        
		while ( file_input.good() ) 
		{
			std::getline( file_input, line );
			ParseLine( line );    
		}

		file_input.close();
	}

	myHandler->EndDocument();
}


void CXmlParser::ParseLine( const std::string& in_line )
{
	std::string line = in_line;
	
	if ( myRemoveWhiteSpace ) line = RemoveWhiteSpace( line );
	
	size_t i;

	if ( myStatus == content )
	{
		i = line.find_first_of("<");
           
        if ( i == line.npos ) 
		{
			myContentBuffer += line;
			return;
		} else {
			myContentBuffer += line.substr( 0, i );
			myStatus = tag;
			ParseContentBuffer();
			ParseLine( line.substr( i + 1 ) );
			return;
		}
	} else if ( myStatus == tag )
	{
		i = line.find_first_of(">");
		
		if ( i == line.npos )
		{
			myTagBuffer += line;
			return;
		} else {
			myTagBuffer += line.substr( 0, i );
			myStatus = content;
			ParseTagBuffer();
			ParseLine( line.substr( i + 1 ) );
			return;
		}
	}

}


void CXmlParser::ParseContentBuffer()
{
	
	while ( myRemoveWhiteSpace && myContentBuffer.size() > 1 && myContentBuffer[ myContentBuffer.size() - 1 ] == '\n' ) 
		myContentBuffer = myContentBuffer.substr( 0, myContentBuffer.size() - 1 );
	
	if ( myContentBuffer.empty() ) return;

	if( myRemoveWhiteSpace ) 
		myContentBuffer = RemoveWhiteSpace( myContentBuffer );	
	
	myHandler->Characters( myContentBuffer );
	myContentBuffer = "";

}

void CXmlParser::ParseTagBuffer()
{
	if ( myRemoveWhiteSpace ) myTagBuffer = RemoveWhiteSpace( myTagBuffer );
	while ( myRemoveWhiteSpace && myTagBuffer.size() > 1 && myTagBuffer[ myTagBuffer.size() - 1 ] == '\n' ) myTagBuffer = myTagBuffer.substr( 0, myTagBuffer.size() - 1 );
	
	if ( myTagBuffer.empty() ) return;

	
	
	std::string line = myTagBuffer;
	myTagBuffer = "";

	if ( line[0] == '/' ) 
	{
		myHandler->EndElement( line.substr( 1 ) );
		return;
	}

	if ( line[0] == '!' )
	{
		return;
	}

	size_t i = line.find_first_of( "=" );
	if ( i != line.npos ) line = ParseAttributes( line );
	
	if ( line.empty() ) return;

	if ( line[ line.size() - 1 ] == '/' )
	{	
		line = line.substr( 0, line.size() - 1 );
		myHandler->StartElement( line, myAttributeBuffer );
		myAttributeBuffer.clear();
		myHandler->EndElement( line );

		return;
	}

	myHandler->StartElement( line, myAttributeBuffer );
	myAttributeBuffer.clear();

}

std::string CXmlParser::ParseAttributes( const std::string& line )
{
	std::string tmp = line;
	size_t i = tmp.find_first_of( "=" );
	if ( i == tmp.npos ) return tmp;
	
	std::string key_part	= RemoveWhiteSpace( tmp.substr( 0, i ) );
	std::string value_part  = RemoveWhiteSpace( tmp.substr( i + 1 ) );

	i = key_part.find_last_of(" \t");
	if ( i != key_part.npos ) 
	{
		tmp = key_part.substr( 0, i );
		key_part = key_part.substr( i + 1 );
	}

	i = StringFindFirstOf( " \t", value_part );
	if ( i != value_part.npos )
	{
		tmp += value_part.substr( i );
		value_part = value_part.substr( 0, i);
	}

	value_part = RemoveWhiteSpace( value_part );
	value_part = value_part.substr( 1, value_part.size() - 2 );
	
	myAttributeBuffer.insert( std::pair< std::string, CAnyContainer >( key_part, value_part ) );

	return ParseAttributes( tmp );	
}

}