#include "cxmlnode.h"
#include "string.h"
#include "xml_macros.h"

namespace ceng {

bool CXmlNode::myReplaceEscapeChars = true;

///////////////////////////////////////////////////////////////////////////////

CXmlNode::~CXmlNode()
{
	for ( unsigned int i = 0; i < myXmlNodes.size(); ++i )
	{
		delete myXmlNodes[ i ];
	}
}

///////////////////////////////////////////////////////////////////////////////
// Child manipulation

bool CXmlNode::HasChilds() const
{
	return myXmlNodes.empty();
}

const CXmlNode*	CXmlNode::GetChild( int i ) const
{
	cassert( i >= 0 && i < GetChildCount() );

	return myXmlNodes[ i ];
}


CXmlNode* CXmlNode::GetChild( int i )
{
	cassert( i >= 0 && i < GetChildCount() );

	return myXmlNodes[ i ];
}

int	CXmlNode::GetChildCount() const
{
	return myXmlNodes.size();
}


void CXmlNode::AddChild( CXmlNode* child )
{
	child->SetFather( this );
	myXmlNodes.push_back( child );
}

void CXmlNode::RemoveChild( int i )
{
	// BUGBUG
	cassert( false && "this function hasn't been implented yet" );
}

void CXmlNode::RemoveChild( CXmlNode* child )
{
	// BUGBUG
	cassert( false && "this function hasn't been implented yet" );
}

///////////////////////////////////////////////////////////////////////////////

bool CXmlNode::HasAttributes() const
{
	return myAttributes.Empty();
}

bool CXmlNode::HasAttribute( const std::string& attribute ) const
{
	return myAttributes.HasKey( attribute );
}

int	CXmlNode::GetAttributeCount() const
{
	return myAttributes.Size();
}

std::string	CXmlNode::GetAttributeName( int i ) const
{
	cassert( i >= 0 && i < GetAttributeCount() );

	return myAttributes.GetKey( i );
}
	
const CAnyContainer& CXmlNode::GetAttributeValue( int i ) const
{
	cassert( i >= 0 && i < GetAttributeCount() );
	
	return myAttributes[ i ];
}

const CAnyContainer& CXmlNode::GetAttributeValue( const std::string& name )	const
{
	cassert( myAttributes.HasKey( name ) );

	return myAttributes[ name ];
}


void CXmlNode::AddAttribute( const std::string& name, const CAnyContainer& value )
{
	if( !myAttributes.HasKey( name ) )
		myAttributes.Insert( name, value );
}

void CXmlNode::RemoveAttribute( int i )
{
	// BUGBUG
	cassert( false && "this function hasn't been implented yet" );
}

void CXmlNode::RemoveAttribute( const std::string& name )
{	
	// BUGBUG
	cassert( false && "this function hasn't been implented yet" );
}

///////////////////////////////////////////////////////////////////////////////

std::string	CXmlNode::GetName() const
{
	return myName;
}

std::string CXmlNode::GetContent() const
{
	return myContent;
}

CXmlNode* CXmlNode::GetFather() const
{
	return myFather;
}

void CXmlNode::SetName( const std::string& name )
{
	myName = name;
}

void CXmlNode::SetContent( const std::string& content )
{
/*
	&lt; 	< 	less than
	&gt; 	> 	greater than
	&amp; 	& 	ampersand 
	&apos; 	' 	apostrophe
	&quot; 	" 	quotation mark
*/
	myContent = ( content );

	if( myReplaceEscapeChars && myContent.find( "&" ) != myContent.npos )
	{
		myContent = StringReplace( "&lt;",   "<",  myContent );
		myContent = StringReplace( "&gt;",   ">",  myContent );
		myContent = StringReplace( "&amp;",  "&",  myContent );
		myContent = StringReplace( "&apos;", "'",  myContent );
		myContent = StringReplace( "&quot;", "\"", myContent );
	}

}

void CXmlNode::SetFather( CXmlNode* father )
{
	myFather = father;
}

///////////////////////////////////////////////////////////////////////////////

}

