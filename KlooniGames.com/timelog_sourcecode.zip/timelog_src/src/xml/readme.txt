cxml 28.06.2006 version 1.2

cxml 08.05.2006 version 1.1

read comments in the file cxml.h to make some sense of this.