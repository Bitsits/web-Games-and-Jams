#ifndef INC_XMLMACROS_H
#define INC_XMLMACROS_H

#include "../tester/ctester.h"

#include <assert.h>
#include <iostream>

#define logger std::cout 
#define cassert assert

#endif