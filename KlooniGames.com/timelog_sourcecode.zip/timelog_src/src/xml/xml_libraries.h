#ifndef INC_XML_LIBRARIES_H
#define INC_XML_LIBRARIES_H

#include "canycontainer.h"
#include "cvarreference.h"
#include "cmultikeyvector.h"
#include "string.h"


#endif