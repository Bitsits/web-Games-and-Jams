///////////////////////////////////////////////////////////////////////////////
//
//	This file include some handlers.
//
//	There is the base class for the handlers called CXmlHandlerInterface, which
//	every selfrespecting handler will derivate.
//
//  Handlers are given to parsers as pointers and parsers will call the proper
//	methods of these handlers when they pick up something.
//
//  Created 01.10.2004 Pete
//
//.............................................................................
//
//=============================================================================
#pragma warning ( disable : 4786 )

#ifndef INC_CXMLHANDLER_H
#define INC_CXMLHANDLER_H


//-----------------------------------------------------------------------------

#include <string>
#include <map>
#include "xml_libraries.h"
#include <sstream>
#include <ostream>
#include "cxmlnode.h"
#include "xml_macros.h"

namespace ceng {

//! Base class for Handlers
class CXmlHandlerInterface
{
public:
	typedef std::map< std::string, CAnyContainer >					attributes;
	typedef std::map< std::string, CAnyContainer >::iterator		attributes_iterator;
	typedef std::map< std::string, CAnyContainer >::const_iterator	attributes_const_iterator;

	virtual ~CXmlHandlerInterface() { }
	
	//! Called when a document it startted
	virtual void StartDocument() { } 

	//! Called when the document is ended
	virtual void EndDocument() { }
	

	//! When we hit some characters this gets called, 
	virtual void Characters( const std::string& chars ) { }

	//! When a element gets startted this gets called
	virtual void StartElement( const std::string& name, const attributes& attr ) { }

	//! And when it ends we call him
	virtual void EndElement( const std::string& name ) { }
	

};


//-----------------------------------------------------------------------------


//! This parses the stuff confronted in to the stream.
/*!
	Works the other way round. If you have a CXmlNode structure you can create
	a xml file structure and output it in you favourite stream.
*/

class CXmlStreamHandler : public CXmlHandlerInterface
{
public:

	CXmlStreamHandler() : myCount(0) { }
	virtual ~CXmlStreamHandler() { }
	
	virtual void StartDocument() { }
	virtual void EndDocument() { }
	
	virtual void Characters( const std::string& chars, std::ostream& stream  ) { if ( !chars.empty() ) PrintText( chars, stream ); }
	virtual void StartElement( const std::string& name, const attributes& attr, std::ostream& stream  ) 
	{ 
		std::stringstream ss;
		ss << "<" << name;

		if ( !attr.empty() ) 
		{
			ss << " ";
			attributes::const_iterator i;
			for ( i = attr.begin(); i != attr.end(); ++i )
			{
				ss << i->first << "=\"" << CAnyContainerCast< std::string >( i->second ) << "\" ";
			}
		}
		ss << ">";

		PrintText( ss.str(), stream );
		myCount++;
	}

	virtual void EndElement( const std::string& name, std::ostream& stream  ) 
	{ 
		myCount--;
		PrintText( "</" + name + ">", stream );
		
	}

	//! Just for printing the text	
	void PrintText( const std::string& text, std::ostream& stream  )
	{
		for( int i = 0; i < myCount; i++ ) stream << "  ";
		stream << text << std::endl;
	}

	//! Just for parsing open the Node 
	void ParseOpen( CXmlNode* rootnode, std::ostream& stream ) 
	{
		StartElement( rootnode->GetName(), CreateAttributes( rootnode ), stream );
		Characters( rootnode->GetContent() , stream );
		for( int i = 0; i < rootnode->GetChildCount(); i++ )
		{
			
			ParseOpen( rootnode->GetChild( i ), stream );
		}
		EndElement( rootnode->GetName(), stream );
	}

	//! Returns a map of attributes
	std::map< std::string, CAnyContainer > CreateAttributes( CXmlNode* node )
	{
		std::map< std::string, CAnyContainer > tmp_map;

		for( int i = 0; i < node->GetAttributeCount(); i++ )
		{
			tmp_map.insert( std::pair< std::string, CAnyContainer >( node->GetAttributeName( i ), node->GetAttributeValue( i ) ) );
		}
		
		return tmp_map;
	}


	int				myCount;

};

//-----------------------------------------------------------------------------

// #include <assert.h>
// #define cassert assert


//! The handler which creates a CXmlNode structure.
/*!
	You should use this to create your own CXmlNode structure,
	you can get the root node by calling the GetRootElement() method

	Note: CXmlHanlder aint responsible for destroing the CXmlNode structure it 
	created. The user should always remember to release after use. 

*/
class CXmlHandler : public CXmlHandlerInterface
{
public:

	CXmlHandler() {  }
	virtual ~CXmlHandler() { }
	
	virtual void StartDocument()	{ myCurrentNode = NULL; myRootElement = NULL; }
	virtual void EndDocument()		{ /*cassert( myCurrentNode == NULL ); if( myCurrentNode != NULL) reportError();*/  }
	
	virtual void Characters( const std::string& chars ) 
	{ 
		if( myCurrentNode )
			myCurrentNode->SetContent( chars );
		// else report_error 
	}
	
	virtual void StartElement( const std::string& name, const attributes& attr ) 
	{ 
		
		CXmlNode* tmp_node = new CXmlNode;
		
		tmp_node->SetName( name );
		tmp_node->SetFather( myCurrentNode );

		if ( !attr.empty() )
		{
			attributes_const_iterator i;
		
			for ( i = attr.begin(); i != attr.end(); ++i ) 
			{
				tmp_node->AddAttribute( i->first, i->second );
			}
		}

		if ( myRootElement != NULL )
		{
			myCurrentNode->AddChild( tmp_node );
			myCurrentNode = tmp_node;
		} else {
			myRootElement = tmp_node;
			myCurrentNode = tmp_node;
		}

	}

	virtual void EndElement( const std::string& name ) 
	{ 
		myCurrentNode = myCurrentNode->GetFather();		
	}
	
	//! Returns the root node
	virtual CXmlNode* GetRootElement() const
	{
		return myRootElement;
	}
	
private:
	CXmlNode*	myRootElement;
	CXmlNode*	myCurrentNode;
	int			myCount;

};

//-----------------------------------------------------------------------------

}

#endif