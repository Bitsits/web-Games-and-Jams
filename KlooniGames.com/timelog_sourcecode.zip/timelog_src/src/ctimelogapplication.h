///////////////////////////////////////////////////////////////////////////////
//
// CTimeLogApplication
// ===================
//
// A Application for logging used time for a given project. Also logs your
// working efficensy.
//
// http://www.stevepavlina.com/articles/triple-your-personal-productivity.htm
//
//
// Created 08.05.2006 by Pete
//,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
//
// TODO!!!
// =======
//
//  [ ] Proper analyzer, that could be used as a independent program to analyze
//		working logs. Also per day and per project. So you could get some idea
//		how many hours has the project taken and some other useful stats, like
//		how much of time has been spend in writing tests, refactoring, bug 
//		hunting, designing and of course on breaks.
//
//  [ ] Change the command to a real class not just random junk in the 
//		applications run method.
//
//.............................................................................
//=============================================================================
#ifndef INC_CTIMELOGAPPLICATION_H
#define INC_CTIMELOGAPPLICATION_H

namespace timelog
{

class CTimeLogApplication
{
public:
	CTimeLogApplication( int argc, char** argv );
	~CTimeLogApplication();

	void Run();
	void Save();

private:

	class CTimeLogApplicationImpl;
	CTimeLogApplicationImpl* impl;
};

class CTimeLogAnalyzer
{
public:
	CTimeLogAnalyzer( int argc, char** argv );

	void Run();


private:
	class CTimeLogAnalyzerImpl;
	CTimeLogAnalyzerImpl* impl;

};

} // end of namespace timelog

#endif