#include "cdate.h"
#include <ctime>

#include "xml/cxml.h"

namespace timelog {

///////////////////////////////////////////////////////////////////////////////
CDate::CDate() :
	mySeconds( 0 ),
	myMinutes( 0 ),
	myHours( 0 ),
	myDays( 0 ),
	myWeeks( 0 ),
	myMonths( 0 ),
	myYears( 0 )
{ 

	time_t rawtime;
	tm* timeinfo;
	time( &rawtime );
	timeinfo = localtime( &rawtime );

	myYears = timeinfo->tm_year + 1900;
	myMonths = timeinfo->tm_mon + 1;
	myWeeks = timeinfo->tm_yday / 7;
	myDays = timeinfo->tm_mday;
	myHours = timeinfo->tm_hour;
	myMinutes = timeinfo->tm_min;
	mySeconds = timeinfo->tm_sec;

}

//=============================================================================

CDate::CDate( const CDate& other )
{
	operator=( other );
}

//=============================================================================

CDate::~CDate() 
{ 
}

///////////////////////////////////////////////////////////////////////////////

CDate& CDate::operator= ( const CDate& other ) 
{ 
	mySeconds = other.mySeconds;
	myMinutes = other.myMinutes;
	myHours = other.myHours;
	myDays = other.myDays;
	myWeeks = other.myWeeks;
	myMonths = other.myMonths;
	myYears = other.myYears;

	return *this;	
}

///////////////////////////////////////////////////////////////////////////////

bool CDate::operator== ( const CDate& other ) const  
{ 
	return ( this->GetSeconds() == other.GetSeconds() &&
			this->GetMinutes() == other.GetMinutes() &&
			this->GetHours() == other.GetHours() &&
			this->GetDays() == other.GetDays() &&
			this->GetWeeks() == other.GetWeeks() && 
			this->GetMonths() == other.GetMonths() &&
			this->GetYears() == other.GetYears() ); 
}

//=============================================================================

bool CDate::operator!= ( const CDate& other ) const  
{ 
	return !operator==( other ); 
}

///////////////////////////////////////////////////////////////////////////////

bool CDate::operator< ( const CDate& other ) const 
{ 
	return ( InSeconds() < other.InSeconds() ); 
}

//=============================================================================

bool CDate::operator> ( const CDate& other ) const 
{ 
	if( operator<( other ) || operator==( other )  ) 
		return false; 
	
	return true; 
}

//=============================================================================

bool CDate::operator<=( const CDate& other ) const 
{ 
	return !operator>( other ); 
}

//=============================================================================

bool CDate::operator>=( const CDate& other ) const 
{ 
	return !operator<( other ); 
}

///////////////////////////////////////////////////////////////////////////////

CDate CDate::operator- ( const CDate& other ) const 
{ 
	CDate foo( *this ); 
	foo -= other; 
	return foo; 
}

//=============================================================================

CDate CDate::operator+ ( const CDate& other ) const 
{ 
	CDate foo( *this ); 
	foo += other; 
	return foo; 
}

//=============================================================================

CDate& CDate::operator-=( const CDate& other ) 
{ 
	mySeconds -= other.mySeconds;
	myMinutes -= other.myMinutes;
	myHours -= other.myHours;
	myDays -= other.myDays;
	myWeeks -= other.myWeeks;
	myMonths -= other.myMonths;
	myYears -= other.myYears;

	return *this; 
}

//=============================================================================

CDate& CDate::operator+=( const CDate& other ) 
{ 
	mySeconds += other.mySeconds;
	myMinutes += other.myMinutes;
	myHours += other.myHours;
	myDays += other.myDays;
	myWeeks += other.myWeeks;
	myMonths += other.myMonths;
	myYears += other.myYears;

	return *this; 
}

///////////////////////////////////////////////////////////////////////////////

int	CDate::GetYears() const 
{ 
	return (int)myYears; 
}

//=============================================================================

int	CDate::GetMonths() const 
{ 
	return (int)myMonths; 
}

//=============================================================================

int	CDate::GetWeeks() const 
{ 
	return (int)myWeeks; 
}

//=============================================================================

int	CDate::GetDays() const 
{ 
	return (int)myDays; 
}

//=============================================================================

int	CDate::GetHours() const 
{ 
	return (int)myHours;
}

//=============================================================================

int	CDate::GetMinutes() const 
{ 
	return (int)myMinutes; 
}

//=============================================================================

int	CDate::GetSeconds() const 
{ 
	return (int)mySeconds; 
}

///////////////////////////////////////////////////////////////////////////////

double		CDate::InYears() const		
{ 
	return ( InDays() / 364.0 ); 
}

//=============================================================================

double		CDate::InMonths() const	
{ 
	return ( InYears() * 12.0 ); 
}

//=============================================================================

double		CDate::InWeeks() const		
{ 
	return ( InDays() / 7.0 ); 
}

//=============================================================================

double CDate::InDays() const
{ 
	return ( InHours() / 24.0 ); 
}

//=============================================================================

double CDate::InHours() const
{ 
	return ( InMinutes() / 60.0 ); 
}

//=============================================================================

double CDate::InMinutes() const	
{ 
	return ( InSeconds() / 60.0 ); 
}

//=============================================================================

double CDate::InSeconds() const	
{ 
	double result = 0;
	result += (double)( GetSeconds() );
	result += (double)( GetMinutes() ) * 60.0;
	result += (double)( GetHours() ) * 60.0 * 60.0;
	result += (double)( GetDays() ) * 24.0 * 60.0 * 60.0;
	result += (double)( GetMonths() ) * 30.0 * 24.0 * 60.0 * 60.0;
	result += (double)( GetYears() ) * 12.0 * 30.0 * 24.0 * 60.0 * 60.0;
	
	return result; 
}

///////////////////////////////////////////////////////////////////////////////

std::string CDate::AsString() const 
{ 
	return ""; 
}

///////////////////////////////////////////////////////////////////////////////

void CDate::Serialize( ceng::CXmlFileSys* filesys )
{
	XML_BindAttributeAlias( filesys, myYears,	"year" );
	XML_BindAttributeAlias( filesys, myMonths,	"month" );
	XML_BindAttributeAlias( filesys, myWeeks,	"week" );
	XML_BindAttributeAlias( filesys, myDays,	"day" );
	XML_BindAttributeAlias( filesys, myHours,	"hour" );
	XML_BindAttributeAlias( filesys, myMinutes, "minute" );
	XML_BindAttributeAlias( filesys, mySeconds, "second" );

	/*	int myYears;
	int myMonths;
	int myWeeks;
	int myDays;
	int myHours;
	int myMinutes;
	int mySeconds;*/
}

///////////////////////////////////////////////////////////////////////////////

} // end of namespace timelog
