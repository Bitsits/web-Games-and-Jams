#include "ctester.h"

#define logger std::cout
using namespace ceng;
using namespace ceng::tester;

int RunTests()
{
	logger << "Ceng tester..." << std::endl;
	logger << "------------------------------------------------------------------ " << std::endl;
	bool passed = true;
	int i;

	//logger.Function();
	
	for ( i = 0; i < CTester::GetSingleton().GetSize(); i++ )
	{
		if( tester::CTester::GetSingleton().ExecuteTest( i ) != 0 )
		{
			// Error 

			logger << CTester::GetSingleton().GetName( i ) << " FAILED!" << std::endl;
			
			logger << " in the file " << CTester::GetSingleton().GetFile( i ) << ".\n" << std::endl;
			
			logger << " on the following test assert: " << CTester::GetSingletonPtr()->GetAssertation() << std::endl;

			logger << CTester::GetSingletonPtr()->GetError() << std::endl;

			passed = false;
		}
		else
		{

			// Success
			logger << CTester::GetSingleton().GetName( i ) + " [OK]" << std::endl;
		}
	}
	
	logger << "------------------------------------------------------------------ " << std::endl;
	
	if( passed ) 
		logger << "All tests OK" << std::endl << std::endl;
	else logger << "Some of the tests failed miserably" << std::endl << std::endl;


	return 0;
}