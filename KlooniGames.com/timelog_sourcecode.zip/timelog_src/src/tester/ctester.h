///////////////////////////////////////////////////////////////////////////////
//
// CTester
// Unit-test framework 
//
// Inspired by Jani Kajala's (jani.kajala@helsinki.fi) Tester class. 
// The static array implentation is from his Test class which he wrote for 
//	catmother ( http://catmother.sourceforge.net/ )
//.............................................................................
//
// Created 02.02.2005 Pete
//
//=============================================================================
#ifndef INC_CTESTER_H
#define INC_CTESTER_H

#include <string>
#include <vector>
#include <assert.h>
#include <iostream>

#include "csingleton.h"
#include "ctester_numeric.h"
// #include "../utils/logger.h"

#define test_assert assert
#define logger		std::cout

namespace ceng {

//! namespace for unit test classes
namespace tester {

///////////////////////////////////////////////////////////////////////////////

	//! Just to make my life a more pleasent place to be
struct CDelegate 
{
	CDelegate() { }
	CDelegate( int (*func)() ) : myFunction( func ) { }
	CDelegate( const CDelegate& other ) : myFunction( other.myFunction ) { }
	CDelegate& operator=( const CDelegate& other ) { myFunction = other.myFunction; return *this; }

	int Call() { return (*myFunction)(); }
private:
	int (*myFunction)() ;
};

///////////////////////////////////////////////////////////////////////////////

//! POD class to make the world a little better place 
struct CTestInfo
{
	CTestInfo() { }
	CTestInfo( const CDelegate& deleg, const std::string& name, const std::string& file ) : 
	  myDelegate( deleg ), myName( name ), myFile( file ) { }
	
	CTestInfo( const CTestInfo& other ) : 
	  myDelegate( other.myDelegate ),
	  myName( other.myName ),
	  myFile( other.myFile ) { }

	CTestInfo& operator=( const CTestInfo& other ) 
	{
		myDelegate = other.myDelegate;
		myName = other.myName;
		myFile = other.myFile;

		return *this;
	}

	CDelegate	myDelegate;
	std::string	myName;
	std::string	myFile;
};

///////////////////////////////////////////////////////////////////////////////

//! CTester is a class / framework for testing modules of your / mine program
class CTester : public ceng::CSingleton< CTester >
{
public:
	
	//! The constructor used to register new test
	CTester( int (*deleg)(), const std::string& name, const std::string& file );
	~CTester() { } 

	//! Returns the number of tests
	int GetSize() const;

	//! returns the name of the test required
	std::string GetName( int i ) const;

	//! returns the name of the file where the test was registered
	std::string GetFile( int i ) const;

	//.........................................................................

	//! returns the currently failed assertation
	std::string GetAssertation() const;

	//! get error report
	std::string GetError() const;

	//.........................................................................

	//! excecutes the desired the test and returns the return value 
	//! that the test returns
	int ExecuteTest( int i );

private:
	//! Because of the singleton
	CTester() { }
	
	std::vector< CTestInfo > myTests;

	friend class ceng::CSingleton< CTester >;

};

// ripped from boost
#define TESTER_JOIN( X, Y ) TESTER_DO_JOIN( X, Y )
#define TESTER_DO_JOIN( X, Y ) TESTER_DO_JOIN2(X,Y)
#define TESTER_DO_JOIN2( X, Y ) X##Y

#define TEST_REGISTER( x ) static ::ceng::tester::CTester TESTER_JOIN( test, __LINE__ ) (  x, #x, __FILE__ )

///////////////////////////////////////////////////////////////////////////////
} // end of namespace tester
} // end of namespace ceng

#endif