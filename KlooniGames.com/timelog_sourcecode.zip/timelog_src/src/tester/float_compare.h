#ifndef INC_FLOAT_COMPARE_H
#define INC_FLOAT_COMPARE_H

bool AlmostEqualUlpsFinal(float A, float B, int maxUlps = 10);

#endif