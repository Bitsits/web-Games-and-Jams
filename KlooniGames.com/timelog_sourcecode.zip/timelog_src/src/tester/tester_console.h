#ifndef INC_TESTER_CONSOLE_H
#define INC_TESTER_CONSOLE_H

int RunTests();

#endif