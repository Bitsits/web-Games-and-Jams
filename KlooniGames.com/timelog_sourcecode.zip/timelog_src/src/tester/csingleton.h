///////////////////////////////////////////////////////////
//
// CSingleton 
// ----------
// 
// Instructions:
//
// Easy singleton creation.
// simple-example:
// class mysingleton : public CSingleton< mysingleton >
// {
// private:
//    mysingleton() { }
//    friend CSingleton< mysingleton >;
// };
//
// Features
//
// if these are defined the following will happen
//
// #define CSINGLETON_CFG_USE_GARBAGE_COLLECTOR
//
//		Puts the singletons in to a list, in 
//		CSingletonControl class. 
//		CSingletonControl::CollectGarbage()
//		will delete all the singletons in memory
//
// #define CSINGLETON_CFG_USE_AUTO_GARBAGE_COLLECTOR
//		
//		Calls CSingletonControl::CollectGarbage()
//		automaticly, when the program ends.
//
// #define CSINGLETON_CFG_USE_LEAK_LOGGER
//
//		This will write a log file where you can
//		see the not-deleted singletons. 
//		The memory leaks.
// 
// Thats pretty much it. As a default the 
// garbage collecting stuff is used in debug mode...
//
// Credits:
//
// Petri Purho (c) 2004
// full source can be found at:
// http://koti.mbnet.fi/kumikana/soodaus/cpp/CSingleton/
//
//---------------------------------------------------------

#ifndef INC_CSINGLETON_H
#define INC_CSINGLETON_H

#pragma warning(disable:4786) 

#include <list>
#include <typeinfo>
#include <string>



// As a default in the debug mode the garbage 
// collecting and leak loggin are in use. 
// If you don't like the garbage collecting 
// ( even in debug-only-mode ), just 
// throw // infront
// of the #define CSINGLETON_CFG_USE... line

// These may cause nasty bugs when dealing with static stuff.
#ifndef NDEBUG

// #	define CSINGLETON_CFG_USE_GARBAGE_COLLECTOR
// #	define CSINGELTON_CFG_USE_AUTO_GARBAGE_COLLECTOR
// #	define CSINGLETON_CFG_USE_LEAK_LOGGER


#endif

// Some macro magic...
#ifdef CSINGLETON_CFG_USE_LEAK_LOGGER
#	define CSINGLETON_CFG_USE_GARBAGE_COLLECTOR
#endif

#ifdef CSINGELTON_CFG_USE_AUTO_GARBAGE_COLLECTOR
#	define CSINGLETON_CFG_USE_GARBAGE_COLLECTOR
#endif


#include <fstream>
#include <ctime>

namespace ceng {

//! This fellow here is used to log the leaks... 
//! So if there is a leak this badger will log
//! it to SingletonLeaks.log... Or you can
//! set your own log file by calling 
//! CSingletonLeakLogger::SetFilename( "mylog.log" );
class CSingletonLeakLogger
{
public:
	CSingletonLeakLogger() { }
	~CSingletonLeakLogger();

	
	static void SetFilename( const std::string& filename ) { myFilename = filename; }

private:
	static std::string myFilename;

};

// This here is the auto garbage collector
struct CSingletonAutoGarbageCollector
{
	~CSingletonAutoGarbageCollector();
};

//! This here is the control class.
//! from here the CSingleton is derived if 
//! CSINGLETON_CFG_USE_GARBAGE_COLLECTOR
//! is defined.
//! This class will be defined even if you
//! dont use garbage collecting. So you dont
//! have to write in your code #ifdef DEBUG
//! stuff, if you want to read the leaked 
//! singletons
class CSingletonControl
{
public:
	virtual ~CSingletonControl() { }

	// This here is the function for Collecting Garbage.
	// CSingletonControl::CollectGarbage() will destroy
	// all the singletons in memory.
	static void CollectGarbage()
	{
		while ( !mySingletons.empty() )
		{
			delete mySingletons.begin()->second;
		}
	}


#ifdef CSINGLETON_CFG_USE_LEAK_LOGGER
	static CSingletonLeakLogger LeakLogger;
#endif

#ifdef CSINGELTON_CFG_USE_AUTO_GARBAGE_COLLECTOR
	static CSingletonAutoGarbageCollector	autoGC;
#endif

	// Heres a list of singletons in memory.
	// So its pretty simply to write a reader
	// that will read in the end of a program
	// the singletons that didn't get deleted
	// and print their names.  So you can fix 
	// memory leaks with this list.
	static std::list< std::pair< std::string, CSingletonControl* > > mySingletons;
};

// Heres the two different begins of the class
// CSingleton
#ifdef CSINGLETON_CFG_USE_GARBAGE_COLLECTOR

//! First the garbage collecting version
template < typename _T >
class CSingleton : public CSingletonControl
{
public:
	virtual ~CSingleton() 
	{ 
		// Basicly here we remove our selves from the 
		// CSingletonControl::mySingletons list
		std::list< std::pair< std::string, CSingletonControl* > >::iterator i;

		for ( i =  CSingletonControl::mySingletons.begin();
			  i != CSingletonControl::mySingletons.end();
			  ++i )
			if ( this == i->second ) break;
		
		if ( i != CSingletonControl::mySingletons.end() ) 
			CSingletonControl::mySingletons.erase( i );

	}

	static _T* GetSingletonPtr()
	{ 
		
		if ( myInstance == 0 ) 
		{
			myInstance = new _T; 
			// only difference here is that we push
			// our selves to the list.
			CSingletonControl::mySingletons.push_back( 
				std::pair< std::string, CSingletonControl* >( 
				typeid( _T ).name(), myInstance ) );
		}

		return myInstance; 
	}
#else 

//! Heres the normal version without the garbage collecting
//! stuff
template < typename _T >
class CSingleton
{
public:
	virtual ~CSingleton() { }

	static _T* GetSingletonPtr()
	{ 
		if ( myInstance == 0 ) 
			myInstance = new _T; 
		
		return myInstance; 
	}

#endif


	static _T& GetSingleton() { return (*GetSingletonPtr() ); }
	
	static void Delete() 
	{
		delete myInstance;
		myInstance = 0;
	}

protected:
	CSingleton() {	}

	static _T* myInstance;
	
};

template< typename _T >  _T* CSingleton< _T >::myInstance = 0;

}

#endif