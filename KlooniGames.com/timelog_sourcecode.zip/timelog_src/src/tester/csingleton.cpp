#include "csingleton.h"

#pragma warning(disable:4786) 

namespace ceng {

std::list< std::pair< std::string, CSingletonControl* > >	CSingletonControl::mySingletons;


#ifdef CSINGLETON_CFG_USE_LEAK_LOGGER
CSingletonLeakLogger										CSingletonControl::LeakLogger;
#endif

#ifdef CSINGELTON_CFG_USE_AUTO_GARBAGE_COLLECTOR
CSingletonAutoGarbageCollector								CSingletonControl::autoGC;
#endif


std::string CSingletonLeakLogger::myFilename;

CSingletonLeakLogger::~CSingletonLeakLogger()
{
	// this gets called when the program ends
	
	//while ( true );
	if ( CSingletonControl::mySingletons.empty() == false )
	{
		
		std::fstream myOutput;

		if ( myFilename.empty() ) myFilename = "SingletonLeaks.log";

		myOutput.open( myFilename.c_str(), std::ios::out );
		
		char	date[80];
		time_t	now = time( NULL );
		strftime( date, sizeof date, "%a,%b %d,%I:%M %p",localtime( &now ) );
		
		myOutput << "Singletons leaked " << date << std::endl << std::endl;
		myOutput << "The following class(es) didn't get destroid:" << std::endl;
		
		std::list< std::pair< std::string, CSingletonControl* > >::iterator i;
		for ( i  = CSingletonControl::mySingletons.begin();
			  i != CSingletonControl::mySingletons.end(); ++i )
		{
			myOutput << "  " << i->first << std::endl;
		}
		
		myOutput << std::endl;
		myOutput << std::endl << "You could have freeded them by adding "
			"the following line to the end of your code:" << std::endl 
			<< "CSingletonControl::CollectGarbage();" << std::endl << std::endl
			<< "That will destroy the leaked singletons, but it won't "
			" work in release unless you " << std::endl <<
			"#define CSINGLGETON_USE_GARBAGE_COLLECTOR" << std::endl << std::endl
			<< "check csingleton.h for further instructions" << std::endl;

		myOutput.close();
	}
}

CSingletonAutoGarbageCollector::~CSingletonAutoGarbageCollector()
{
	CSingletonControl::CollectGarbage();
}

class _T;

_T* CSingleton< _T >::myInstance = 0;

}