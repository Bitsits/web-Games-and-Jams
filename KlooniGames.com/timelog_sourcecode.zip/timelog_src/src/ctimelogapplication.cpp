#include "ctimelogapplication.h"
#include <direct.h>

#include <vector>
#include <algorithm>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <fstream>

#include "dirlist/cdirlist.h"
#include "xml/string.h"

#include "ctimelog.h"
#include "clrscr.h"

namespace timelog {

namespace {

///////////////////////////////////////////////////////////////////////////////

bool DoesDirectoryExist( const std::string& name )
{
	CDirList test( "." );
	test.ReadDir();
		
	std::list< std::string > temp_list = test.GetTheList();

	std::list< std::string >::iterator i = std::find( temp_list.begin(), temp_list.end(), name );
	return ( i != temp_list.end() );
}

///////////////////////////////////////////////////////////////////////////////

bool autosave = true;

} // end of anonymous namespace

///////////////////////////////////////////////////////////////////////////////

class CTimeLogApplication::CTimeLogApplicationImpl
{
public:
	CTimeLogApplicationImpl( int argc, char** args )  :
		myAnalyzeOnly( false )
	{
		int i;
		for ( i=1; i < argc; i++ ) 
			myArgs.push_back( args[i] );

		if( myArgs.size() > 0 && myArgs[ 0 ].empty() == false )
		{
			if( myArgs[ 0 ] == "-analyze" )
				myAnalyzeOnly = true;
		}

		for( i = 0; i < (signed)myArgs.size(); i++ )
		{
			if( myArgs[ i ] == "-no_autosave" )
				autosave = false;
		}
		// myAnalyzeOnly = true;
	}

	///////////////////////////////////////////////////////////////////////////

	void Run()
	{
		if( myAnalyzeOnly )
		{
			RunAnalyzer();
		}
		else
		{
			RunTimeLog();
		}
	}

	//=========================================================================

	void RunAnalyzer()
	{
		std::string myOutputFile;
		bool are_just_analysing = true;

		myLog.SetUnloading( false );

		// loading the project file
		{
			// reading the project name
			std::string project_name;
			if( myArgs.size() > 1 && myArgs[ 1 ].empty() == false )
			{
				project_name = myArgs[ 1 ];
			}
			else
			{
				std::cout << "Please, give the name of the project: ";
				std::cin >> project_name;
			}

			// checking does the project exist
			while( DoesDirectoryExist( project_name ) == false )
			{
				std::cout << "Sorry, but could not find project folder with the name: " << project_name << std::endl;
				std::cout << "Please, reenter the name of the project: ";
				std::cin >> project_name;
			}


			myFilename = project_name + "/";

			// loading all the entries
			{
				CDirList files;
				files.ReadFiles( myFilename + "*.xml" );
				
				std::list< std::string > temp_list = files.GetTheList();

				std::list< std::string >::iterator i = temp_list.begin();
				for( i = temp_list.begin(); i != temp_list.end(); ++i )
				{
					myLog.LoadProject( myFilename + *i );
				}
			}
			
			if( are_just_analysing )
			{
				std::string output_file;
				if( myArgs.size() > 1 && myArgs[ 1 ].empty() == false )
				{
					output_file = myArgs[ 1 ];
				}
				else
				{
					std::cout << "Please, give the name of the output file: ";
					std::cin >> output_file;
				}

				myOutputFile = output_file;
			}
			
			std::fstream file( myOutputFile.c_str(), std::ios::out );
			AnalyzeTo( file );
			file.close();
		}
	}

	//=========================================================================

	void LoadProject( const std::string& in_project_name = "" )
	{
		// loading the project file
		{
			myLog.Clear();

			// reading the project name
			std::string project_name;
			if( in_project_name.empty() == false )
			{
				project_name = in_project_name;
			}
			else if( myArgs.size() > 0 && myArgs[ 0 ].empty() == false )
			{
				project_name = myArgs[ 0 ];
			}
			else
			{
				std::cout << "Please, give the name of the project: ";
				std::cin >> project_name;
			}

			// checking does the project exist
			if( DoesDirectoryExist( project_name ) == false )
			{
				while( true )
				{
					std::cout << "Sorry, but could not find project folder with the name: " << project_name << std::endl;
					if( project_name.empty() == false )
					{
						std::cout << "Do you want to create a new project named: " << project_name << " (y/n)" << std::endl;
						std::string temp_input;
						std::cin >> temp_input;

						if( temp_input == "y" ) 
						{
							if( mkdir( project_name.c_str() ) == -1 )
							{
								std::cout << "Error: Couldn't create a folder named: " << project_name << std::endl;
							}
						}
					}
					
					if( DoesDirectoryExist( project_name ) == true )
						break;

					std::cout << "Please, reenter the name of the project: ";
					std::cin >> project_name;

					if( DoesDirectoryExist( project_name ) == true )
						break;

				}
			}

			myFilename = project_name + "/";

			myProjectName = project_name;
			{
				CDate now;
				std::stringstream ss;
				ss << std::setfill( '0' ) << std::setw(2) << now.GetDays() << "-" << std::setw(2) << now.GetMonths() << "-" << now.GetYears() << ".xml";
				myFilename += ss.str();
			}
			
			myLog.LoadProject( myFilename );

			// reenter the old task
			if( myLog.GetEntryList().empty() == false )
			{
				CTimeLog::Entry entry = myLog.GetCurrentEntry();
				myLog.AddEntry( CTimeLog::Entry( entry.GetName(), entry.entry_type ) );
			}			
		}
	}

	void RunTimeLog()
	{
	
		LoadProject();
		// reading the entries
		{
			std::string error_text = "";
			std::string temp;
			bool on_break = myLog.OnABreak();
			do
			{
				// header
				{
					clrscr();

					{
						if( true )
						{
							std::cout << "Project: " << myProjectName << std::endl;
						}

						if( myLog.GetEntryList().empty() == false )
						{
							CTimeLog::Entry entry = myLog.GetCurrentEntry();

							if( entry.entry_type == CTimeLog::Entry::entry_subtask )
							{
								std::cout << "Currently working on: " << entry.GetName() << std::endl;
							}
							else
							{
								std::cout << "Currently on a break: " << entry.GetName() << std::endl;
							}
						}
						else
						{
							std::cout << "Gimme something to work with: " << std::endl;
						}

						std::cout << std::endl;
					}
					if( error_text.empty() == false )
					{
						std::cout << error_text << std::endl;
						error_text = "";
					}
					
				}
				// read
				{
					temp = "";
					char temp_buffer[ 256 ];
					std::cin.getline( temp_buffer, 256 );
					temp = temp_buffer;
				}

				// parse
				if( temp.empty() == false && temp[0] != '/' )
				{
					myLog.WorkingNowOn( temp );
					// currently_text = "Currently working on: " + temp;
					on_break = false;
					if( autosave ) 
						Save();
				}
				else if( temp.empty() == false )
				{
					std::vector< std::string > args = ceng::Split( " ", temp, 2 );
					std::string command = args[ 0 ].substr( 1 );
					
					std::cout << command << std::endl;
					
					if( command == "break" || command == "b" )
					{
						if( args.size() > 1 ) 
						{
							myLog.TakeABreak( args[ 1 ] );
							on_break = true;
							if( autosave ) 
								Save();

						}
						else if( on_break ) // end break
						{
							myLog.EndBreak();
							on_break = false;
							if( autosave ) 
								Save();
						}
						else
						{
							error_text = "Warning: no break reason given. Using default unknown break reason: surfing porn";
							myLog.TakeABreak( "unknow" );
							on_break = true;
							if( autosave ) 
								Save();

						}
						// currently_text = "Currently on a break: " + break_reason;
					}
					else if( command == "end_break" || command == "" )
					{
						if( on_break )
						{
							myLog.EndBreak();
							on_break = false;
							if( autosave ) 
								Save();
						}
						else
						{
							error_text = "Error: could not end break, because you were not on a break.";
						}
					}
					else if( command == "undo" )
					{
						myLog.UndoLastEntry();
					}
					else if( command == "save" )
					{
						std::string file = myFilename;
						if( args.size() > 1 ) 
							file = args[ 1 ];

						myLog.SaveProject( file );
					}
					else if( command == "project" )
					{
						std::string project = "";
						if( args.size() > 1 )
						{
							project = args[ 1 ];
							Save();
							LoadProject( project );
							{
								error_text = "";
								temp = "";
								on_break = myLog.OnABreak();
							}
							
						}
						else
						{
							error_text = "Error: Cannot change project, unless you give project's name to be switched in.";
						}
					}
					else if( command == "reload" )
					{
						Reload();
						{
							error_text = "";
							temp = "";
							on_break = myLog.OnABreak();
						}
					}
					else if( command == "help" )
					{
						if( args.size() > 1 )
						{
						}
						else
						{
							std::stringstream ss;
							ss << "Timelog commands: " << std::endl;
							ss << "/break" << std::endl;
							ss << "/save" << std::endl;
							ss << "/undo" << std::endl;
							ss << "/reload" << std::endl;
							ss << "/help" << std::endl;
							ss << "/list \t or /analyze" << std::endl;
							ss << "/project" << std::endl;
							ss << "/quit \t or /exit" << std::endl;
							ss << std::endl;
							ss << "Howto use: Just write name of the task your working on. When you complete that task write the name of the new task your working on. If you want, you can use helpful categories. For example write \"code: bug hunting\"." << std::endl;
							ss << "When you want to take break from working, just type /break and the reason why your on a break. For example \"/break reading email\". You can end your break, just by typing \"/break\", without any reason. " << std::endl;
							ss << "You can change project on the fly with the /project -command" << std::endl;
	
							error_text = ss.str();
						}
					}
					else if( command == "analyze" || command == "list" )
					{
						if( autosave ) 
							Save();

						error_text = SmallAnalyze();
					}
					else
					{
						error_text = "Error: unknown command: " + command + "\nType \"/help\" for list of known commands";
					}
				}

			} while( temp != "/quit" && temp != "/exit" );

		}

		// saving
		{
			Save();
		}

		std::cout << SmallAnalyze() << std::endl;
	}

	///////////////////////////////////////////////////////////////////////////

	void Save()
	{
		myLog.SaveProject( myFilename );
	}

	void Reload()
	{
		myLog.Clear();
		myLog.LoadProject( myFilename );
	}

	///////////////////////////////////////////////////////////////////////////

	std::string SmallAnalyze()
	{
		std::stringstream ss;

		// analyzing
		/*{
			std::list< CTimeLog::Entry > list = myLog.GetEntryList();
			std::list< CTimeLog::Entry >::iterator i = list.begin();
			for( i = list.begin(); i != list.end(); ++i )
			{
				ss << i->GetName() << "\t" << i->GetDuration().InHours() << " h" << std::endl;
			}
		}*/
		AnalyzeTo( ss );

		return ss.str();

	}

	///////////////////////////////////////////////////////////////////////////

	void AnalyzeTo( std::ostream& stream )
	{
		// analyzing
		{
			double total_hours = 0;
			double total_work = 0;
			double total_break = 0;

			// std::fstream out_file( myOutputFile.c_str(), std::ios::out );

			std::list< CTimeLog::Entry > list = myLog.GetEntryList();
			list.sort();
			std::list< CTimeLog::Entry >::iterator i = list.begin();
			for( i = list.begin(); i != list.end(); ++i )
			{
				// break
				if( i->entry_type == 1 )
				{
					
					stream << "break: " << i->GetName() << "\t" << i->GetDuration().InHours() << " h" << std::endl;
					total_break += i->GetDuration().InHours();
				}
				else
				{
					stream << i->GetName() << "\t" << i->GetDuration().InHours() << " h" << std::endl;
					total_work += i->GetDuration().InHours();
				}
				

				total_hours += i->GetDuration().InHours();
			}


			float working_efficiency = 0;
			
			if( total_hours != 0 )
			{
				working_efficiency = (float)total_work / (float)total_hours;
				working_efficiency *= 100.0f;
			}


			stream << "total hours: \t " << total_hours << std::endl;
			stream << "total work: \t " << total_work << std::endl;
			stream << "total break: \t " << total_break << std::endl;
			stream << "working efficiency: \t " << std::setprecision(4) << working_efficiency << " %" << std::endl;

			/*
			out_file << "total hours: \t " << total_hours << std::endl;
			out_file << "total work: \t " << total_work << std::endl;
			out_file << "total break: \t " << total_break << std::endl;
			out_file  << "working efficiency: \t " << std::setprecision(2) << working_efficiency << std::endl;
	
			out_file.close();
			*/
		}
	}

	///////////////////////////////////////////////////////////////////////////

	std::vector< std::string >	myArgs;
	CTimeLog					myLog;
	std::string					myFilename;
	std::string					myProjectName;
	bool						myAnalyzeOnly;

};

///////////////////////////////////////////////////////////////////////////////

CTimeLogApplication::CTimeLogApplication( int argc, char** args ) :
	impl( NULL )
{
	impl = new CTimeLogApplicationImpl( argc, args );
}

//=============================================================================

CTimeLogApplication::~CTimeLogApplication()
{
	if( impl )
		impl->Save();
	delete impl;
	impl = NULL;
}


//=============================================================================

void CTimeLogApplication::Run()
{
	if( impl )
		impl->Run();
}

void CTimeLogApplication::Save()
{
	if( impl )
		impl->Save();
}

///////////////////////////////////////////////////////////////////////////////

class CTimeLogAnalyzer::CTimeLogAnalyzerImpl
{
public:
	CTimeLogAnalyzerImpl( int argc, char** args ) 
	{
		int i;
		for ( i=1; i < argc; i++ ) 
			myArgs.push_back( args[i] );
	}

	void Run()
	{
		CTimeLog myLog;
		std::string myFilename;
		std::string myOutputFile;
		bool are_just_analysing = true;

		myLog.SetUnloading( false );

		// loading the project file
		{
			// reading the project name
			std::string project_name;
			if( myArgs.size() > 0 && myArgs[ 0 ].empty() == false )
			{
				project_name = myArgs[ 0 ];
			}
			else
			{
				std::cout << "Please, give the name of the project: ";
				std::cin >> project_name;
			}

			// checking does the project exist
			while( DoesDirectoryExist( project_name ) == false )
			{
				std::cout << "Sorry, but could not find project folder with the name: " << project_name << std::endl;
				std::cout << "Please, reenter the name of the project: ";
				std::cin >> project_name;
			}

			myFilename = project_name + "/";

			// loading all the entries
			{
				CDirList files;
				files.ReadFiles( myFilename + "*.xml" );
				
				std::list< std::string > temp_list = files.GetTheList();

				std::list< std::string >::iterator i = temp_list.begin();
				for( i = temp_list.begin(); i != temp_list.end(); ++i )
				{
					myLog.LoadProject( myFilename + *i );
				}
			}
			
			if( are_just_analysing )
			{
				std::string output_file;
				if( myArgs.size() > 1 && myArgs[ 1 ].empty() == false )
				{
					output_file = myArgs[ 1 ];
				}
				else
				{
					std::cout << "Please, give the name of the output file: ";
					std::cin >> output_file;
				}

				myOutputFile = output_file;
			}
		}

	
	}

	std::vector< std::string > myArgs;
};

CTimeLogAnalyzer::CTimeLogAnalyzer( int argc, char** argv )
{
	impl = new CTimeLogAnalyzerImpl( argc, argv );
}


void CTimeLogAnalyzer::Run()
{
	impl->Run();
}

///////////////////////////////////////////////////////////////////////////////
} // end of namespace timelog
