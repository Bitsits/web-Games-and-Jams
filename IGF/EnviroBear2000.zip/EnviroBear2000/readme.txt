Enviro-Bear 2000: Operation: Hibernation

A game by Justin Smith


Instructions:

. Use the mouse to grab stuff
. Eat fish and berries to fatten up
. When you are fat enough, drive into a cave to hibernate
. You can throw stuff out of your windows and sunroof


Press ctrl+M and ctrl+S to toggle music and sound.


Made using Haaf's Game Engine (HGE) and Box2d
Music by Roberto �RobRic� Ricioppo
