In One Piece

Install instructions:
Execute release\in-one-piece.exe to start the game.

Game manual:
Click and drag with your mouse on the YumBalls to lead them around on the rooftop. All the other balls will follow the one you're dragging.
Blocks will fall from above, and the shadow will tell you where the holes in the block are. Position your YumBalls in the hole before the block hits the roof!
Every once in a while you will get new YumBalls, so don't worry if some of them gets crushed by the blocks. But keep at least a couple around to finish the game, if all YumbBalls are lost, the game is over.
To score you actually have to let the YumBalls die, but the longer their lifes have been, the more points they give when they die.